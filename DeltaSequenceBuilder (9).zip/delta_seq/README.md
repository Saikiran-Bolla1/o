# Delta Elektronika Sequence Builder

A desktop tool (PyQt5 + matplotlib) to build, edit, plot, upload and monitor
sequences for Delta Elektronika SM15K / SM3300 power supplies.

## Files

| File | Purpose |
|---|---|
| `delta_seq_gui.py` | The application – **run this one** |
| `delta_seq_core.py` | Sequence logic, file I/O and power-supply communication (no GUI). Must be in the same folder. |
| `requirements.txt` | Python packages |
| `build_exe.bat` / `build_exe.sh` | Build a single executable with PyInstaller |
| `tests/` | Automated tests (`python -m pytest tests -q`) incl. a fake power supply |

## Run

```
pip install -r requirements.txt
python delta_seq_gui.py
```

## Build a stand-alone .exe (Windows)

Double-click `build_exe.bat` (or run it in a terminal). The result is
`dist\DeltaSequenceBuilder.exe` – copy it to any Windows PC, no Python needed.
Antivirus tools sometimes flag new PyInstaller executables; this is a known
false positive.

## Window layout

Like dSPACE ControlDesk, every part is a **dock window**: *Connection*,
*Signal*, *Settings*, *Output* (sequence file / messages / script editor),
*Direct control* and *Live monitor*. Drag a window by its title to another
side, drop it on another window to stack them as tabs, double-click the title to
float it, or close it. The **Windows bar** on the left edge opens any window
with one click; *Windows → Reset layout* restores the default arrangement. The
layout is remembered between sessions.

The **Connection** window (top left) holds the IP address and port, Connect /
Disconnect, the connection status (connected or failed, with the reason), the
supply's model, serial number, firmware and response time, and quick actions.

## Finding your way around

- **Help → Quick start (F1)** – 5-step guide (also shown once at the first start);
  Help → Mouse & keyboard shortcuts.
- **Check result** in the Output window: ✓ OK (green), ! notes (amber), ✕ errors –
  click *show* to jump to the messages.

- **Top toolbar** – grouped and labelled: FILE · SEQUENCE FILES · SUPPLY · RUN. Colours
  tell the kind: blue = files, orange = supply, green = run, red = stop / output off.
  The pill on the right shows the supply connection (green / red / grey).
- **Windows bar (dark, left)** – opens each window; PLOTS switches the plot tabs.
- **Every window** has a blue title bar (drag to move, ❐ float, ✕ close) and a
  one-line explanation of what it is for.
- **Segments** each have their own coloured badge (∿ sine, / ramp, ⊓ square …).
- **Plot toolbar** – Restore view, Zoom in/out, Zoom box, Pan, Back/Forward, Data tips,
  Cursors, Copy values, Save image.

## Main features

- **Signal editor** – Constant, Ramp, Sine, Square, Triangle, Exponential, PWM
  (duty ramp), Battery discharge curve, Table, Combine (A + − × min max B),
  Wait for digital input, Wait for trigger. Repeat once / N times / forever.
- **Device profiles** – SM15K (70-CP-450 … 1500-CP-30) and SM3300
  (18-220 … 660-AR-11) limits; *Custom* for anything else.
- **Files** – export sequence `.txt` (SCPI upload commands or step list),
  open and hand-edit existing sequence files, import samples (CSV/TXT/Excel,
  µs…h, step or continuous), export samples, save/open projects (`.json`),
  drag & drop, recent files.
- **Plots** – MATLAB-style: mouse-wheel or +/− zoom (Ctrl = time only, Shift = Y only),
  drag to pan, **double-click (or R / Restore view) returns to the original view** – also
  while the toolbar Zoom/Pan tool is on; Zoom in / Zoom out buttons; **Data tips**
  (click a point to label its time and value, Esc or Clear tips removes them); two measurement cursors with Δt, 1/Δt, ΔV, min, max,
  mean, RMS; ←/→ jumps between step edges.
- **Compare** – overlay editor, script and any files; time offset and scale per
  signal; A − B difference plot.
- **Run sequences** (Device menu / Windows bar, Ctrl+R) – add one or more sequence
  `.txt` files (or the editor / script sequence), then run a single one or several
  one after another. Per file: repeat count and max time (needed for endless
  sequences). Options: upload first, verify, output ON at start / OFF at the end,
  pause between files, loop the list, stop at the first error. Lists can be saved.
- **Direct control** (Device menu / toolbar, Ctrl+D) – set voltage and current by
  hand, switch the output ON/OFF, see measured V / I / P and the programmed values.
  Takes remote control (`SYST:REM:CV REM`, `SYST:REM:CC REM`) when connecting;
  all commands can be changed under *Device → Connection settings*.
- **Device menu** – connection settings (default port 8462), test connection,
  upload with read-back verification, read a stored sequence back from the
  supply, run / stop / output OFF, **Live monitor** (logs measured V/I/P over
  the planned profile, saves CSV/Excel).

- **Compact ramps** – straight ramps become small INC loops: a 1000-point ramp
  needs ~10 steps instead of 2000 (within half a digit of the normal output).
- **Sink mode** – sink current (SCN) and sink power (SPN) profiles for SM15K.
- **Safety checks** – power (V × I) vs. rating, max step size, max rate,
  optional blocking, extra confirmation above a set voltage (default 60 V).
- **Tolerance + reports** – ± absolute / % bands with settling time in the
  Compare tab and Live monitor, PASS/FAIL, PDF test report.
- **Templates** – save segments as your own templates; they are listed under *Templates → Project*.

## Editing imported files, saving under another name, looping

- **Imported samples** become a *Table* segment. Click it in the Signal window to edit
  every value / hold time, add or delete rows, paste from Excel, copy to Excel, or use
  **Change values…** (value × factor + offset, hold time × factor – selected rows or all).
- **Loop anything:** every segment has **Repeat this segment** (e.g. samples ×10). It is
  written as a loop on the supply (variable #C), so it needs no extra steps. When you
  *append* samples with "Repeat N times", only the samples are looped. The project
  **Repeat** setting (Signal window) loops the whole sequence, ∞ = forever.
- **Sequence .txt files:** Open .txt → edit in **Script editor** → *Apply & simulate*
  → **Save as .txt…** (unchanged text, or clean SCPI / step list under a new name).
  **Convert to editable…** turns it into segments you can edit like your own.
- **Save as a different file:** File → Save project as… (.json), Export sequence .txt…,
  Export samples… (CSV/TXT/XLSX, from the editor or from an opened .txt).

## Command-line mode

`delta_seq_core.py` also works without the window, e.g. for test rigs:

```
python delta_seq_core.py compile project.json -o seq.txt
python delta_seq_core.py convert log.csv --unit ms --continuous --dt 0.05 --compact -o seq.txt
python delta_seq_core.py simulate seq.txt -o samples.csv
python delta_seq_core.py upload seq.txt --host 192.168.0.100 --verify --run
python delta_seq_core.py read SEQ1 --host 192.168.0.100 -o seq1.txt
python delta_seq_core.py measure --host 192.168.0.100 --count 10 --interval 0.5
python delta_seq_core.py set --volt 24 --curr 2 --remote --host 192.168.0.100
python delta_seq_core.py output on --host 192.168.0.100
python delta_seq_core.py status --host 192.168.0.100
```

Run `python delta_seq_core.py --help` (or `<command> --help`) for all options.

## If a sequence does not run / nothing comes out

Use **Device → Diagnose sequence…**. It asks the supply for the sequencer state,
its error queue, the output state, the CV/CC/CP control sources and the
programmed power, and says what to fix. The usual causes:

- **Power limit 0 W** – SM15K supplies start a sequence with SP = 0. Sequences
  from this app now write `SP=<limit>` (Settings tab → *Power limit*); re-upload
  older sequences.
- **Control source** – voltage/current must be controlled by the *Sequencer*.
  Run / Upload & run / Live monitor now send `SYST:REM:CV SEQ; SYST:REM:CC SEQ;
  SYST:REM:CP SEQ` first. Direct control takes control *away* from the sequencer
  (use *Hand control back to sequencer*).
- **Output off** – switch it on (Direct control, Live monitor or front panel).
- **Errors** – a wrong step or a missing END stops the build; the supply's error
  text is shown after Run.

## Please verify on your supply first

The sequencer syntax comes from Delta's *Ethernet & Sequencer Programming*
manual, but some details could not be confirmed without hardware:

- the read-back reply format of `PROG:SEL:STE?` (the tool tries one full query,
  then step by step – raw replies are shown under *Messages*),
- whether `PROG:SEL:LAB?` exists (labels may need re-adding after read-back),
- the measurement queries (`MEAS:VOLT?`, `MEAS:CURR?`, `MEAS:POW?`) – editable
  under *Device → Connection settings*,
- that `INC`/`DEC` accept decimal values for SV/SC (used by *Compact ramps* –
  off by default) and the sink settings `SCN`/`SPN` on your firmware.

Test with a short sequence and no load connected before using it on a real
setup.
