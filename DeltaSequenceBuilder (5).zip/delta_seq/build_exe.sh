#!/usr/bin/env sh
# Builds a single DeltaSequenceBuilder executable in ./dist (Linux / macOS).
set -e
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt pyinstaller
python3 -m PyInstaller --noconfirm --clean --onefile --windowed \
    --name DeltaSequenceBuilder \
    --hidden-import openpyxl \
    delta_seq_gui.py
echo "Done: dist/DeltaSequenceBuilder"
