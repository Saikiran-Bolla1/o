@echo off
REM Builds a single DeltaSequenceBuilder.exe in the "dist" folder (Windows).
REM Run this from the folder that contains delta_seq_gui.py and delta_seq_core.py.

python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :error

python -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name DeltaSequenceBuilder ^
    --hidden-import openpyxl ^
    delta_seq_gui.py
if errorlevel 1 goto :error

echo.
echo Done: dist\DeltaSequenceBuilder.exe
goto :eof

:error
echo.
echo Build failed - see the messages above.
exit /b 1
