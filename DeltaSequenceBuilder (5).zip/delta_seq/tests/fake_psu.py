"""Fake Delta Elektronika PSU for testing (TCP, line based)."""
import os, re, socket, sys, threading, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import delta_seq_core as c


class FakePSU:
    def __init__(self, port=0, full_query=False):
        self.seqs = {}          # name -> {n: cmd}
        self.labels = {}        # name -> {lbl: n}
        self.sel = None
        self.full_query = full_query
        self.state = "STOP"; self.t_run = None; self.trace = None
        self.out = 0; self.log = []
        self.sv = 0.0; self.sc = 0.0; self.remote = set()
        self.src = {"CV": "FRONT", "CC": "FRONT", "CP": "FRONT"}
        self.errors = []; self.sp = 0.0
        self.srv = socket.socket(); self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", port)); self.srv.listen(5)
        self.port = self.srv.getsockname()[1]
        threading.Thread(target=self._accept, daemon=True).start()

    def _accept(self):
        while True:
            try:
                conn, _ = self.srv.accept()
            except OSError:            # server closed
                return
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    def close(self):
        try:
            self.srv.close()
        except OSError:
            pass

    def _values(self):
        if self.state == "RUN" and self.trace:
            t = time.monotonic() - self.t_run
            r = self.trace
            if t >= r.end_time: self.state = "STOP"
            sp_tr = r.traces.get("SP", [(0, 0.0)])
            sp_now = c.step_value_at([x for x, _ in sp_tr], [v for _, v in sp_tr], t)
            if not (str(self.out) in ("1", "ON") and self.src["CV"].startswith("SEQ")
                    and sp_now > 0):
                return 0.0, 0.0          # like a real SM15K: no output
            sv = c.step_value_at([x for x, _ in r.traces["SV"]], [v for _, v in r.traces["SV"]], t)
            sc = c.step_value_at([x for x, _ in r.traces["SC"]], [v for _, v in r.traces["SC"]], t)
            return sv, min(sc, sv / 2.0)   # 2 ohm load, current limited
        if str(self.out) in ("1", "ON"):               # manual mode, 2 ohm load
            return self.sv, min(self.sc, self.sv / 2.0)
        return 0.0, 0.0

    def handle(self, line):
        self.log.append(line)
        u = line.strip(); U = u.upper()
        if U == "*IDN?": return "DELTA ELEKTRONIKA,SM70-CP-450,FAKE123,P0130"
        if m := re.match(r"PROG:SEL:NAM\s+(\S+)$", u, re.I):
            self.sel = m.group(1).upper(); self.seqs.setdefault(self.sel, {}); return None
        if U == "PROG:SEL:DEL": self.seqs[self.sel] = {}; self.labels[self.sel] = {}; return None
        if m := re.match(r"PROG:SEL:STE\s+(\d+)\s+(.+)$", u, re.I):
            cmd = m.group(2).upper()
            if not c._RE_BARE.match(cmd):
                self.errors.append(f"-102,Syntax error in step {m.group(1)} ({cmd})"); return None
            self.seqs[self.sel][int(m.group(1))] = cmd; return None
        if m := re.match(r"PROG:SEL:STE\s+(\d+)\?$", u, re.I):
            return self.seqs.get(self.sel, {}).get(int(m.group(1)), "")
        if U == "PROG:SEL:STE?":
            if not self.full_query: return "ERROR"
            return "\n".join(f"{n} {cmd}" for n, cmd in sorted(self.seqs[self.sel].items()))
        if m := re.match(r"PROG:SEL:LAB\s+(\w+),(\d+)$", u, re.I):
            self.labels.setdefault(self.sel, {})[m.group(1).upper()] = int(m.group(2)); return None
        if U == "PROG:SEL:LAB?":
            return ";".join(f"{k},{v}" for k, v in self.labels.get(self.sel, {}).items()) or ""
        if U == "PROG:CAT?": return ",".join(self.seqs)
        if U == "PROG:SEL:STA RUN" and "END" not in self.seqs.get(self.sel, {}).values():
            self.errors.append("-200,Program open end (no END step)"); return None
        if U == "PROG:SEL:STA RUN":
            txt = "\n".join(f"{n} {cmd}" for n, cmd in sorted(self.seqs[self.sel].items()))
            txt += "".join(f"\n# label {k} = step {v}" for k, v in self.labels.get(self.sel, {}).items())
            self.trace = c.simulate(c.parse_sequence_text(txt), max_time=60, step_time=0)
            self.state = "RUN"; self.t_run = time.monotonic(); return None
        if U == "PROG:SEL:STA STOP": self.state = "STOP"; return None
        if U == "PROG:SEL:STA?": self._values(); return self.state
        if U == "MEAS:VOLT?": return f"{self._values()[0]:.4f}"
        if U == "MEAS:CURR?": return f"{self._values()[1]:.4f}"
        if U == "MEAS:POW?": v, i = self._values(); return f"{v*i:.3f}"
        if m := re.match(r"OUTP\s+(\S+)", u, re.I): self.out = m.group(1).upper(); return None
        if U == "OUTP?": return "1" if str(self.out) in ("1", "ON") else "0"
        if m := re.match(r"SOUR:VOLT\s+(\S+)$", u, re.I): self.sv = float(m.group(1)); return None
        if m := re.match(r"SOUR:CURR\s+(\S+)$", u, re.I): self.sc = float(m.group(1)); return None
        if U == "SOUR:VOLT?": return f"{self.sv:.4f}"
        if U == "SOUR:CURR?": return f"{self.sc:.4f}"
        if m := re.match(r"SYST:REM:(CV|CC|CP)\s+(\S+)$", u, re.I):
            self.src[m.group(1).upper()] = m.group(2).upper()
            if m.group(2).upper().startswith("REM"): self.remote.add(m.group(1).upper())
            return None
        if m := re.match(r"SYST:REM:(CV|CC|CP)\?$", u, re.I): return self.src[m.group(1).upper()]
        if U == "SYST:ERR?": return self.errors.pop(0) if self.errors else "0,None"
        if m := re.match(r"SOUR:POW\s+(\S+)$", u, re.I): self.sp = float(m.group(1)); return None
        if U == "SOUR:POW?": return f"{self.sp:.1f}"
        if U.endswith("?") and not U.startswith("PROG"):
            self.errors.append(f"-113,Undefined header ({u})"); return "ERROR"
        return None

    def _serve(self, conn):
        buf = b""
        with conn:
            while True:
                try:
                    d = conn.recv(4096)
                except OSError:        # Windows: connection reset/aborted by client
                    return
                if not d: return
                buf += d
                while b"\n" in buf:
                    ln, buf = buf.split(b"\n", 1)
                    r = self.handle(ln.decode())
                    if r is not None:
                        try:
                            conn.sendall((r + "\n").encode())
                        except OSError:
                            return
