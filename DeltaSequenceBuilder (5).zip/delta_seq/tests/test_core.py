"""Automated tests for delta_seq_core (no GUI, no hardware).

    pip install pytest
    python -m pytest tests -q
"""
import copy
import math
import os
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import delta_seq_core as c          # noqa: E402
from fake_psu import FakePSU        # noqa: E402

# The tests must match delta_seq_core.py. If they come from different
# downloads, stop with one clear message instead of dozens of errors.
_NEEDED = ["SEGMENT_TYPES", "WAIT_TYPES", "compile_sequence", "simulate",
           "simulate_settings", "parsed_to_text", "tolerance_check", "make_report",
           "max_setpoint", "main_cli", "linear_value_at", "segment_compiled_duration"]
_missing = [n for n in _NEEDED if not hasattr(c, n)]
if _missing:
    pytest.exit(f"delta_seq_core.py ({c.__file__}) is older than these tests – "
                f"missing {', '.join(_missing)}. Use delta_seq_core.py and tests/ "
                f"from the same zip.", returncode=2)

d = c.default_segment


def run(cfg, max_time=1e5, allow_too_long=False):
    comp = c.compile_sequence(cfg)
    errs = [e for e in comp.errors if not (allow_too_long and "max 2000" in e)]
    assert not errs, errs
    seq = c.parse_sequence_text(c.to_text(cfg, comp))
    return comp, c.simulate(seq, max_time=max_time, step_time=0.0)


def trace_dev(ra, rb, ch):
    xa = [t for t, _ in ra.traces[ch]]; ya = [v for _, v in ra.traces[ch]]
    xb = [t for t, _ in rb.traces[ch]]; yb = [v for _, v in rb.traces[ch]]
    ts = sorted(set(round(x, 9) for x in xa + xb))
    return max(abs(c.step_value_at(xa, ya, t + 1e-9) - c.step_value_at(xb, yb, t + 1e-9))
               for t in ts)


# ---------------------------------------------------------------- compile
def test_basic_ramp_compiles_and_simulates():
    comp, r = run(c.SequenceSettings(segments=[d("Ramp")]))
    assert comp.steps[-1] == "END"
    assert r.stop_reason.startswith("END")
    assert r.end_time == pytest.approx(comp.duration_one_pass)


@pytest.mark.parametrize("repeat", [1, 2, 5])
def test_repeat_runs_n_times(repeat):
    comp, r = run(c.SequenceSettings(repeat=repeat, segments=[d("Square")]))
    assert r.end_time == pytest.approx(comp.duration_one_pass * repeat)


def test_infinite_loop_uses_label():
    cfg = c.SequenceSettings(repeat=0, segments=[d("Constant")])
    comp = c.compile_sequence(cfg)
    assert "JP LOOP" in comp.steps and "LOOP" in comp.labels
    seq = c.parse_sequence_text(c.to_text(cfg, comp))
    r = c.simulate(seq, max_time=5, step_time=0.0)
    assert r.stop_reason.startswith("Stopped at the simulation limit")


def test_too_many_steps_is_an_error():
    cfg = c.SequenceSettings(segments=[d("Sine") | {"duration": 100, "dt": 0.01}])
    assert any("max 2000" in e for e in c.compile_sequence(cfg).errors)


def test_value_above_model_limit_is_an_error():
    cfg = c.SequenceSettings(vmax=70, segments=[d("Constant") | {"value": 80}])
    assert any("exceeds" in e for e in c.compile_sequence(cfg).errors)


@pytest.mark.parametrize("kind", [k for k in c.SEGMENT_TYPES if k not in c.WAIT_TYPES])
def test_every_segment_type_compiles(kind):
    seg = d(kind)
    cfg = c.SequenceSettings(segments=[seg], vmax=1000)
    comp = c.compile_sequence(cfg)
    assert not comp.errors, comp.errors


def test_combine_multiply():
    seg = {"type": "Combine", "op": "Multiply", "dt": 0.5,
           "a": d("Constant") | {"value": 4, "duration": 2},
           "b": d("Constant") | {"value": 2.5, "duration": 2}}
    assert all(v == pytest.approx(10) for v, _ in c.sample_segment(seg))


def test_wait_steps_generate_poll_loop_and_trigger():
    cfg = c.SequenceSettings(segments=[d("Constant"), d("Wait for input") |
                                       {"input": "IB2", "level": "0 (low)"},
                                       d("Wait for trigger"), d("Constant")])
    comp = c.compile_sequence(cfg)
    i = comp.steps.index("NOP")
    assert comp.steps[i + 1] == f"CJNE IB2,0,{i + 1}"
    assert "TRG" in comp.steps
    assert len(comp.markers) == 2


# ---------------------------------------------------------------- compact ramps
@pytest.mark.parametrize("cfg", [
    c.SequenceSettings(segments=[d("Ramp") | {"end": 50, "duration": 100, "dt": 0.1}]),
    c.SequenceSettings(segments=[d("Ramp") | {"start": 50, "end": 0, "duration": 10,
                                              "dt": 0.01}]),
    c.SequenceSettings(repeat=3, segments=[d("Triangle") | {"cycles": 3, "dt": 0.05},
                                           d("Constant"), d("Ramp")]),
    c.SequenceSettings(decimals=2, segments=[d("Ramp") | {"end": 7, "duration": 9,
                                                          "dt": 0.03}]),
    c.SequenceSettings(channel="SCN", limit_voltage=40, segments=[
        d("Ramp") | {"start": 0, "end": -100, "duration": 5, "dt": 0.01}]),
])
def test_compact_ramps_match_expanded_output(cfg):
    a = copy.deepcopy(cfg); a.compact_ramps = False
    b = copy.deepcopy(cfg); b.compact_ramps = True
    ca, ra = run(a, allow_too_long=True)     # reference: may exceed 2000 steps
    cb, rb = run(b)
    assert len(cb.steps) < len(ca.steps)
    assert ra.end_time == pytest.approx(rb.end_time)
    assert trace_dev(ra, rb, cfg.channel) <= 0.5 * 10 ** -cfg.decimals * 1.00001


def test_compact_makes_long_ramp_fit():
    cfg = c.SequenceSettings(compact_ramps=True, segments=[
        d("Ramp") | {"end": 60, "duration": 600, "dt": 0.05}])
    comp = c.compile_sequence(cfg)
    assert not comp.errors and len(comp.steps) < 100


# ---------------------------------------------------------------- sink + safety
def test_sink_channel_rejects_positive_values():
    cfg = c.SequenceSettings(channel="SCN", segments=[d("Constant") | {"value": 5}])
    assert any("sink" in e for e in c.compile_sequence(cfg).errors)


def test_sink_warning_on_device_without_sink():
    cfg = c.SequenceSettings(channel="SCN", device="SM 18-220", cmax=220,
                             segments=[d("Constant") | {"value": -5}])
    assert any("no built-in sink" in w for w in c.compile_sequence(cfg).warnings)


def test_safety_checks_warn_or_block():
    cfg = c.SequenceSettings(limit_current=400, max_step=5, max_rate=20, segments=[
        d("Square") | {"high": 60, "cycles": 1}])
    comp = c.compile_sequence(cfg)
    assert sum(w.startswith("Safety") for w in comp.warnings) == 3
    cfg.safety_errors = True
    assert sum(e.startswith("Safety") for e in c.compile_sequence(cfg).errors) == 3


def test_max_setpoint_follows_loops():
    cfg = c.SequenceSettings(compact_ramps=True, segments=[
        d("Ramp") | {"end": 42, "duration": 10, "dt": 0.1}])
    assert c.max_setpoint(c.compile_sequence(cfg).steps) == pytest.approx(42, abs=1e-3)


# ---------------------------------------------------------------- files
def test_parse_formats_and_renumber():
    txt = "1 SV=5\n2 #A=0\n5 SV=10\n6 W=1\n8 INC #A,1\n9 CJL #A,3,5\n12 JP 15\n15 END\n"
    seq = c.parse_sequence_text(txt)
    out = c.parsed_to_text(seq, "NEW", "steps")
    assert "6 CJL #A,3,3" in out and "7 JP 8" in out
    r1 = c.simulate(seq, step_time=0)
    r2 = c.simulate(c.parse_sequence_text(c.parsed_to_text(seq, "NEW")), step_time=0)
    assert r1.traces["SV"] == r2.traces["SV"]


def test_samples_import_step_and_continuous(tmp_path):
    f = tmp_path / "s.csv"
    f.write_text("Time_ms;Voltage\n0;0\n500;10,5\n1000;20\n2000;5\n")
    rows = c.read_table_file(str(f))
    smp, skipped = c.extract_samples(rows, 0, 1, "ms", c.detect_header(rows))
    assert skipped == 0 and smp[1] == (0.5, 10.5)
    step, _ = c.samples_to_points(smp, c.SampleImportOptions())
    assert step[:2] == [[0.0, 0.5], [10.5, 0.5]]
    cont, _ = c.samples_to_points(smp, c.SampleImportOptions(continuous=True,
                                                             resample_dt=0.25))
    assert cont[1][0] == pytest.approx(5.25)


def test_export_samples_roundtrip(tmp_path):
    pytest.importorskip("openpyxl", reason="openpyxl not installed (Excel files)")
    cfg = c.SequenceSettings(segments=[d("Square") | {"cycles": 1}])
    r = c.simulate_settings(cfg)
    header, rows = c.traces_to_table({"SV": r.traces["SV"]}, r.end_time, "steps")
    path = tmp_path / "out.xlsx"
    c.write_table_file(str(path), header, rows)
    back = c.read_table_file(str(path))
    assert back[0] == header and len(back) == len(rows) + 1


# ---------------------------------------------------------------- tolerance + report
def test_tolerance_check_and_report(tmp_path):
    pytest.importorskip("matplotlib", reason="matplotlib not installed (PDF report)")
    planned = [(0, 0), (1, 10), (3, 5), (5, 5)]
    meas = [(i * 0.05, c.step_value_at([0, 1, 3], [0, 10, 5], i * 0.05)
             + (0.4 if 80 < i < 84 else 0)) for i in range(100)]
    r = c.tolerance_check(planned, meas, tol_abs=0.2, settle=0.1, end_time=5)
    assert not r.passed and r.n_fail == 3
    assert c.tolerance_check(planned, meas, tol_abs=0.5, end_time=5).passed
    pdf = tmp_path / "r.pdf"
    c.make_report(str(pdf), {"title": "t"}, {"V": planned}, {"V": meas}, {"V": r})
    assert pdf.stat().st_size > 5000


# ---------------------------------------------------------------- power supply (fake)
@pytest.fixture
def psu():
    srv = FakePSU()
    yield srv
    srv.close()


def test_upload_verify_readback_measure(psu):
    cfg = c.SequenceSettings(name="DEMO", repeat=0, segments=[
        d("Square") | {"cycles": 1, "period": 0.4, "high": 10}])
    comp = c.compile_sequence(cfg)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        assert "DELTA" in c.identify(con)
        c.upload_sequence(con, c.to_scpi_lines(cfg, comp))
        assert c.verify_upload(con, "DEMO", comp.steps) == []
        assert c.list_sequences(con) == ["DEMO"]
        text, _ = c.read_sequence(con, "DEMO")
        back = c.parse_sequence_text(text)
        assert list(back.steps.values()) == comp.steps
        assert back.labels == comp.labels
        assert "SP=15000" in comp.steps          # SM15K: power limit is written
        c.set_output(con, True)
        res = c.run_sequence(con, "DEMO", settle=0.05)
        assert res["running"] and res["errors"] == []
        m = c.measure(con, c.DEFAULT_QUERIES)
        assert m["V"] == pytest.approx(10)


def test_readback_full_query_mode():
    psu = FakePSU(full_query=True)
    try:
        _readback_full(psu)
    finally:
        psu.close()


def _readback_full(psu):
    cfg = c.SequenceSettings(name="FQ", segments=[d("Ramp")])
    comp = c.compile_sequence(cfg)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        c.upload_sequence(con, c.to_scpi_lines(cfg, comp))
        text, _ = c.read_sequence(con, "FQ")
    assert list(c.parse_sequence_text(text).steps.values()) == comp.steps


def test_connection_error_is_reported():
    with pytest.raises(c.PsuError):
        c.PsuConnection("127.0.0.1", 1, timeout=0.5).open()


# ---------------------------------------------------------------- command line
def test_cli_compile_convert_simulate_upload(tmp_path, psu, capsys):
    proj = tmp_path / "p.json"
    proj.write_text(c.SequenceSettings(name="CLI", segments=[d("Ramp")]).to_json())
    out = tmp_path / "p.txt"
    assert c.main_cli(["compile", str(proj), "-o", str(out)]) == 0
    assert "PROG:SEL:STE 1" in out.read_text()

    smp = tmp_path / "s.csv"
    smp.write_text("t,v\n0,0\n1,5\n2,10\n")
    out2 = tmp_path / "s.txt"
    assert c.main_cli(["convert", str(smp), "--unit", "s", "-o", str(out2),
                       "--name", "CONV"]) == 0
    assert "SV=5" in out2.read_text()

    csv = tmp_path / "sim.csv"
    assert c.main_cli(["simulate", str(out2), "-o", str(csv)]) == 0
    assert csv.read_text().startswith("Time [s]")

    assert c.main_cli(["upload", str(out2), "--host", "127.0.0.1", "--port",
                       str(psu.port), "--verify"]) == 0
    assert "CONV" in psu.seqs


# ---------------------------------------------------------------- regressions
@pytest.mark.parametrize("value,decimals,text", [
    (10, 0, "10"), (-50, 0, "-50"), (100, 0, "100"), (-0.4, 0, "0"),
    (10.5, 1, "10.5"), (10.5, 3, "10.5"), (0, 2, "0"), (65535, 3, "65535")])
def test_number_formatting_keeps_integer_zeros(value, decimals, text):
    assert c._fmt(value, decimals) == text


def test_zero_decimals_output_matches_plan():
    cfg = c.SequenceSettings(decimals=0, segments=[d("Constant") | {"value": 10},
                                                   d("Constant") | {"value": 20}])
    comp, r = run(cfg)
    assert "SV=10" in comp.steps and "SV=20" in comp.steps
    assert c.step_value_at([t for t, _ in r.traces["SV"]],
                           [v for _, v in r.traces["SV"]], 0.5) == 10


def test_verify_compares_numbers_not_text():
    assert c.steps_equal("W=0.500", "W=0.5")
    assert c.steps_equal("SV=+10", "SV=10")
    assert c.steps_equal("cjl #a,3,5", "CJL #A,3,5")
    assert not c.steps_equal("SV=10", "SV=1")
    assert not c.steps_equal("INC SV,0.0050004", "INC SV,0.005")


def test_clock_times_continue_past_midnight():
    rows = [["time", "v"], ["23:59:58", "1"], ["23:59:59.5", "2"], ["00:00:01", "3"]]
    smp, _ = c.extract_samples(rows, 0, 1, "hh:mm:ss / date-time", True)
    assert [t for t, _ in smp] == [86398.0, 86399.5, 86401.0]


@pytest.mark.parametrize("text", ["[]", '{"channel": "XX"}', "not json",
                                  '{"segments": [{"type": "Nope"}]}'])
def test_bad_project_files_are_rejected_clearly(text):
    with pytest.raises(ValueError):
        c.SequenceSettings.from_json(text)


def test_project_missing_parameters_are_filled():
    cfg = c.SequenceSettings.from_json('{"segments": [{"type": "Ramp", "end": 5}]}')
    assert not c.compile_sequence(cfg).errors


def test_compare_loads_sample_files(tmp_path):
    f = tmp_path / "m.csv"
    f.write_text("t_ms,U,I\n500,5,1\n0,0,0\n1000,10,2\n")       # unsorted on purpose
    traces, end, kind = c.load_traces(str(f), "ms")
    assert kind == "samples" and list(traces) == ["U", "I"]
    assert [t for t, _ in traces["U"]] == [0.0, 0.5, 1.0] and end == 1.0


def test_tolerance_ignores_points_after_planned_end():
    planned = [(0, 5), (1, 5)]
    meas = [(0.5, 5.0), (3.0, 0.0)]          # after the end the output is off
    assert c.tolerance_check(planned, meas, tol_abs=0.1, end_time=1.0).passed


def test_leading_wait_is_counted_for_preview():
    cfg = c.SequenceSettings(repeat=3, segments=[d("Wait for input"),
                                                 d("Constant") | {"value": 7}])
    assert c.compile_sequence(cfg).lead_waits == 1



# ---------------------------------------------------------------- direct control
def test_direct_control_set_output_status(psu):
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        assert c.take_remote_control(con) == ["SYST:REM:CV REM", "SYST:REM:CC REM"]
        assert c.set_setpoints(con, 12.5, 3) == ["SOUR:VOLT 12.5", "SOUR:CURR 3"]
        c.set_output(con, True)
        st = c.read_status(con)
    assert psu.remote == {"CV", "CC"}
    assert st["set_V"] == 12.5 and st["set_I"] == 3 and st["output"] is True
    assert st["V"] == pytest.approx(12.5) and st["I"] == pytest.approx(3)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        c.set_output(con, False)
        assert c.read_status(con)["output"] is False


def test_direct_control_rejects_negative_and_custom_commands(psu):
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        with pytest.raises(ValueError):
            c.set_setpoints(con, -1)
        sent = c.set_setpoints(con, 5, cmds={"set_v": "SOUR:VOLT {v}"})
    assert sent == ["SOUR:VOLT 5"]


@pytest.mark.parametrize("reply,state", [("1", True), ("ON", True), ("0", False),
                                         ("OFF", False), ("garbage", None)])
def test_output_state_parsing(reply, state):
    assert c.parse_on_off(reply) is state


def test_cli_set_output_status(psu, capsys):
    base = ["--host", "127.0.0.1", "--port", str(psu.port)]
    assert c.main_cli(["set", "--volt", "24", "--curr", "2", "--remote"] + base) == 0
    assert c.main_cli(["output", "on"] + base) == 0
    assert c.main_cli(["status"] + base) == 0
    out = capsys.readouterr().out
    assert "set_V      24" in out and "output     True" in out



# ---------------------------------------------------------------- running + diagnostics
def test_power_limit_written_per_device():
    seg = [d("Constant") | {"value": 5}]
    assert "SP=15000" in c.compile_sequence(c.SequenceSettings(segments=seg)).steps
    sm3300 = c.SequenceSettings(device="SM 66-AR-110", vmax=66, cmax=110, pmax=3300,
                                segments=seg)
    assert not any(st.startswith("SP=") for st in c.compile_sequence(sm3300).steps)
    sm3300.write_power = "yes"; sm3300.power_limit = 1000
    assert "SP=1000" in c.compile_sequence(sm3300).steps
    sink = c.SequenceSettings(channel="SCN", segments=[d("Constant") | {"value": -5}],
                              power_limit=2000)
    steps = c.compile_sequence(sink).steps
    assert "SP=2000" in steps and "SPN=-2000" in steps
    too_much = c.SequenceSettings(segments=seg, power_limit=99999)
    assert any("Power limit" in e for e in c.compile_sequence(too_much).errors)


def test_sequence_without_sequencer_source_gives_no_output(psu):
    cfg = c.SequenceSettings(name="SRC", repeat=0, segments=[d("Constant") | {"value": 10}])
    comp = c.compile_sequence(cfg)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        c.upload_sequence(con, c.to_scpi_lines(cfg, comp))
        c.set_output(con, True)
        res = c.run_sequence(con, "SRC", to_sequencer=False)   # source stays FRONT
        assert res["running"]
        assert c.measure(con, c.DEFAULT_QUERIES)["V"] == 0      # nothing comes out
        report = {r["check"]: r for r in c.diagnose(con, "SRC")}
        assert report["Voltage control (CV) source"]["ok"] is False
        c.run_sequence(con, "SRC")                               # hand control over
        assert c.measure(con, c.DEFAULT_QUERIES)["V"] == pytest.approx(10)
        report = {r["check"]: r for r in c.diagnose(con, "SRC")}
    assert report["Voltage control (CV) source"]["ok"] is True
    assert report["Sequencer state"]["ok"] is True and report["Output"]["ok"] is True


def test_run_reports_supply_errors(psu):
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        con.write("PROG:SEL:NAM BROKEN")
        con.write("PROG:SEL:STE 1 SV=5")                       # no END step
        res = c.run_sequence(con, "BROKEN")
        assert not res["running"] and any("open end" in e for e in res["errors"])
        report = {r["check"]: r for r in c.diagnose(con, "MISSING")}
    assert report["Sequence stored"]["ok"] is False



def test_identification_parsing_and_device_match():
    info = c.parse_idn("DELTA ELEKTRONIKA BV,SM66-AR-110,000010097302,H0_P0150,0")
    assert info["model"] == "SM66-AR-110" and info["serial"] == "000010097302"
    assert info["firmware"] == "H0_P0150,0"
    assert c.match_device("SM66-AR-110") == "SM 66-AR-110"
    assert c.match_device("SM70-CP-450") == "SM 70-CP-450"
    assert c.match_device("SOMETHING ELSE") is None
    assert c.parse_idn("")["model"] == ""


# ---------------------------------------------------------------- run list
def _write_seq(tmp_path, fname, cfg):
    comp = c.compile_sequence(cfg)
    assert not comp.errors, comp.errors
    p = tmp_path / fname
    p.write_text(c.to_text(cfg, comp))
    return str(p)


@pytest.fixture
def seq_files(tmp_path):
    short = c.SequenceSettings(name="SHORT", segments=[d("Constant") | {"value": 5,
                                                                        "duration": 0.15}])
    ramp = c.SequenceSettings(name="RAMP", segments=[d("Ramp") | {"end": 8, "duration": 0.2,
                                                                  "dt": 0.05}])
    endless = c.SequenceSettings(name="FOREVER", repeat=0,
                                 segments=[d("Constant") | {"value": 3, "duration": 0.1}])
    return {"short": _write_seq(tmp_path, "short.txt", short),
            "ramp": _write_seq(tmp_path, "ramp.txt", ramp),
            "endless": _write_seq(tmp_path, "endless.txt", endless)}


def _run(psu, items, **kw):
    events = []
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        ok = c.execute_run_list(con, items, poll=0.05,
                                on_event=lambda k, i, m: events.append((k, i)), **kw)
    return ok, events


def test_run_list_runs_files_in_order(psu, seq_files):
    items = [c.load_run_item(seq_files["short"]), c.load_run_item(seq_files["ramp"])]
    assert [it.name for it in items] == ["SHORT", "RAMP"]
    assert items[0].duration == pytest.approx(0.15) and items[1].duration is not None
    ok, ev = _run(psu, items)
    assert ok
    kinds = [k for k, _ in ev if k != "state"]
    assert kinds == ["upload", "start", "done", "upload", "start", "done", "list_done"]
    runs = [ln for ln in psu.log if ln.upper().startswith("PROG:SEL:NAM")]
    assert runs[-1].upper().endswith("RAMP")


def test_run_list_repeat_and_max_time(psu, seq_files):
    rep = c.load_run_item(seq_files["short"]); rep.repeat = 2
    endless = c.load_run_item(seq_files["endless"])
    assert endless.duration is None and any("endless" in n for n in endless.notes)
    endless.max_time = 0.3
    ok, ev = _run(psu, [rep, endless])
    assert ok
    assert [k for k, i in ev if i == 0 and k == "start"] == ["start", "start"]
    assert ("timeout", 1) in ev and ("done", 1) in ev


def test_run_list_stop_button(psu, seq_files):
    endless = c.load_run_item(seq_files["endless"])
    flag = {"stop": False}
    events = []

    def on_event(kind, i, msg):
        events.append(kind)
        if kind == "start":
            flag["stop"] = True
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        ok = c.execute_run_list(con, [endless], poll=0.05, should_stop=lambda: flag["stop"],
                                on_event=on_event)
    assert not ok and "stopped" in events and psu.state == "STOP"


def test_run_list_error_handling(psu, seq_files, tmp_path):
    bad = tmp_path / "bad.txt"
    bad.write_text("1 SV=5\n2 W=0.1\n")                  # no END step
    bad_item = c.load_run_item(str(bad))
    assert any("no END" in n for n in bad_item.notes)
    good = c.load_run_item(seq_files["short"])
    ok, ev = _run(psu, [bad_item, good])
    assert not ok and ev[-1][0] == "failed"             # stops at the first error
    ok, ev = _run(psu, [bad_item, good], stop_on_error=False)
    assert ok and ("done", 1) in ev                     # or carries on with the next


def test_run_item_notes_missing_power_limit(tmp_path):
    p = tmp_path / "old.txt"
    p.write_text("1 SC=5\n2 SV=10\n3 W=1\n4 END\n")
    item = c.load_run_item(str(p), device="SM 70-CP-450")
    assert any("power limit" in n for n in item.notes) and item.name == "old"



def test_upload_reports_rejected_steps(psu):
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        errs = c.upload_sequence(con, ["PROG:SEL:NAM X", "PROG:SEL:STE 1 SV=5",
                                       "PROG:SEL:STE 2 BOGUS 7", "PROG:SEL:STE 3 END"])
        assert len(errs) == 1 and "Syntax" in errs[0]
        assert c.upload_sequence(con, ["PROG:SEL:NAM Y", "PROG:SEL:STE 1 END"]) == []


def test_run_list_stops_on_rejected_upload(psu, tmp_path):
    p = tmp_path / "typo.txt"
    p.write_text("1 SV=5\n2 W=0.1\n3 END\n")
    item = c.load_run_item(str(p))
    item.seq.steps[2] = "WAIT 0.1"                     # a step the supply rejects
    ok, ev = _run(psu, [item])
    assert not ok and ev[-1][0] == "failed"


# ---- input validation (huge / negative values must give a clear error, not hang)
@pytest.mark.parametrize("seg", [
    {"type": "Ramp", "start": 0, "end": 10, "duration": 100000, "dt": 0.001},
    {"type": "Sine", "offset": 0, "amplitude": 1, "freq": 1, "phase": 0,
     "duration": -4, "dt": 0.05},
    {"type": "Constant", "value": 5, "duration": 0},
    {"type": "Square", "low": 0, "high": 1, "period": 0, "duty": 50, "cycles": 3},
    {"type": "Square", "low": 0, "high": 1, "period": 1, "duty": 150, "cycles": 3},
    {"type": "Triangle", "low": 0, "high": 1, "period": 100, "cycles": 10000, "dt": 0.001},
    {"type": "PWM", "low": 0, "high": 1, "freq": 100000, "duty_start": 10,
     "duty_end": 90, "duration": 100000},
])
def test_bad_segment_values_are_rejected_quickly(seg):
    t0 = time.monotonic()
    comp = c.compile_sequence(c.SequenceSettings(segments=[seg]))
    assert comp.errors and "Segment 1" in comp.errors[0]
    assert time.monotonic() - t0 < 2
