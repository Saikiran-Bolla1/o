"""
Delta Elektronika Sequence Builder - ControlDesk-style signal editor (PyQt5).

    pip install PyQt5 matplotlib
    python delta_seq_gui.py
"""
from __future__ import annotations

import copy
import json
import math
import os
import re
import sys
import time

from PyQt5.QtCore import Qt, QSettings, QThread, QTimer, pyqtSignal
from PyQt5.QtGui import QBrush, QColor, QFont
from PyQt5.QtWidgets import (
    QAction, QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QFormLayout, QGroupBox, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
    QListWidget, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QSpinBox, QSplitter, QTabWidget, QTableWidget, QTableWidgetItem, QToolBar,
    QVBoxLayout, QWidget, QHeaderView, QDialog, QDialogButtonBox,
    QAbstractItemView, QRadioButton, QButtonGroup, QProgressDialog, QListWidgetItem,
    QScrollArea, QMenu,
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure

import delta_seq_core as core

CHANNELS = {"Voltage (SV)": "SV", "Current (SC)": "SC", "Power (SP)": "SP",
            "Sink current (SCN)": "SCN", "Sink power (SPN)": "SPN"}
UNITS = {"SV": "V", "SC": "A", "SP": "W", "SCN": "A", "SPN": "W"}


class InteractiveCanvas(FigureCanvasQTAgg):
    """Matplotlib canvas with mouse-wheel zoom, drag-pan, double-click fit and
    two measurement cursors (C1, C2) with difference read-out.

    View rules
    - The time window (X) you zoom/pan to is kept when the plot is redrawn.
    - Y follows the data that is visible in that window whenever the data
      changes (so edited curves never disappear off-screen).
    - Y zoom/pan you do yourself is kept until the data changes (live plots
      keep it until you double-click / Fit).
    """
    ZOOM = 1.25
    CURSOR_COLORS = ("#d6278f", "#0f9d9a")
    GRAB_PX = 7
    DRAG_PX = 3

    def __init__(self, figsize=(6, 4)):
        self.fig = Figure(figsize=figsize)
        super().__init__(self.fig)
        self.setFocusPolicy(Qt.StrongFocus)
        self.traces: list[dict] = []
        self.cursors_on = False
        self.cursor_t: list[float | None] = [None, None]
        self.active_cursor = 0
        self._cursor_artists: list[list] = [[], []]
        self._drag = None
        self._x_user = None          # time window the user zoomed/panned to
        self._y_user = False         # user changed Y since the last data change
        self.on_readout = None       # callback(html: str)
        self.mpl_connect("scroll_event", self._on_scroll)
        self.mpl_connect("button_press_event", self._on_press)
        self.mpl_connect("button_release_event", self._on_release)
        self.mpl_connect("motion_notify_event", self._on_motion)
        self.mpl_connect("key_press_event", self._on_key)

    # ---- layout (computed once per plot / resize – no jitter while panning) --
    def _relayout(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                self.fig.tight_layout()
            except (ValueError, RuntimeError, AttributeError):
                pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._relayout()
        self.draw_idle()

    # ---- called by subclasses while plotting --------------------------------
    def begin_traces(self):
        self.traces = []
        self._cursor_artists = [[], []]

    def add_trace(self, name, xs, ys, unit="", step=True):
        pts = [(x, y) for x, y in zip(xs, ys)
               if y is not None and not (isinstance(y, float) and math.isnan(y))]
        if pts:
            self.traces.append({"name": name, "xs": [p[0] for p in pts],
                                "ys": [p[1] for p in pts], "unit": unit,
                                "step": step})

    def finish_plot(self):
        """Call after (re)drawing the data."""
        axes = self.fig.axes
        self._y_user = False
        if self._x_user is not None and axes:
            axes[0].set_xlim(self._x_user)
            self._autoscale_y_all()
        self._relayout()
        self._draw_cursors()
        self._update_readout()
        tb = getattr(self, "toolbar", None)
        if tb is not None and hasattr(tb, "update"):
            try:
                tb.update()            # forget the toolbar's stale back/forward views
            except (AttributeError, TypeError):
                pass
        self.draw_idle()

    # ---- view helpers --------------------------------------------------------
    def _primary_axes(self):
        return [a for a in self.fig.axes if not getattr(a, "_is_twin", False)]

    def _data_lines(self, a):
        """Lines that carry data (not cursors, separators or markers)."""
        out = []
        for ln in a.get_lines():
            if not ln.get_visible() or ln.get_transform() != a.transData:
                continue
            if len(ln.get_xdata()) == 0:
                continue
            out.append(ln)
        return out

    def _autoscale_y(self, a):
        """Fit Y to the data that is visible in the current time window."""
        if getattr(a, "_fixed_ylim", None):
            a.set_ylim(a._fixed_ylim); return
        import bisect
        x0, x1 = sorted(a.get_xlim())
        lo, hi = math.inf, -math.inf
        for ln in self._data_lines(a):
            xs = [float(x) for x in ln.get_xdata()]
            ys = [float(y) for y in ln.get_ydata()]
            if not xs or xs[-1] < x0 or xs[0] > x1:
                continue                                    # line not in the window
            i0 = max(bisect.bisect_right(xs, x0) - 1, 0)     # value held into view
            i1 = min(bisect.bisect_left(xs, x1) + 1, len(xs))  # one past the window
            for y in ys[i0:i1]:
                if not math.isnan(y):
                    lo, hi = min(lo, y), max(hi, y)
        for coll in a.collections:                          # tolerance bands
            for path in coll.get_paths():
                for x, y in path.vertices:
                    if x0 <= x <= x1 and not math.isnan(y):
                        lo, hi = min(lo, y), max(hi, y)
        if lo == math.inf:
            return
        pad = (hi - lo) * 0.05 or max(abs(hi) * 0.05, 0.5)
        a.set_ylim(lo - pad, hi + pad)

    def _autoscale_y_all(self):
        for a in self.fig.axes:
            self._autoscale_y(a)

    def reset_view(self):
        """Forget zoom and cursor positions (new file / new project)."""
        self._x_user = None
        self._y_user = False
        self.cursor_t = [None, None]

    def fit(self):
        self._x_user = None
        self._y_user = False
        for a in self.fig.axes:
            a.set_autoscale_on(True)
            a.relim(visible_only=True)
            a.autoscale_view()
            if getattr(a, "_fixed_ylim", None):
                a.set_ylim(a._fixed_ylim)
        self._after_view_change(relayout=True)

    def _after_view_change(self, relayout=False):
        if relayout:
            self._relayout()
        self.draw_idle()

    def _toolbar_busy(self):
        return bool(getattr(getattr(self, "toolbar", None), "mode", ""))

    def toolbar_changed_view(self):
        """Called by the toolbar after its own zoom/pan/back/forward."""
        axes = self.fig.axes
        if axes:
            self._x_user = tuple(axes[0].get_xlim())
            self._y_user = True
        self._relayout()
        self.draw_idle()

    # ---- cursors ---------------------------------------------------------------
    def set_cursors(self, on: bool):
        self.cursors_on = on
        if on:
            self._bring_cursors_into_view()
        self._draw_cursors()
        self._update_readout()
        self.draw_idle()

    def _bring_cursors_into_view(self):
        axes = self._primary_axes()
        if not axes:
            return
        x0, x1 = sorted(axes[0].get_xlim())
        for i, f in enumerate((1 / 3, 2 / 3)):
            t = self.cursor_t[i]
            if t is None or not (x0 <= t <= x1):
                self.cursor_t[i] = x0 + (x1 - x0) * f

    def _init_cursor_positions(self):
        """Give cursors a position if they have none (keeps existing ones)."""
        if None in self.cursor_t:
            axes = self._primary_axes()
            if not axes:
                return
            x0, x1 = sorted(axes[0].get_xlim())
            for i, f in enumerate((1 / 3, 2 / 3)):
                if self.cursor_t[i] is None:
                    self.cursor_t[i] = x0 + (x1 - x0) * f

    def _remove_cursor_artists(self):
        for arts in self._cursor_artists:
            for a in arts:
                try:
                    a.remove()
                except (ValueError, AttributeError, NotImplementedError):
                    pass
        self._cursor_artists = [[], []]

    def _draw_cursors(self):
        from matplotlib.lines import Line2D
        from matplotlib.transforms import blended_transform_factory
        self._remove_cursor_artists()
        axes = self._primary_axes()
        if not self.cursors_on or not axes:
            return
        self._init_cursor_positions()
        for i in range(2):
            t = self.cursor_t[i]
            col = self.CURSOR_COLORS[i]
            lw = 1.8 if i == self.active_cursor else 1.1
            arts = []
            for a in axes:
                # added as plain artists: they never take part in autoscaling
                ln = Line2D([t, t], [0, 1], color=col, lw=lw, zorder=10,
                            transform=blended_transform_factory(a.transData, a.transAxes))
                a.add_artist(ln)
                arts.append(ln)
            tr = blended_transform_factory(axes[0].transData, axes[0].transAxes)
            arts.append(axes[0].text(t, 0.985, f"C{i + 1}", color="white",
                                     fontsize=8, fontweight="bold", va="top",
                                     ha="center", transform=tr, zorder=11, clip_on=True,
                                     bbox=dict(boxstyle="round,pad=0.2", fc=col,
                                               ec="none")))
            self._cursor_artists[i] = arts

    def _move_cursor(self, i, t):
        self.cursor_t[i] = t
        for a in self._cursor_artists[i]:
            if hasattr(a, "set_xdata"):
                a.set_xdata([t, t])
            else:
                a.set_x(t)
        self._update_readout()
        self.draw_idle()

    def _cursor_near(self, ev):
        if not self.cursors_on or ev.inaxes is None:
            return None
        best, best_d = None, self.GRAB_PX
        for i, t in enumerate(self.cursor_t):
            if t is None:
                continue
            px = ev.inaxes.transData.transform((t, 0))[0]
            d = abs(px - ev.x)
            if d <= best_d:
                best, best_d = i, d
        return best

    def _edges(self):
        """Step changes of step signals and every point of measured signals."""
        edges = set()
        for tr in self.traces:
            xs, ys = tr["xs"], tr["ys"]
            if tr.get("step", True):
                edges.update(xs[k] for k in range(len(xs))
                             if k == 0 or k == len(xs) - 1 or ys[k] != ys[k - 1])
            else:
                edges.update(xs)
        return sorted(edges)

    # ---- read-out ----------------------------------------------------------------
    @staticmethod
    def _f(v, unit=""):
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return "–"
        return f"{f'{v:.6g}'} {unit}".strip()

    def _update_readout(self):
        if not self.on_readout:
            return
        if not self.cursors_on or not self.traces:
            self.on_readout("")
            return
        self._init_cursor_positions()
        if None in self.cursor_t:
            self.on_readout("")
            return
        t1, t2 = self.cursor_t
        dt = t2 - t1
        freq = f" &nbsp;(1/Δt = {self._f(1 / abs(dt), 'Hz')})" if dt else ""
        c1, c2 = self.CURSOR_COLORS
        h = ["<table cellspacing='0' cellpadding='2' style='font-size:9pt'>",
             "<tr><th align='left'></th>"
             f"<th style='color:{c1}'>C1</th><th style='color:{c2}'>C2</th>"
             "<th>Δ (C2−C1)</th><th>Min</th><th>Max</th><th>Mean</th><th>RMS</th></tr>",
             f"<tr><td><b>t</b></td><td>{self._f(t1, 's')}</td><td>{self._f(t2, 's')}</td>"
             f"<td colspan='5'><b>{self._f(dt, 's')}</b>{freq}</td></tr>"]
        for tr in self.traces:
            u = tr["unit"]
            if tr.get("step", True):
                v1 = core.step_value_at(tr["xs"], tr["ys"], t1)
                v2 = core.step_value_at(tr["xs"], tr["ys"], t2)
                st = core.step_stats(tr["xs"], tr["ys"], t1, t2) or {}
            else:
                v1 = core.linear_value_at(tr["xs"], tr["ys"], t1)
                v2 = core.linear_value_at(tr["xs"], tr["ys"], t2)
                st = core.linear_stats(tr["xs"], tr["ys"], t1, t2) or {}
            dv = None if v1 is None or v2 is None else v2 - v1
            h.append(f"<tr><td><b>{tr['name']}</b></td><td>{self._f(v1, u)}</td>"
                     f"<td>{self._f(v2, u)}</td><td><b>{self._f(dv, u)}</b></td>"
                     f"<td>{self._f(st.get('min'), u)}</td><td>{self._f(st.get('max'), u)}</td>"
                     f"<td>{self._f(st.get('mean'), u)}</td><td>{self._f(st.get('rms'), u)}</td></tr>")
        h.append("</table>")
        self.on_readout("".join(h))

    # ---- zoom ----------------------------------------------------------------------
    def _axes_at(self, x, y):
        return [a for a in self.fig.axes if a.bbox.contains(x, y)]

    def zoom_at(self, x, y, steps, x_only=False, y_only=False):
        """Zoom around pixel (x, y). steps > 0 zooms in."""
        hit = self._axes_at(x, y)
        if not hit:
            return
        f = self.ZOOM ** (-steps)
        if not y_only:
            a = hit[0]
            xd = a.transData.inverted().transform((x, y))[0]
            x0, x1 = a.get_xlim()
            n0, n1 = xd - (xd - x0) * f, xd + (x1 - xd) * f
            if abs(n1 - n0) > 1e-12 * max(1.0, abs(xd)):
                a.set_xlim(n0, n1)
                self._x_user = tuple(a.get_xlim())
        if x_only:
            if not self._y_user:
                self._autoscale_y_all()        # time zoom: Y follows the window
        else:
            for a in hit:
                if getattr(a, "_fixed_ylim", None):
                    continue
                yd = a.transData.inverted().transform((x, y))[1]
                y0, y1 = a.get_ylim()
                n0, n1 = yd - (yd - y0) * f, yd + (y1 - yd) * f
                if abs(n1 - n0) > 1e-12 * max(1.0, abs(yd)):
                    a.set_ylim(n0, n1)
            self._y_user = True
        self._schedule_relayout()
        self.draw_idle()

    def _schedule_relayout(self):
        """Re-fit margins shortly after zooming stops (tick labels change width)."""
        t = getattr(self, "_relayout_timer", None)
        if t is None:
            try:
                t = QTimer(self); t.setSingleShot(True)
                t.timeout.connect(lambda: (self._relayout(), self.draw_idle()))
                self._relayout_timer = t
            except TypeError:
                return
        t.start(300)

    def wheelEvent(self, event):
        """Handle the wheel ourselves: matplotlib ignores horizontal wheel events,
        and Qt turns Shift+wheel into a horizontal wheel on Windows/Linux."""
        d = event.angleDelta()
        delta = d.y() or d.x()
        if not delta:
            event.ignore(); return
        mods = event.modifiers()
        pos = event.position() if hasattr(event, "position") else event.pos()
        x, y = self.mouseEventCoords(pos)
        self.zoom_at(x, y, delta / 120.0,
                     x_only=bool(mods & Qt.ControlModifier),
                     y_only=bool(mods & Qt.ShiftModifier))
        event.accept()

    def _on_scroll(self, ev):          # used when the wheel arrives via matplotlib
        mods = QApplication.keyboardModifiers()
        steps = getattr(ev, "step", 0) or (1 if ev.button == "up" else -1)
        self.zoom_at(ev.x, ev.y, steps,
                     x_only=bool(mods & Qt.ControlModifier),
                     y_only=bool(mods & Qt.ShiftModifier))

    # ---- mouse / keyboard -----------------------------------------------------------
    def _on_press(self, ev):
        if self._toolbar_busy() or ev.inaxes is None:
            return
        if ev.dblclick and ev.button == 1:
            self._drag = None
            self.fit(); return
        if ev.button == 1:
            i = self._cursor_near(ev)
            if i is not None:
                self._drag = ("cursor", i)
                self.active_cursor = i
                self._draw_cursors(); self.draw_idle()
                return
        if ev.button == 3 and self.cursors_on and ev.xdata is not None:
            # right click: put the active cursor here, then switch active cursor
            self._move_cursor(self.active_cursor, ev.xdata)
            self.active_cursor = 1 - self.active_cursor
            self._draw_cursors(); self.draw_idle()
            return
        if ev.button in (1, 2):
            self._drag = ["pan", ev.x, ev.y,
                          [(a, a.get_xlim(), a.get_ylim(), a.bbox.contains(ev.x, ev.y))
                           for a in self.fig.axes], False, False]

    def _on_motion(self, ev):
        if self._drag is None:
            if self.cursors_on and not self._toolbar_busy():
                if self._cursor_near(ev) is not None:
                    self.setCursor(Qt.SizeHorCursor)
                else:
                    self.unsetCursor()
            return
        if self._drag[0] == "cursor":
            axes = self._primary_axes()
            if axes:
                t = axes[0].transData.inverted().transform((ev.x, ev.y))[0]
                self._move_cursor(self._drag[1], t)
            return
        _, x0, y0, state, moved, moved_y = self._drag
        dx, dy = ev.x - x0, ev.y - y0
        if not moved and abs(dx) < self.DRAG_PX and abs(dy) < self.DRAG_PX:
            return                                   # a click, not a drag
        self._drag[4] = True
        if abs(dy) >= self.DRAG_PX:
            self._drag[5] = True
        for i, (a, xl, yl, inside) in enumerate(state):
            w, h = a.bbox.width or 1, a.bbox.height or 1
            if i == 0:
                sx = (xl[1] - xl[0]) * dx / w
                a.set_xlim(xl[0] - sx, xl[1] - sx)
            if inside and self._drag[5] and not getattr(a, "_fixed_ylim", None):
                sy = (yl[1] - yl[0]) * dy / h
                a.set_ylim(yl[0] - sy, yl[1] - sy)
        self.draw_idle()

    def _on_release(self, ev):
        drag, self._drag = self._drag, None
        if drag and drag[0] == "pan" and drag[4]:
            axes = self.fig.axes
            if axes:
                self._x_user = tuple(axes[0].get_xlim())
            if drag[5]:
                self._y_user = True
            self._schedule_relayout()
            self.draw_idle()

    def _on_key(self, ev):
        if not self.cursors_on or ev.key not in ("left", "right", "1", "2", "c"):
            return
        if ev.key in ("1", "2"):
            self.active_cursor = int(ev.key) - 1
            self._draw_cursors(); self.draw_idle(); return
        if ev.key == "c":                      # put both cursors back in view
            self.cursor_t = [None, None]
            self._draw_cursors(); self._update_readout(); self.draw_idle(); return
        edges = self._edges()
        t = self.cursor_t[self.active_cursor]
        if not edges or t is None:
            return
        import bisect
        eps = 1e-12
        if ev.key == "right":
            k = bisect.bisect_right(edges, t + eps)
            if k < len(edges): self._move_cursor(self.active_cursor, edges[k])
        else:
            k = bisect.bisect_left(edges, t - eps) - 1
            if k >= 0: self._move_cursor(self.active_cursor, edges[k])


class NavToolbar(NavigationToolbar2QT):
    """Matplotlib toolbar whose Home = Fit and whose zoom/pan are remembered."""

    def home(self, *args):
        self.canvas.fit()

    def release_zoom(self, event):
        super().release_zoom(event)
        self.canvas.toolbar_changed_view()

    def release_pan(self, event):
        super().release_pan(event)
        self.canvas.toolbar_changed_view()

    def back(self, *args):
        super().back(*args)
        self.canvas.toolbar_changed_view()

    def forward(self, *args):
        super().forward(*args)
        self.canvas.toolbar_changed_view()


class PlotPanel(QWidget):
    """Toolbar + interactive canvas + cursor read-out."""
    HELP = ("Wheel: zoom · Ctrl+wheel: time only · Shift+wheel: Y only · "
            "Drag: pan · Double-click or Home: fit · Cursors: drag the lines, "
            "right-click places the active cursor, ←/→ jump to the next edge, "
            "1/2 select cursor, C recentres")

    def __init__(self, canvas: InteractiveCanvas, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0)
        tb = NavToolbar(canvas, self)
        tb.addSeparator()
        a = QAction("Fit", self); a.setToolTip("Show everything (double-click)")
        a.triggered.connect(canvas.fit); tb.addAction(a)
        self.act_cur = QAction("Cursors", self); self.act_cur.setCheckable(True)
        self.act_cur.setToolTip("Two measurement cursors with difference read-out")
        self.act_cur.toggled.connect(self._toggle); tb.addAction(self.act_cur)
        a = QAction("Copy values", self)
        a.setToolTip("Copy the cursor read-out to the clipboard")
        a.triggered.connect(self._copy); tb.addAction(a)
        v.addWidget(tb)
        v.addWidget(canvas, 1)
        self.lbl = QLabel(); self.lbl.setTextFormat(Qt.RichText)
        self.lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.lbl.setVisible(False)
        v.addWidget(self.lbl)
        hint = QLabel(self.HELP); hint.setWordWrap(True)
        hint.setStyleSheet("color: grey; font-size: 8pt")
        v.addWidget(hint)
        canvas.on_readout = self._readout

    def _toggle(self, on):
        self.canvas.set_cursors(on)
        if on:
            self.canvas.setFocus()

    def _readout(self, html):
        self.lbl.setText(html)
        self.lbl.setVisible(bool(html))

    def _copy(self):
        doc = self.lbl.text()
        import re as _re
        text = _re.sub(r"</t[dh]>", "\t", doc)
        text = _re.sub(r"</tr>", "\n", text)
        text = _re.sub(r"<[^>]+>|&nbsp;", "", text)
        QApplication.clipboard().setText(text.strip())


class PlotCanvas(InteractiveCanvas):
    def __init__(self):
        super().__init__()
        self.ax = self.fig.add_subplot(111)

    def plot(self, points, channel, repeat, seg_bounds, selected, markers=(),
             lead_waits=0):
        ax = self.ax
        ax.clear()
        self.begin_traces()
        passes = 1 if repeat == 1 else (2 if repeat == 0 else min(repeat, 3))
        t, ts, vs = 0.0, [], []
        for p in range(passes):
            prev = vs[-1] if vs else None
            for k, (v, dt) in enumerate(points):
                if p > 0 and k < lead_waits and prev is not None:
                    v = prev               # a wait keeps the output where it was
                ts.append(t); vs.append(v)
                t += dt
        if vs:
            ts.append(t); vs.append(vs[-1])
            ax.step(ts, vs, where="post", lw=1.6, color="#1f6fb2")
            self.add_trace(channel, ts, vs, UNITS.get(channel, ""))
        one = sum(dt for _, dt in points)
        for p in range(1, passes):
            ax.axvline(p * one, color="grey", ls="--", lw=0.8)
        if selected is not None and 0 <= selected < len(seg_bounds):
            a, b = seg_bounds[selected]
            ax.axvspan(a, b, color="orange", alpha=0.2)
        for p in range(passes):
            for mt, mlabel in markers:
                x = mt + p * one
                ax.axvline(x, color="#9467bd", ls=":", lw=1.2)
                ax.text(x, 0.02, f" {mlabel}", color="#9467bd", fontsize=7,
                        rotation=90, va="bottom",
                        transform=ax.get_xaxis_transform())
        if not vs:
            ax.text(0.5, 0.5, "No segments – add one on the left",
                    ha="center", va="center", transform=ax.transAxes, color="grey")
        ax.set_xlabel("Time [s]")
        ax.set_ylabel(f"{channel} [{UNITS.get(channel, '')}]")
        title = "Preview"
        if repeat == 0:
            title += " (infinite loop – 2 passes shown)"
        elif repeat > 1:
            title += f" ({repeat} passes, {passes} shown)"
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        self.finish_plot()


# --------------------------------------------------------------------------
# Segment parameter editors (shared by main window and child dialogs)
# --------------------------------------------------------------------------
def build_segment_form(form: QFormLayout, seg: dict, on_changed, parent):
    """Fill `form` with editors for `seg`; edits are written into `seg`
    and `on_changed()` is called after every change."""
    kind = seg["type"]
    if kind == "Table":
        _build_table_editor(form, seg, on_changed)
        return

    if kind == "Combine":
        cb = QComboBox(); cb.addItems(core.COMBINE_OPS)
        cb.setCurrentText(seg["op"])
        def op_changed(text):
            seg["op"] = text; on_changed()
        cb.currentTextChanged.connect(op_changed)
        form.addRow("Operation", cb)

    for key, (label, options) in core.SEGMENT_CHOICES.get(kind, {}).items():
        cbx = QComboBox(); cbx.addItems(options)
        cbx.setCurrentText(seg.get(key, options[0]))
        def choice_changed(text, k=key):
            seg[k] = text; on_changed()
        cbx.currentTextChanged.connect(choice_changed)
        form.addRow(label, cbx)

    for key, label, _d, is_int in core.SEGMENT_TYPES[kind]:
        if is_int:
            w = QSpinBox(); w.setRange(1, 10000)
        else:
            w = QDoubleSpinBox(); w.setDecimals(4)
            w.setRange(-100000, 100000)
            w.setKeyboardTracking(False)
            if key == "dt": w.setSingleStep(0.01); w.setRange(0.001, 100000)
            if key == "duty": w.setRange(0, 100)
            if key in ("duration", "period", "freq"): w.setMinimum(0)
            if key in ("duty_start", "duty_end"): w.setRange(0, 100)
            if key in ("tau", "preview"): w.setMinimum(0.001)
        w.setValue(seg[key])
        def changed(v, k=key):
            seg[k] = v; on_changed()
        w.valueChanged.connect(changed)
        form.addRow(label, w)

    if kind in core.WAIT_TYPES:
        what = ("the selected digital input has the chosen level"
                if kind == "Wait for input" else "a TRIGger:IMMediate command arrives")
        note = QLabel(f"On the supply the sequence pauses here until {what}. The output "
                      f"keeps its last value. The wait time above is only used for the "
                      f"preview plot.")
        note.setWordWrap(True); note.setStyleSheet("color: grey")
        form.addRow(note)
    if kind == "Battery":
        note = QLabel("Approximate Li-ion style discharge shape (fast initial drop, "
                      "plateau, knee to cut-off). Adjust the voltages for your cell or pack.")
        note.setWordWrap(True); note.setStyleSheet("color: grey")
        form.addRow(note)

    if kind == "Combine":
        child_labels = {}
        for slot, name in (("a", "Signal A"), ("b", "Signal B")):
            box = QWidget(); h = QHBoxLayout(box); h.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(core.describe_segment(seg[slot])); lbl.setWordWrap(True)
            child_labels[slot] = lbl
            btn = QPushButton("Edit…"); btn.setFixedWidth(60)
            def edit(_=False, slot=slot, name=name):
                dlg = SegmentDialog(seg[slot], parent, f"Edit {name}")
                if dlg.exec_() == QDialog.Accepted:
                    seg[slot] = dlg.seg
                    child_labels[slot].setText(core.describe_segment(dlg.seg))
                    on_changed()
            btn.clicked.connect(edit)
            h.addWidget(lbl, 1); h.addWidget(btn)
            form.addRow(name, box)
        def swap():
            seg["a"], seg["b"] = seg["b"], seg["a"]
            for slot in ("a", "b"):
                child_labels[slot].setText(core.describe_segment(seg[slot]))
            on_changed()
        b = QPushButton("Swap A ↔ B"); b.clicked.connect(swap)
        form.addRow(b)
        note = QLabel("Duration = longer of A and B; the shorter one holds its "
                      "last value. Result is sampled every 'Sample time'.")
        note.setWordWrap(True); note.setStyleSheet("color: grey")
        form.addRow(note)


def _build_table_editor(form: QFormLayout, seg: dict, on_changed):
    tbl = QTableWidget(len(seg["points"]), 3)
    tbl.setHorizontalHeaderLabels(["Value", "Hold [s]", "Starts at [s]"])
    tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    tbl.setMinimumHeight(200)
    for r, (v, t) in enumerate(seg["points"]):
        tbl.setItem(r, 0, QTableWidgetItem(f"{v:g}"))
        tbl.setItem(r, 1, QTableWidgetItem(f"{t:g}"))

    def fill_times():
        tbl.blockSignals(True)
        acc = 0.0
        for r in range(tbl.rowCount()):
            it = QTableWidgetItem(f"{acc:.6g}")
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it.setForeground(QBrush(QColor(128, 128, 128)))
            tbl.setItem(r, 2, it)
            try:
                acc += float(tbl.item(r, 1).text())
            except (AttributeError, ValueError):
                pass
        tbl.blockSignals(False)
    fill_times()

    def read_back(*_):
        pts = []
        for r in range(tbl.rowCount()):
            try:
                pts.append([float(tbl.item(r, 0).text()),
                            float(tbl.item(r, 1).text())])
            except (AttributeError, ValueError):
                pass                       # skip incomplete / non-numeric rows
        seg["points"] = pts
        fill_times()
        on_changed()

    def add_row():
        r = tbl.currentRow() + 1 if tbl.currentRow() >= 0 else tbl.rowCount()
        last = [0, 1]
        if r > 0:
            try:
                last = [float(tbl.item(r - 1, 0).text()), float(tbl.item(r - 1, 1).text())]
            except (AttributeError, ValueError):
                pass
        tbl.blockSignals(True)
        tbl.insertRow(r)
        tbl.setItem(r, 0, QTableWidgetItem(f"{last[0]:g}"))
        tbl.setItem(r, 1, QTableWidgetItem(f"{last[1]:g}"))
        tbl.blockSignals(False)
        read_back()

    def del_rows():
        for r in sorted({i.row() for i in tbl.selectedIndexes()}, reverse=True):
            tbl.removeRow(r)
        read_back()

    def paste():
        text = QApplication.clipboard().text()
        rows = []
        for ln in text.splitlines():
            if not ln.strip():
                continue
            if "\t" in ln:                       # Excel / LibreOffice copy
                cells = ln.split("\t")
            elif ";" in ln:                      # European CSV
                cells = ln.split(";")
            elif "," in ln and not (re.search(r"\s", ln.strip()) and all(
                    re.fullmatch(r"[-+]?\d+(,\d+)?", tok) for tok in ln.split())):
                cells = ln.split(",")            # "1.5,2" or "1.5, 2"
            else:
                cells = ln.split()               # "1.5 2" or decimal comma "1,5 2"
            cells = [c.strip().replace(",", ".") for c in cells if c.strip()]
            if len(cells) >= 2 and all(re.fullmatch(r"[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?", c)
                                       for c in cells[:2]):
                rows.append(cells)
        if not rows:
            QMessageBox.information(tbl, "Paste", "No rows with two numbers (value, hold "
                                    "time) found on the clipboard.")
            return
        tbl.blockSignals(True)
        tbl.setRowCount(len(rows))
        for r, (v, t, *_) in enumerate(rows):
            tbl.setItem(r, 0, QTableWidgetItem(v))
            tbl.setItem(r, 1, QTableWidgetItem(t))
        tbl.blockSignals(False)
        read_back()

    tbl.itemChanged.connect(read_back)
    btns = QWidget(); h = QHBoxLayout(btns); h.setContentsMargins(0, 0, 0, 0)
    for text, fn in [("Add row", add_row), ("Delete rows", del_rows),
                     ("Paste (Excel/CSV)", paste)]:
        b = QPushButton(text); b.clicked.connect(fn); h.addWidget(b)
    form.addRow(tbl)
    form.addRow(btns)


class SegmentDialog(QDialog):
    """Edit a child signal of a Combine segment (any type, can be nested)."""

    def __init__(self, seg: dict, parent=None, title="Edit signal"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(560, 620)
        self.seg = copy.deepcopy(seg)
        v = QVBoxLayout(self)
        top = QFormLayout()
        self.cb = QComboBox(); self.cb.addItems(core.SEGMENT_TYPES)
        self.cb.setCurrentText(self.seg["type"])
        self.cb.currentTextChanged.connect(self._type_changed)
        top.addRow("Signal type", self.cb)
        v.addLayout(top)
        self.holder = QWidget(); self.form = QFormLayout(self.holder)
        v.addWidget(self.holder)
        self.canvas = PlotCanvas(); self.canvas.setMinimumHeight(220)
        v.addWidget(self.canvas, 1)
        self.lbl_err = QLabel()
        v.addWidget(self.lbl_err)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self._rebuild()

    def _type_changed(self, kind):
        self.seg = core.default_segment(kind)
        self._rebuild()

    def _rebuild(self):
        while self.form.rowCount():
            self.form.removeRow(0)
        build_segment_form(self.form, self.seg, self._preview, self)
        self._preview()

    def _preview(self):
        try:
            pts = core.segment_preview(self.seg)
            self.lbl_err.setText("")
        except (ValueError, ZeroDivisionError) as e:
            pts = []; self.lbl_err.setText(str(e))
        self.canvas.plot(pts, "SV", 1, [], None)
        self.canvas.ax.set_ylabel("Value"); self.canvas.ax.set_title("Signal preview")
        self.canvas.draw_idle()


class SampleImportDialog(QDialog):
    """Load timestamp/value samples and convert them to a Table segment."""

    def __init__(self, parent, cfg):
        super().__init__(parent)
        self.base_cfg = copy.deepcopy(cfg)
        channel = cfg.channel
        self.setWindowTitle("Import samples")
        self.resize(1100, 720)
        self.rows: list[list[str]] = []
        self.samples: list[tuple[float, float]] = []
        self.points: list[list[float]] = []
        self.path = ""

        main = QHBoxLayout(self)
        left = QVBoxLayout(); main.addLayout(left, 0)

        # --- file
        gf = QGroupBox("1. Sample file"); ff = QFormLayout(gf)
        hb = QHBoxLayout()
        self.ed_path = QLineEdit(); self.ed_path.setReadOnly(True)
        b = QPushButton("Browse…"); b.clicked.connect(self.browse)
        hb.addWidget(self.ed_path, 1); hb.addWidget(b)
        ff.addRow(hb)
        self.chk_header = QCheckBox("First row is a header")
        self.cb_tcol = QComboBox(); self.cb_vcol = QComboBox()
        ff.addRow(self.chk_header)
        ff.addRow("Time column", self.cb_tcol)
        ff.addRow("Value column", self.cb_vcol)
        self.tbl_raw = QTableWidget(); self.tbl_raw.setMaximumHeight(140)
        self.tbl_raw.setEditTriggers(QAbstractItemView.NoEditTriggers)
        ff.addRow(self.tbl_raw)
        left.addWidget(gf)

        # --- time
        gt = QGroupBox("2. Time"); ft = QFormLayout(gt)
        self.cb_unit = QComboBox(); self.cb_unit.addItems(core.TIME_UNITS)
        self.cb_unit.setCurrentText("ms")
        self.cb_tmode = QComboBox()
        self.cb_tmode.addItems(["Timestamp (time of each sample)",
                                "Duration (hold time of each sample)"])
        self.chk_zero = QCheckBox("Start at t = 0 (shift first timestamp)")
        self.chk_zero.setChecked(True)
        self.sp_last = self._dspin(0.001, 1e6, 3, 1.0)
        ft.addRow("Time unit", self.cb_unit)
        ft.addRow("Time column is", self.cb_tmode)
        ft.addRow(self.chk_zero)
        ft.addRow("Hold last value [s]", self.sp_last)
        left.addWidget(gt)

        # --- signal shape
        gm = QGroupBox("3. Signal shape between samples"); fm = QFormLayout(gm)
        self.rb_step = QRadioButton("Step – hold each value until the next sample")
        self.rb_cont = QRadioButton("Continuous – linear interpolation, resampled")
        self.rb_step.setChecked(True)
        grp = QButtonGroup(self); grp.addButton(self.rb_step); grp.addButton(self.rb_cont)
        fm.addRow(self.rb_step); fm.addRow(self.rb_cont)
        self.sp_dt = self._dspin(1, 1e7, 1, 100.0)
        b_fit = QPushButton("Fit to 2000 steps"); b_fit.clicked.connect(self.fit_steps)
        fm.addRow("Resample step [ms]", self._row(self.sp_dt, b_fit))
        self.sp_minhold = self._dspin(1, 1e7, 1, 1.0)
        fm.addRow("Minimum hold [ms]", self.sp_minhold)
        self.sp_scale = self._dspin(-1e6, 1e6, 4, 1.0)
        self.sp_offset = self._dspin(-1e6, 1e6, 3, 0.0)
        fm.addRow("Value × scale + offset", self._row(self.sp_scale, self.sp_offset))
        left.addWidget(gm)

        # --- output
        go = QGroupBox("4. Output"); fo = QFormLayout(go)
        self.cb_ch = QComboBox(); self.cb_ch.addItems(CHANNELS)
        self.cb_ch.setCurrentIndex(list(CHANNELS.values()).index(channel))
        self.cb_rep = QComboBox()
        self.cb_rep.addItems(["Play once", "Repeat N times", "Continuous loop (∞)"])
        self.sp_n = QSpinBox(); self.sp_n.setRange(2, 65535); self.sp_n.setValue(2)
        self.cb_target = QComboBox()
        self.cb_target.addItems(["Replace current project", "Append as segment"])
        fo.addRow("Controlled", self.cb_ch)
        fo.addRow("Playback", self._row(self.cb_rep, self.sp_n))
        fo.addRow("Insert", self.cb_target)
        left.addWidget(go)
        left.addStretch()

        # --- right: preview
        right = QVBoxLayout(); main.addLayout(right, 1)
        self.canvas = PlotCanvas()
        right.addWidget(PlotPanel(self.canvas), 1)
        self.lbl = QLabel("Choose a file with time and value columns."); self.lbl.setWordWrap(True)
        right.addWidget(self.lbl)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Import")
        self.bb.accepted.connect(self.accept); self.bb.rejected.connect(self.reject)
        right.addWidget(self.bb)

        for w in (self.chk_header, self.chk_zero, self.rb_step, self.rb_cont):
            w.toggled.connect(self.update_preview)
        for w in (self.cb_tcol, self.cb_vcol, self.cb_unit, self.cb_tmode,
                  self.cb_ch, self.cb_rep, self.cb_target):
            w.currentIndexChanged.connect(self.update_preview)
        for w in (self.sp_last, self.sp_dt, self.sp_minhold, self.sp_scale,
                  self.sp_offset):
            w.valueChanged.connect(self.update_preview)
        self.sp_n.valueChanged.connect(self.update_preview)
        self.update_preview()

    @staticmethod
    def _dspin(lo, hi, dec, val):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setValue(val); s.setKeyboardTracking(False)
        return s

    @staticmethod
    def _row(*ws):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in ws: h.addWidget(x)
        return w

    def browse(self):
        fn, _ = _open_dialog(
            self, "Open sample file", "",
            "Samples (*.csv *.txt *.tsv *.dat *.xlsx *.xlsm);;All files (*)")
        if fn:
            self.load(fn)

    def load(self, fn):
        try:
            self.rows = core.read_table_file(fn)
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Read failed", str(e)); return
        if not self.rows:
            QMessageBox.warning(self, "Read failed", "The file is empty."); return
        self.path = fn
        self.ed_path.setText(fn)
        hdr = core.detect_header(self.rows)
        ncol = max(len(r) for r in self.rows[:50])
        names = [(self.rows[0][i] if hdr and i < len(self.rows[0]) else f"Column {i + 1}")
                 for i in range(ncol)]
        for cb in (self.cb_tcol, self.cb_vcol):
            cb.blockSignals(True); cb.clear(); cb.addItems(names); cb.blockSignals(False)
        self.cb_vcol.setCurrentIndex(1 if ncol > 1 else 0)
        # guess the time unit from the header text
        guess = core.guess_time_unit(names[0])
        if guess:
            self.cb_unit.setCurrentText(guess)
        if any(r and ":" in r[0] for r in self.rows[1 if hdr else 0:6]):
            self.cb_unit.setCurrentText("hh:mm:ss / date-time")
        self.chk_header.blockSignals(True); self.chk_header.setChecked(hdr)
        self.chk_header.blockSignals(False)
        show = self.rows[:8]
        self.tbl_raw.setRowCount(len(show)); self.tbl_raw.setColumnCount(ncol)
        for r, row in enumerate(show):
            for c, val in enumerate(row):
                self.tbl_raw.setItem(r, c, QTableWidgetItem(val))
        self.update_preview()

    def options(self) -> core.SampleImportOptions:
        return core.SampleImportOptions(
            time_is_duration=self.cb_tmode.currentIndex() == 1,
            zero_start=self.chk_zero.isChecked(),
            continuous=self.rb_cont.isChecked(),
            resample_dt=self.sp_dt.value() / 1000.0,
            last_hold=self.sp_last.value(),
            min_hold=self.sp_minhold.value() / 1000.0,
            scale=self.sp_scale.value(), offset=self.sp_offset.value())

    def repeat(self) -> int:
        i = self.cb_rep.currentIndex()
        return 1 if i == 0 else (self.sp_n.value() if i == 1 else 0)

    def channel(self) -> str:
        return CHANNELS[self.cb_ch.currentText()]

    def fit_steps(self):
        if len(self.samples) < 2: return
        span = self.samples[-1][0] - self.samples[0][0]
        dt = max(0.001, span / 950)               # ~2 steps per point + margin
        self.sp_dt.setValue(math.ceil(dt * 1000))
        self.rb_cont.setChecked(True)

    def update_preview(self, *_):
        self.sp_dt.setEnabled(self.rb_cont.isChecked())
        self.sp_minhold.setEnabled(self.rb_step.isChecked())
        self.sp_n.setEnabled(self.cb_rep.currentIndex() == 1)
        clock = self.cb_unit.currentText() == "hh:mm:ss / date-time"
        if clock and not self.chk_zero.isChecked():
            self.chk_zero.blockSignals(True); self.chk_zero.setChecked(True)
            self.chk_zero.blockSignals(False)
        self.chk_zero.setEnabled(not clock)        # clock times always start at 0
        ok_btn = self.bb.button(QDialogButtonBox.Ok)
        self.points = []
        ax = self.canvas.ax
        if not self.rows:
            ok_btn.setEnabled(False); return
        if getattr(self, "_shown_path", None) != self.path:      # new file: fit view
            self._shown_path = self.path
            self.canvas.reset_view()
        try:
            self.samples, skipped = core.extract_samples(
                self.rows, self.cb_tcol.currentIndex(), self.cb_vcol.currentIndex(),
                self.cb_unit.currentText(), self.chk_header.isChecked())
            self.points, warns = core.samples_to_points(self.samples, self.options())
        except (ValueError, ZeroDivisionError) as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
            ok_btn.setEnabled(False); return
        ch = self.channel()
        self.canvas.plot([tuple(p) for p in self.points], ch, self.repeat(), [], None)
        o = self.options()
        if self.samples:
            t0 = 0 if not o.zero_start or o.time_is_duration else self.samples[0][0]
            if o.time_is_duration:
                ts, acc = [], 0.0
                for d, _v in self.samples:
                    ts.append(acc); acc += d
            else:
                ts = [t - t0 for t, _ in self.samples]
            sv = [v * o.scale + o.offset for _, v in self.samples]
            order = sorted(range(len(ts)), key=ts.__getitem__)
            ts = [ts[i] for i in order]; sv = [sv[i] for i in order]
            ax.plot(ts, sv, "o", ms=3, color="#ff7f0e", label="samples")
            ax.legend(loc="best", fontsize=8)
            self.canvas.add_trace("samples", ts, sv, UNITS.get(ch, ""), step=False)
            if self.canvas._x_user is not None:
                self.canvas._autoscale_y_all()
            self.canvas._update_readout()
            self.canvas.draw_idle()
        # compile with the editor's settings (device, decimals, compact ramps …)
        test = copy.deepcopy(self.base_cfg)
        test.channel, test.repeat = ch, self.repeat()
        seg = {"type": "Table", "points": self.points}
        test.segments = [seg] if self.cb_target.currentIndex() == 0 \
            else test.segments + [seg]
        comp = core.compile_sequence(test)
        n_steps = len(comp.steps)
        dur = sum(p[1] for p in self.points)
        msg = [f"{len(self.samples)} samples → {len(self.points)} points → "
               f"<b>{n_steps} steps</b> (max {core.MAX_STEPS}) · {dur:.3f} s per pass"]
        if skipped:
            msg.append(f"{skipped} row(s) without numeric time/value were skipped.")
        msg += warns
        too_many = [e for e in comp.errors if "max 2000" in e]
        other = [e for e in comp.errors if "max 2000" not in e]
        if too_many:
            msg.append("<b>Too many steps</b> – use Continuous with a larger resample "
                       "step (or 'Fit to 2000 steps'), a larger minimum hold, or turn on "
                       "Compact ramps in the main window.")
        msg += [f"<b>Error:</b> {e}" for e in other]
        self.lbl.setText("<br>".join(msg))
        ok_btn.setEnabled(bool(self.points) and not comp.errors)


class ExportSamplesDialog(QDialog):
    """Export a (simulated) sequence as time/value samples (CSV, TXT, Excel)."""

    def __init__(self, parent, provider, title: str, default_name: str,
                 can_passes: bool):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(620, 560)
        self.provider = provider          # passes -> SimResult
        self.default_name = default_name
        self._cache: dict[int, core.SimResult] = {}
        self.header, self.rows = [], []
        f = QFormLayout(self)
        self.cb_unit = QComboBox(); self.cb_unit.addItems(["µs", "ms", "s", "min"])
        self.cb_unit.setCurrentText("s")
        self.cb_style = QComboBox()
        self.cb_style.addItems(["Exact steps (2 rows at each change)",
                                "Change points only (1 row per change)",
                                "Fixed sample interval"])
        self.sp_dt = QDoubleSpinBox(); self.sp_dt.setRange(0.001, 1e7)
        self.sp_dt.setDecimals(3); self.sp_dt.setValue(10); self.sp_dt.setSuffix(" ms")
        self.sp_pass = QSpinBox(); self.sp_pass.setRange(1, 1000)
        self.sp_pass.setEnabled(can_passes)
        self.chk_changing = QCheckBox("Only channels that change")
        self.chk_changing.setChecked(True)
        self.cb_delim = QComboBox(); self.cb_delim.addItems(["Comma ,", "Semicolon ;", "Tab"])
        f.addRow("Time unit", self.cb_unit)
        f.addRow("Rows", self.cb_style)
        f.addRow("Sample interval", self.sp_dt)
        f.addRow("Passes (repeats)", self.sp_pass)
        f.addRow(self.chk_changing)
        f.addRow("CSV separator", self.cb_delim)
        self.lbl = QLabel(); self.lbl.setWordWrap(True)
        f.addRow(self.lbl)
        self.txt = QPlainTextEdit(); self.txt.setReadOnly(True)
        self.txt.setFont(QFont("Consolas", 9))
        f.addRow(self.txt)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save); bb.rejected.connect(self.reject)
        self.btn_save = bb.button(QDialogButtonBox.Save)
        f.addRow(bb)
        for w in (self.cb_unit, self.cb_style, self.cb_delim):
            w.currentIndexChanged.connect(self.refresh_preview)
        self.sp_dt.valueChanged.connect(self.refresh_preview)
        self.sp_pass.valueChanged.connect(self.refresh_preview)
        self.chk_changing.toggled.connect(self.refresh_preview)
        self.refresh_preview()

    def _delim(self):
        return {0: ",", 1: ";", 2: "\t"}[self.cb_delim.currentIndex()]

    def refresh_preview(self, *_):
        self.sp_dt.setEnabled(self.cb_style.currentIndex() == 2)
        n = self.sp_pass.value()
        try:
            if n not in self._cache:
                QApplication.setOverrideCursor(Qt.WaitCursor)
                try:
                    self._cache[n] = self.provider(n)
                finally:
                    QApplication.restoreOverrideCursor()
            res = self._cache[n]
            traces = dict(res.traces)
            if self.chk_changing.isChecked():
                ch = {k: v for k, v in traces.items() if len({x for _, x in v}) > 1}
                traces = ch or {k: traces[k] for k in list(traces)[:1]}
            style = ("steps", "changes", "fixed")[self.cb_style.currentIndex()]
            self.header, self.rows = core.traces_to_table(
                traces, res.end_time, style, self.sp_dt.value() / 1000.0,
                self.cb_unit.currentText())
        except ValueError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
            self.btn_save.setEnabled(False); return
        self.btn_save.setEnabled(bool(self.rows))
        self.lbl.setText(f"{len(self.rows)} rows × {len(self.header)} columns · "
                         f"{res.end_time:.6g} s · {res.stop_reason}")
        d = self._delim()
        lines = [d.join(self.header)] + [d.join(f"{x:g}" for x in r)
                                         for r in self.rows[:200]]
        if len(self.rows) > 200:
            lines.append(f"… {len(self.rows) - 200} more rows")
        self.txt.setPlainText("\n".join(lines))

    def save(self):
        fn, flt = _save_dialog(
            self, "Export samples", f"{self.default_name}_samples.csv",
            "CSV (*.csv);;Text (*.txt);;Excel (*.xlsx)")
        if not fn: return
        if "xlsx" in flt and not fn.lower().endswith(".xlsx"):
            fn += ".xlsx"
        try:
            core.write_table_file(fn, self.header, self.rows, self._delim())
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Export failed", str(e)); return
        self.accept()


class ImportCanvas(InteractiveCanvas):
    """Multi-channel plot of a simulated (imported) sequence."""
    COLORS = {"SV": "#1f6fb2", "SC": "#d62728", "SP": "#2ca02c",
              "SCN": "#9467bd", "SPN": "#8c564b"}

    @staticmethod
    def _xy(trace, end):
        xs = [t for t, _ in trace] + [end]
        ys = [v for _, v in trace] + [trace[-1][1]]
        return xs, ys

    def plot(self, res: core.SimResult, title: str):
        self.fig.clear()
        self.begin_traces()
        tr, end = res.traces, max(res.end_time, 1e-3)
        extra = [c for c in ("SP", "SCN", "SPN") if c in tr]
        digital = sorted(c for c in tr if c.startswith("O"))
        rows = 1 + (1 if extra else 0) + (1 if digital else 0)
        ratios = [3] + ([2] if extra else []) + ([1.2] if digital else [])
        axes = self.fig.subplots(rows, 1, sharex=True,
                                 gridspec_kw={"height_ratios": ratios})
        axes = [axes] if rows == 1 else list(axes)

        ax = axes[0]
        x, y = self._xy(tr["SV"], end)
        ax.step(x, y, where="post", color=self.COLORS["SV"], lw=1.6, label="SV")
        self.add_trace("SV", x, y, "V")
        ax.set_ylabel("SV [V]", color=self.COLORS["SV"])
        ax2 = ax.twinx(); ax2._is_twin = True
        x, y = self._xy(tr["SC"], end)
        self.add_trace("SC", x, y, "A")
        ax2.step(x, y, where="post", color=self.COLORS["SC"], lw=1.2, ls="--",
                 label="SC")
        ax2.set_ylabel("SC [A]", color=self.COLORS["SC"])
        ax.grid(True, alpha=0.3)
        ax.set_title(title, fontsize=10)

        i = 1
        if extra:
            a = axes[i]; i += 1
            for c in extra:
                x, y = self._xy(tr[c], end)
                a.step(x, y, where="post", color=self.COLORS[c], lw=1.3, label=c)
                self.add_trace(c, x, y, UNITS.get(c, ""))
            a.legend(loc="upper right", fontsize=8); a.grid(True, alpha=0.3)
            a.set_ylabel("Power / sink")
        if digital:
            a = axes[i]
            for k, c in enumerate(digital):
                x, y = self._xy(tr[c], end)
                a.step(x, [v * 0.8 + k for v in y], where="post", lw=1.2)
                self.add_trace(c, x, y)
            a.set_yticks([k + 0.4 for k in range(len(digital))])
            a.set_yticklabels(digital, fontsize=8)
            a.set_ylim(-0.2, len(digital)); a.grid(True, axis="x", alpha=0.3)
            a._fixed_ylim = (-0.2, len(digital))
        axes[-1].set_xlabel("Time [s]")
        self.finish_plot()


# ==========================================================================
# Settings memory (last folders, connection, window layout, recent files)
# ==========================================================================
_SETTINGS = None


def settings() -> QSettings:
    global _SETTINGS
    if _SETTINGS is None:
        _SETTINGS = QSettings("DeltaSeqBuilder", "SequenceBuilder")
    return _SETTINGS


def _last_dir() -> str:
    return settings().value("dirs/last", "", type=str) or ""


def _remember_dir(fn: str):
    if fn:
        settings().setValue("dirs/last", os.path.dirname(fn))


def _open_dialog(parent, caption, directory="", flt=""):
    fn, f = QFileDialog.getOpenFileName(parent, caption, directory or _last_dir(), flt)
    _remember_dir(fn)
    return fn, f


def _save_dialog(parent, caption, default="", flt=""):
    d = _last_dir()
    path = os.path.join(d, os.path.basename(default)) if d and default else default
    fn, f = QFileDialog.getSaveFileName(parent, caption, path, flt)
    _remember_dir(fn)
    return fn, f


def conn_params() -> dict:
    s = settings()
    return {"host": s.value("conn/host", "192.168.0.100", type=str),
            "port": int(s.value("conn/port", core.DEFAULT_PORT)),
            "timeout": float(s.value("conn/timeout", 2.0)),
            "delay": float(s.value("conn/delay", 0.0))}


def conn_queries() -> dict:
    s = settings()
    return {k: s.value(f"conn/q_{k}", q, type=str) for k, q in core.DEFAULT_QUERIES.items()}


def hv_threshold() -> float:
    return float(settings().value("safety/hv", 60.0))


def confirm_high_voltage(parent, max_v: float) -> bool:
    th = hv_threshold()
    if th <= 0 or max_v <= th:
        return True
    box = QMessageBox(QMessageBox.Warning, "High voltage",
                      f"<b>This sets up to {max_v:.6g} V</b> (above your "
                      f"{th:g} V confirmation level).<br><br>Check that covers are "
                      f"fitted, wiring is rated and nobody can touch live parts.<br>"
                      f"Continue?", QMessageBox.Yes | QMessageBox.No, parent)
    box.setDefaultButton(QMessageBox.No)
    return box.exec_() == QMessageBox.Yes


def make_conn() -> core.PsuConnection:
    return core.PsuConnection(**conn_params())


class ConnectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Power supply connection")
        p, q = conn_params(), conn_queries()
        f = QFormLayout(self)
        self.ed_host = QLineEdit(p["host"])
        self.sp_port = QSpinBox(); self.sp_port.setRange(1, 65535); self.sp_port.setValue(p["port"])
        self.sp_to = QDoubleSpinBox(); self.sp_to.setRange(0.1, 60); self.sp_to.setValue(p["timeout"])
        self.sp_to.setSuffix(" s")
        self.sp_delay = QDoubleSpinBox(); self.sp_delay.setRange(0, 1000)
        self.sp_delay.setDecimals(0); self.sp_delay.setValue(p["delay"] * 1000)
        self.sp_delay.setSuffix(" ms")
        f.addRow("IP address / host", self.ed_host)
        f.addRow("TCP port (Delta: 8462)", self.sp_port)
        f.addRow("Reply timeout", self.sp_to)
        f.addRow("Delay between commands", self.sp_delay)
        self.sp_hv = QDoubleSpinBox(); self.sp_hv.setRange(0, 100000)
        self.sp_hv.setValue(hv_threshold()); self.sp_hv.setSuffix(" V")
        self.sp_hv.setSpecialValueText("never ask")
        self.sp_hv.setToolTip("Ask for an extra confirmation before uploading or "
                              "starting anything that sets a higher voltage")
        f.addRow("Confirm uploads above", self.sp_hv)
        self.ed_q = {}
        for k, label in (("V", "Measure voltage query"), ("I", "Measure current query"),
                         ("P", "Measure power query (empty = off)")):
            self.ed_q[k] = QLineEdit(q[k]); f.addRow(label, self.ed_q[k])
        b = QPushButton("Test connection (*IDN?)"); b.clicked.connect(self.test)
        f.addRow(b)
        self.lbl = QLabel(); self.lbl.setWordWrap(True); f.addRow(self.lbl)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save); bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _store(self):
        s = settings()
        s.setValue("conn/host", self.ed_host.text().strip())
        s.setValue("conn/port", self.sp_port.value())
        s.setValue("conn/timeout", self.sp_to.value())
        s.setValue("conn/delay", self.sp_delay.value() / 1000.0)
        s.setValue("safety/hv", self.sp_hv.value())
        for k, e in self.ed_q.items():
            s.setValue(f"conn/q_{k}", e.text().strip())

    def test(self):
        self._store()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                idn = core.identify(con)
                m = core.measure(con, conn_queries())
            self.lbl.setText(f"<b>Connected:</b> {idn}<br>V = {m.get('V')}, "
                             f"I = {m.get('I')}, P = {m.get('P')}")
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
        finally:
            QApplication.restoreOverrideCursor()

    def save(self):
        self._store(); self.accept()


def run_with_progress(parent, title, func):
    """Run func(progress_cb) with a cancellable progress dialog."""
    dlg = QProgressDialog(title, "Cancel", 0, 100, parent)
    dlg.setWindowModality(Qt.WindowModal); dlg.setMinimumDuration(300)

    def progress(i, n):
        dlg.setMaximum(n); dlg.setValue(i)
        QApplication.processEvents()
        return not dlg.wasCanceled()
    try:
        return func(progress)
    finally:
        dlg.close()


class ReportInfoDialog(QDialog):
    def __init__(self, parent, title="Power supply test report"):
        super().__init__(parent)
        self.setWindowTitle("PDF test report")
        f = QFormLayout(self)
        self.ed_title = QLineEdit(title)
        self.ed_op = QLineEdit(settings().value("report/operator", "", type=str))
        self.ed_dut = QLineEdit(settings().value("report/dut", "", type=str))
        self.ed_notes = QPlainTextEdit(); self.ed_notes.setMaximumHeight(90)
        f.addRow("Title", self.ed_title); f.addRow("Operator", self.ed_op)
        f.addRow("Device under test", self.ed_dut); f.addRow("Notes", self.ed_notes)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        f.addRow(bb)

    def info(self) -> dict:
        settings().setValue("report/operator", self.ed_op.text())
        settings().setValue("report/dut", self.ed_dut.text())
        return {"title": self.ed_title.text() or "Test report",
                "Operator": self.ed_op.text(), "Device under test": self.ed_dut.text()}


def save_pdf_report(parent, info, planned, measured, results, notes):
    fn, _ = _save_dialog(parent, "Save PDF report",
                         time.strftime("report_%Y%m%d_%H%M%S.pdf"), "PDF (*.pdf)")
    if not fn:
        return
    if not fn.lower().endswith(".pdf"):
        fn += ".pdf"
    QApplication.setOverrideCursor(Qt.WaitCursor)
    try:
        core.make_report(fn, info, planned, measured, results, notes)
    except (OSError, ValueError) as e:
        QMessageBox.critical(parent, "Report", str(e)); return
    finally:
        QApplication.restoreOverrideCursor()
    QMessageBox.information(parent, "Report", f"Saved:\n{fn}")


class ReadBackDialog(QDialog):
    """Download a stored sequence from the supply."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Read sequence from power supply")
        self.resize(460, 420)
        self.text, self.raw = "", []
        v = QVBoxLayout(self)
        p = conn_params()
        v.addWidget(QLabel(f"Supply: <b>{p['host']}:{p['port']}</b> "
                           f"(change under Device → Connection settings)"))
        h = QHBoxLayout()
        b = QPushButton("List stored sequences"); b.clicked.connect(self.refresh)
        h.addWidget(b); h.addStretch(); v.addLayout(h)
        self.lst = QListWidget(); v.addWidget(self.lst, 1)
        self.lst.currentTextChanged.connect(lambda t: self.ed_name.setText(t))
        f = QFormLayout()
        self.ed_name = QLineEdit(); f.addRow("Sequence name", self.ed_name)
        self.sp_max = QSpinBox(); self.sp_max.setRange(1, core.MAX_STEPS)
        self.sp_max.setValue(core.MAX_STEPS)
        f.addRow("Scan up to step", self.sp_max)
        self.sp_empty = QSpinBox(); self.sp_empty.setRange(1, core.MAX_STEPS)
        self.sp_empty.setValue(50)
        f.addRow("Stop after empty steps (after END)", self.sp_empty)
        v.addLayout(f)
        self.lbl = QLabel(); self.lbl.setWordWrap(True); v.addWidget(self.lbl)
        bb = QDialogButtonBox(QDialogButtonBox.Cancel)
        self.btn = bb.addButton("Read", QDialogButtonBox.AcceptRole)
        bb.accepted.connect(self.read); bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def refresh(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                names = core.list_sequences(con)
            self.lst.clear(); self.lst.addItems(names)
            self.lbl.setText(f"{len(names)} sequence(s) stored." if names else
                             "No names returned – type the name below.")
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
        finally:
            QApplication.restoreOverrideCursor()

    def read(self):
        name = self.ed_name.text().strip()
        if not name:
            self.lbl.setText("Enter or pick a sequence name."); return
        log = []
        try:
            with make_conn() as con:
                self.text, self.raw = run_with_progress(
                    self, f"Reading '{name}'…",
                    lambda prog: core.read_sequence(
                        con, name, self.sp_max.value(), self.sp_empty.value(),
                        progress=prog, log=log.append))
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}"); return
        if self.text.count("\n") <= 1:
            self.lbl.setText("No steps were read. See Messages for the raw replies.")
        self.name = name
        self.raw = log + self.raw
        self.accept()


# ==========================================================================
# Live measurement logging
# ==========================================================================
class LiveWorker(QThread):
    idn = pyqtSignal(str)
    sample = pyqtSignal(float, object)
    status = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, params, queries, interval, start_cmds, stop_cmds):
        super().__init__()
        self.params, self.queries = params, queries
        self.interval = interval
        self.start_cmds, self.stop_cmds = start_cmds, stop_cmds
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            with core.PsuConnection(**self.params) as con:
                try:
                    self.idn.emit(core.identify(con))
                except core.PsuError:
                    pass
                for cmd in self.start_cmds:
                    con.write(cmd)
                t0 = time.monotonic()
                next_state = 0.0
                while not self._stop:
                    t_loop = time.monotonic()
                    t = t_loop - t0
                    self.sample.emit(t, core.measure(con, self.queries))
                    if t >= next_state:
                        try:
                            self.status.emit(con.query("PROG:SEL:STA?", timeout=0.5))
                        except core.PsuError:
                            pass
                        next_state = t + 1.0
                    rest = self.interval - (time.monotonic() - t_loop)
                    while rest > 0 and not self._stop:
                        time.sleep(min(rest, 0.05)); rest -= 0.05
                for cmd in self.stop_cmds:
                    con.write(cmd)
        except core.PsuError as e:
            self.failed.emit(str(e))


class LiveCanvas(InteractiveCanvas):
    def setup(self, planned: dict | None, band=None, band_on_current=False):
        """(Re)build the axes. Keeps the user's time window and cursor positions."""
        self.fig.clear(); self.begin_traces()
        self.ax = ax = self.fig.add_subplot(111)
        self.ax2 = ax2 = ax.twinx(); ax2._is_twin = True
        self.planned = planned or {}
        for name, a, col in (("SV", ax, "#1f6fb2"), ("SC", ax2, "#d62728")):
            tr = self.planned.get(name)
            if tr:
                xs = [t for t, _ in tr]; ys = [v for _, v in tr]
                a.step(xs, ys, where="post", color=col, lw=1.0, ls="--", alpha=0.6,
                       label=f"Planned {name}")
        if band:
            a = ax2 if band_on_current else ax
            a.fill_between([b[0] for b in band], [b[1] for b in band],
                           [b[2] for b in band], step="post", color="#9ecae1",
                           alpha=0.35, label="Tolerance")
        self.l_fail, = (ax2 if band_on_current else ax).plot(
            [], [], "x", color="#c62828", ms=5, label="Out of tolerance")
        self.l_v, = ax.plot([], [], color="#1f6fb2", lw=1.6, label="Measured V")
        self.l_i, = ax2.plot([], [], color="#d62728", lw=1.3, label="Measured I")
        ax.set_xlabel("Time since start [s]"); ax.set_ylabel("Voltage [V]", color="#1f6fb2")
        ax2.set_ylabel("Current [A]", color="#d62728")
        ax.grid(True, alpha=0.3)
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="upper right", fontsize=8)
        ax.set_title("Live measurement")
        self._y_user = False
        self._relayout()
        self._draw_cursors()
        self.update_data([], [], [], 0)

    def update_data(self, ts, vs, is_, follow, fails=((), ())):
        self.l_v.set_data(ts, vs); self.l_i.set_data(ts, is_)
        self.l_fail.set_data(list(fails[0]), list(fails[1]))
        self.traces = []
        for name, unit in (("SV", "V"), ("SC", "A")):
            tr = self.planned.get(name)
            if tr:
                self.add_trace(f"Planned {name}", [t for t, _ in tr],
                               [v for _, v in tr], unit)
        if ts:
            self.add_trace("Measured V", ts, vs, "V", step=False)
            self.add_trace("Measured I", ts, is_, "A", step=False)
        if follow > 0 and ts:
            self.ax.set_xlim(max(0.0, ts[-1] - follow), max(ts[-1], follow) + follow * 0.02)
        elif self._x_user is None:
            for a in (self.ax, self.ax2):
                a.relim(visible_only=True)
                a.set_autoscale_on(True)
                a.autoscale_view(scaley=False)
        if not self._y_user:
            self._autoscale_y_all()          # Y fits what is visible
        self._update_readout()
        self.draw_idle()


class LiveMonitorDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("Live monitor")
        self.resize(1000, 700)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint)
        self.worker = None
        self.ts, self.vs, self.is_, self.ps = [], [], [], []
        self.dirty = False
        v = QVBoxLayout(self)
        p = conn_params()
        top = QHBoxLayout()
        top.addWidget(QLabel(f"Supply <b>{p['host']}:{p['port']}</b> · Planned:"))
        self.cb_plan = QComboBox()
        self.cb_plan.addItems(["Editor sequence", "Script / imported sequence", "None"])
        top.addWidget(self.cb_plan)
        top.addWidget(QLabel("Interval"))
        self.sp_int = QSpinBox(); self.sp_int.setRange(20, 60000); self.sp_int.setValue(200)
        self.sp_int.setSuffix(" ms"); top.addWidget(self.sp_int)
        top.addWidget(QLabel("Follow last"))
        self.sp_follow = QDoubleSpinBox(); self.sp_follow.setRange(0, 1e6)
        self.sp_follow.setSpecialValueText("all"); self.sp_follow.setSuffix(" s")
        top.addWidget(self.sp_follow); top.addStretch()
        v.addLayout(top)
        opt = QHBoxLayout()
        self.chk_upload = QCheckBox("Upload editor sequence first")
        self.chk_out = QCheckBox("Switch output ON")
        self.chk_run = QCheckBox("Start sequence:")
        self.ed_name = QLineEdit(main.cfg.name); self.ed_name.setMaximumWidth(140)
        self.chk_stop = QCheckBox("On Stop: stop sequence + output OFF")
        self.chk_stop.setChecked(True)
        for w in (self.chk_upload, self.chk_out, self.chk_run, self.ed_name, self.chk_stop):
            opt.addWidget(w)
        opt.addStretch(); v.addLayout(opt)
        tol = QHBoxLayout()
        self.chk_tol = QCheckBox("Tolerance check on")
        self.cb_tolch = QComboBox(); self.cb_tolch.addItems(["Voltage", "Current"])
        self.sp_tabs = QDoubleSpinBox(); self.sp_tabs.setRange(0, 1e6); self.sp_tabs.setDecimals(4)
        self.sp_tabs.setValue(0.5); self.sp_tabs.setPrefix("± ")
        self.sp_tpct = QDoubleSpinBox(); self.sp_tpct.setRange(0, 100); self.sp_tpct.setValue(2)
        self.sp_tpct.setPrefix("± "); self.sp_tpct.setSuffix(" %")
        self.sp_settle = QDoubleSpinBox(); self.sp_settle.setRange(0, 1e4); self.sp_settle.setDecimals(3)
        self.sp_settle.setValue(0.2); self.sp_settle.setSuffix(" s")
        self.sp_toff = QDoubleSpinBox(); self.sp_toff.setRange(-1e4, 1e4); self.sp_toff.setDecimals(3)
        self.sp_toff.setSuffix(" s")
        self.sp_toff.setToolTip("Shift the planned curve in time to line it up with the "
                                "measurement (e.g. start delay)")
        for w in (self.chk_tol, self.cb_tolch, self.sp_tabs, self.sp_tpct):
            tol.addWidget(w)
        tol.addWidget(QLabel("(whichever larger) · settle")); tol.addWidget(self.sp_settle)
        tol.addWidget(QLabel("· planned offset")); tol.addWidget(self.sp_toff)
        self.lbl_tol = QLabel(""); tol.addWidget(self.lbl_tol); tol.addStretch()
        v.addLayout(tol)
        for w in (self.chk_tol,):
            w.toggled.connect(lambda *_: self._setup_plot())
        self.cb_tolch.currentIndexChanged.connect(lambda *_: self._setup_plot())
        for w in (self.sp_tabs, self.sp_tpct, self.sp_settle, self.sp_toff):
            w.valueChanged.connect(lambda *_: self._setup_plot())
        self.idn_text = ""
        btns = QHBoxLayout()
        self.b_start = QPushButton("▶ Start logging"); self.b_start.clicked.connect(self.start)
        self.b_stop = QPushButton("■ Stop"); self.b_stop.clicked.connect(self.stop)
        self.b_stop.setEnabled(False)
        b_clear = QPushButton("Clear"); b_clear.clicked.connect(self.clear)
        b_save = QPushButton("Save log…"); b_save.clicked.connect(self.save)
        b_rep = QPushButton("PDF report…"); b_rep.clicked.connect(self.report)
        for b in (self.b_start, self.b_stop, b_clear, b_save, b_rep):
            btns.addWidget(b)
        btns.addStretch()
        self.lbl = QLabel("Not running."); btns.addWidget(self.lbl)
        v.addLayout(btns)
        self.canvas = LiveCanvas()
        v.addWidget(PlotPanel(self.canvas), 1)
        self.timer = QTimer(self); self.timer.timeout.connect(self._redraw)
        self.cb_plan.currentIndexChanged.connect(lambda *_: self._setup_plot())
        self._setup_plot()

    def _planned(self):
        i = self.cb_plan.currentIndex()
        try:
            if i == 0:
                cfg = self.main.cfg
                if core.compile_sequence(cfg).errors:
                    return None
                if cfg.repeat == 0:      # endless: plan enough passes for ~1 hour
                    comp = core.compile_sequence(cfg)
                    one = max(comp.duration_one_pass, 1e-3)
                    passes = max(3, min(math.ceil(3600.0 / one),
                                        max(3, 100_000 // max(len(comp.points), 1))))
                    return core.simulate_settings(cfg, passes).traces
                return core.simulate_settings(cfg, max(cfg.repeat, 1)).traces
            if i == 1 and self.main.imported:
                return core.simulate(self.main.imported, max_time=self.main.sp_simtime.value(),
                                     inputs=self.main._parse_inputs(), step_time=0.0).traces
        except (ValueError, ZeroDivisionError):
            return None
        return None

    def _tol_key(self):
        return ("SC", "I") if self.cb_tolch.currentIndex() == 1 else ("SV", "V")

    def _tol_result(self):
        if not self.chk_tol.isChecked() or not self.planned_traces:
            return None
        pk, _mk = self._tol_key()
        plan = self.planned_traces.get(pk)
        if not plan:
            return None
        meas = list(zip(self.ts, self.is_ if pk == "SC" else self.vs))
        return core.tolerance_check(plan, meas, self.sp_tabs.value(), self.sp_tpct.value(),
                                    self.sp_settle.value(), self.sp_toff.value(),
                                    end_time=self.planned_end)

    def _setup_plot(self):
        r = None
        self.planned_traces = self._planned() or {}
        self.planned_end = None
        if self.planned_traces:
            self.planned_end = max(t for tr in self.planned_traces.values() for t, _ in tr)
        if self.chk_tol.isChecked() and self.planned_traces:
            pk, _ = self._tol_key()
            if self.planned_traces.get(pk):
                r = core.tolerance_check(self.planned_traces[pk], [], self.sp_tabs.value(),
                                         self.sp_tpct.value(), 0, self.sp_toff.value(),
                                         end_time=self.planned_end)
        shifted = {k: [(t + self.sp_toff.value(), v) for t, v in tr]
                   for k, tr in self.planned_traces.items()}
        self.canvas.setup(shifted, r.band if r else None, self._tol_key()[0] == "SC")
        self.dirty = True; self._redraw()

    def start(self):
        if self.worker:
            return
        start, stop = [], []
        if self.chk_upload.isChecked():
            comp = core.compile_sequence(self.main.cfg)
            if comp.errors:
                QMessageBox.warning(self, "Live monitor", "The editor sequence has errors:\n"
                                    + "\n".join(comp.errors)); return
            start += [ln for ln in core.to_scpi_lines(self.main.cfg, comp)
                      if not ln.upper().startswith("PROG:SEL:STA")]
            self.ed_name.setText(self.main.cfg.name)
        if self.chk_out.isChecked():
            if QMessageBox.question(self, "Output ON",
                                    "Switch the power supply output ON now?") != QMessageBox.Yes:
                return
            start.append("OUTP 1")
        if self.chk_run.isChecked():
            start += [f"PROG:SEL:NAM {self.ed_name.text().strip()}", "PROG:SEL:STA RUN"]
        if start:
            plan = self._planned() or {}
            vmax = max((v for _, v in plan.get("SV", [])), default=0.0)
            if self.chk_upload.isChecked():
                vmax = max(vmax, core.max_setpoint(core.compile_sequence(self.main.cfg).steps))
            if not confirm_high_voltage(self, vmax):
                return
        self.t_start_wall = time.strftime("%Y-%m-%d %H:%M:%S")
        if self.chk_stop.isChecked():
            stop = ["PROG:SEL:STA STOP", "OUTP 0"]
        self.clear()
        self._setup_plot()
        self.worker = LiveWorker(conn_params(), conn_queries(),
                                 self.sp_int.value() / 1000.0, start, stop)
        self.worker.sample.connect(self._on_sample)
        self.worker.idn.connect(lambda s: setattr(self, "idn_text", s))
        self.worker.status.connect(lambda s: setattr(self, "seq_state", s))
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self._on_finished)
        self.seq_state = "?"
        self.worker.start()
        self.timer.start(250)
        self.b_start.setEnabled(False); self.b_stop.setEnabled(True)
        self.lbl.setText("Connecting…")

    def stop(self):
        if self.worker:
            self.worker.stop()

    def _on_sample(self, t, vals):
        self.ts.append(t)
        self.vs.append(vals.get("V") if vals.get("V") is not None else math.nan)
        self.is_.append(vals.get("I") if vals.get("I") is not None else math.nan)
        self.ps.append(vals.get("P") if vals.get("P") is not None else math.nan)
        self.dirty = True

    def _on_failed(self, msg):
        QMessageBox.critical(self, "Live monitor", msg)

    def _on_finished(self):
        self.worker = None
        self.timer.stop(); self._redraw()
        self.b_start.setEnabled(True); self.b_stop.setEnabled(False)
        self.lbl.setText(f"Stopped · {len(self.ts)} samples")

    def _redraw(self):
        if not self.dirty:
            return
        self.dirty = False
        t_start = time.perf_counter()
        r = self._tol_result()
        fails = ((), ())
        if r:
            import bisect
            ys = self.is_ if self._tol_key()[0] == "SC" else self.vs
            fy = [ys[min(bisect.bisect_left(self.ts, t), len(ys) - 1)] for t in r.fail_times]
            fails = (r.fail_times, fy)
            self.lbl_tol.setText(f"<b>{'PASS' if r.passed else 'FAIL'}"
                                 f"</b> · {r.n_fail}/{r.n_checked} outside · max |dev| "
                                 f"{r.max_dev:.4g}")
        elif self.chk_tol.isChecked():
            self.lbl_tol.setText("no planned curve to check against")
        if r and self.ts and self.planned_end is not None and \
                self.ts[-1] > self.planned_end + self.sp_toff.value():
            self.lbl_tol.setText(self.lbl_tol.text() + " · points after the planned "
                                 "end are not judged")
        else:
            self.lbl_tol.setText("")
        self.canvas.update_data(self.ts, self.vs, self.is_, self.sp_follow.value(), fails)
        if self.ts:
            self.lbl.setText(f"t = {self.ts[-1]:.1f} s · {len(self.ts)} samples · "
                             f"V = {self.vs[-1]:.4g} · I = {self.is_[-1]:.4g} · "
                             f"sequencer: {getattr(self, 'seq_state', '?')}")
        # long logs: redraw less often so the window stays responsive
        if self.timer.isActive():
            cost_ms = (time.perf_counter() - t_start) * 1000
            self.timer.setInterval(int(min(5000, max(250, cost_ms * 4))))

    def report(self):
        if not self.ts:
            QMessageBox.information(self, "Report", "Nothing logged yet."); return
        dlg = ReportInfoDialog(self, "Power supply test report")
        if dlg.exec_() != QDialog.Accepted:
            return
        info = dlg.info()
        info.update({"Power supply": self.idn_text or "–",
                     "Started": getattr(self, "t_start_wall", "–"),
                     "Duration": f"{self.ts[-1]:.3f} s, {len(self.ts)} samples, "
                                 f"interval {self.sp_int.value()} ms",
                     "Planned": self.cb_plan.currentText()})
        off = self.sp_toff.value()
        planned = {}
        for pk, key in (("SV", "V"), ("SC", "I")):
            if self.planned_traces.get(pk):
                tr = [(t + off, v) for t, v in self.planned_traces[pk]]
                if self.planned_end is not None:
                    tr.append((self.planned_end + off, tr[-1][1]))
                planned[key] = tr
        measured = {"V": list(zip(self.ts, self.vs)), "I": list(zip(self.ts, self.is_))}
        if any(not math.isnan(p) for p in self.ps):
            measured["P"] = list(zip(self.ts, self.ps))
        results = {}
        r = self._tol_result()
        if r:
            results[self._tol_key()[1]] = r
            info["Tolerance"] = (f"{self.cb_tolch.currentText()}: ± max({self.sp_tabs.value():g}, "
                                 f"{self.sp_tpct.value():g} %), settle {self.sp_settle.value():g} s, "
                                 f"planned offset {off:g} s")
        save_pdf_report(self, info, planned, measured, results,
                        dlg.ed_notes.toPlainText().strip())

    def clear(self):
        self.ts, self.vs, self.is_, self.ps = [], [], [], []
        self.dirty = True; self._redraw()

    def save(self):
        if not self.ts:
            QMessageBox.information(self, "Save log", "Nothing logged yet."); return
        fn, flt = _save_dialog(self, "Save measurement log",
                               time.strftime("log_%Y%m%d_%H%M%S.csv"),
                               "CSV (*.csv);;Excel (*.xlsx)")
        if not fn: return
        if "xlsx" in flt and not fn.lower().endswith(".xlsx"):
            fn += ".xlsx"
        header = ["Time [s]", "Voltage [V]", "Current [A]", "Power [W]"]
        rows = [[round(t, 4), v, i, p] for t, v, i, p in
                zip(self.ts, self.vs, self.is_, self.ps)]
        try:
            core.write_table_file(fn, header, rows)
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Save failed", str(e))

    def closeEvent(self, ev):
        if self.worker:
            self.worker.stop(); self.worker.wait(3000)
        super().closeEvent(ev)


# ==========================================================================
# Compare view
# ==========================================================================
COMPARE_COLORS = ["#1f6fb2", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e",
                  "#17becf", "#8c564b", "#e377c2"]


class CompareCanvas(InteractiveCanvas):
    def plot(self, sources: list[dict], diff: bool, tol: dict | None = None):
        self.tol_result = None
        self.fig.clear(); self.begin_traces()
        shown = [s for s in sources if s["checked"] and s["signal"] in s["traces"]]
        rows = 2 if diff and len(shown) >= 2 else 1
        axes = self.fig.subplots(rows, 1, sharex=True,
                                 gridspec_kw={"height_ratios": [3, 1.3][:rows]})
        axes = [axes] if rows == 1 else list(axes)
        ax = axes[0]
        for s in shown:
            tr = s["traces"][s["signal"]]
            xs = [t + s["offset"] for t, _ in tr]; ys = [v * s["scale"] for _, v in tr]
            label = f"{s['label']}: {s['signal']}"
            if not ys:
                continue
            if s["kind"] == "sequence":
                xs2, ys2 = xs + [s["end"] + s["offset"]], ys + [ys[-1]]
                ax.step(xs2, ys2, where="post", color=s["color"], lw=1.5, label=label)
                self.add_trace(label, xs2, ys2, core.CHANNEL_UNITS.get(s["signal"], ""))
            else:
                ax.plot(xs, ys, color=s["color"], lw=1.3, marker=".", ms=3, label=label)
                self.add_trace(label, xs, ys, step=False)
        if tol and len(shown) >= 2:
            a, b = shown[0], shown[1]
            ta = [(t, v * a["scale"]) for t, v in a["traces"][a["signal"]]]
            tb = [(t, v * b["scale"]) for t, v in b["traces"][b["signal"]]]
            r = core.tolerance_check(ta, tb, tol["abs"], tol["pct"], tol["settle"],
                                     a["offset"], b["offset"], end_time=a["end"])
            self.tol_result = r
            if r.band:
                ax.fill_between([q[0] for q in r.band], [q[1] for q in r.band],
                                [q[2] for q in r.band], step="post", color="#9ecae1",
                                alpha=0.35, label="Tolerance around A", zorder=0)
            if r.fail_times:
                import bisect
                bx = [t + b["offset"] for t, _ in tb]; by = [v for _, v in tb]
                fy = [by[min(bisect.bisect_left(bx, t), len(by) - 1)] for t in r.fail_times]
                ax.plot(r.fail_times, fy, "x", color="#c62828", ms=5,
                        label="B out of tolerance")
        if shown:
            ax.legend(loc="best", fontsize=8)
        else:
            ax.text(0.5, 0.5, "Add files or the editor / imported sequence on the left",
                    transform=ax.transAxes, ha="center", va="center", color="grey")
        ax.grid(True, alpha=0.3); ax.set_title("Compare")
        if rows == 2:
            a, b = shown[0], shown[1]
            dt = core.difference_trace(
                [(t, v * a["scale"]) for t, v in a["traces"][a["signal"]]],
                [(t, v * b["scale"]) for t, v in b["traces"][b["signal"]]],
                a["offset"], b["offset"], a["kind"] == "sequence", b["kind"] == "sequence")
            xs = [t for t, _ in dt]; ys = [v for _, v in dt]
            axes[1].step(xs, ys, where="post", color="#444", lw=1.2)
            axes[1].set_ylabel("A − B")
            axes[1].axhline(0, color="grey", lw=0.8)
            axes[1].set_ylabel("A − B"); axes[1].grid(True, alpha=0.3)
            self.add_trace("A − B", xs, ys)
            if ys:
                axes[1].set_title(f"A − B: max |Δ| = {max(abs(y) for y in ys):.4g}",
                                  fontsize=9)
        axes[-1].set_xlabel("Time [s]")
        self.finish_plot()


class ComparePanel(QWidget):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.sources: list[dict] = []
        h = QHBoxLayout(self)
        left = QVBoxLayout()
        self.lst = QListWidget()
        self.lst.itemChanged.connect(self._item_changed)
        self.lst.currentRowChanged.connect(self._select)
        left.addWidget(QLabel("Signals (tick to show; first two ticked = A and B)"))
        left.addWidget(self.lst, 1)
        for text, fn in (("Add file…", self.add_file), ("Add editor sequence", self.add_editor),
                         ("Add script / imported", self.add_imported),
                         ("Remove", self.remove)):
            b = QPushButton(text); b.clicked.connect(fn); left.addWidget(b)
        g = QGroupBox("Selected"); f = QFormLayout(g)
        self.cb_sig = QComboBox(); self.cb_sig.currentTextChanged.connect(self._edit)
        self.sp_off = QDoubleSpinBox(); self.sp_off.setRange(-1e6, 1e6); self.sp_off.setDecimals(4)
        self.sp_off.setSuffix(" s"); self.sp_off.valueChanged.connect(self._edit)
        self.sp_off.setKeyboardTracking(False)
        self.sp_scale = QDoubleSpinBox(); self.sp_scale.setRange(-1e6, 1e6)
        self.sp_scale.setDecimals(4); self.sp_scale.setValue(1.0)
        self.sp_scale.valueChanged.connect(self._edit); self.sp_scale.setKeyboardTracking(False)
        f.addRow("Signal", self.cb_sig); f.addRow("Time offset", self.sp_off)
        f.addRow("Scale", self.sp_scale)
        left.addWidget(g)
        self.chk_diff = QCheckBox("Show difference A − B")
        self.chk_diff.toggled.connect(self.replot)
        left.addWidget(self.chk_diff)
        gt = QGroupBox("Tolerance: B against A"); ft = QFormLayout(gt)
        self.chk_tol = QCheckBox("Check"); self.chk_tol.toggled.connect(self.replot)
        self.sp_tabs = QDoubleSpinBox(); self.sp_tabs.setRange(0, 1e6); self.sp_tabs.setDecimals(4)
        self.sp_tabs.setValue(0.5); self.sp_tabs.setPrefix("± ")
        self.sp_tpct = QDoubleSpinBox(); self.sp_tpct.setRange(0, 100); self.sp_tpct.setValue(2)
        self.sp_tpct.setPrefix("± "); self.sp_tpct.setSuffix(" %")
        self.sp_settle = QDoubleSpinBox(); self.sp_settle.setRange(0, 1e4); self.sp_settle.setDecimals(3)
        self.sp_settle.setValue(0.2); self.sp_settle.setSuffix(" s")
        for w in (self.sp_tabs, self.sp_tpct, self.sp_settle):
            w.setKeyboardTracking(False); w.valueChanged.connect(self.replot)
        ft.addRow(self.chk_tol)
        ft.addRow("Absolute", self.sp_tabs); ft.addRow("Relative", self.sp_tpct)
        ft.addRow("Settling time", self.sp_settle)
        self.lbl_tol = QLabel(""); self.lbl_tol.setWordWrap(True); ft.addRow(self.lbl_tol)
        b = QPushButton("PDF report…"); b.clicked.connect(self.report); ft.addRow(b)
        left.addWidget(gt)
        w = QWidget(); w.setLayout(left); w.setMaximumWidth(290)
        h.addWidget(w)
        self.canvas = CompareCanvas()
        h.addWidget(PlotPanel(self.canvas), 1)
        self._busy = False
        self.replot()

    def _add(self, label, traces, end, kind):
        if not traces:
            QMessageBox.warning(self, "Compare", "No signals found."); return
        sig = "SV" if "SV" in traces else next(iter(traces))
        if kind == "sequence":     # prefer the channel that changes
            changing = [k for k, v in traces.items() if len({x for _, x in v}) > 1]
            if changing and sig not in changing:
                sig = changing[0]
        src = {"label": label, "traces": traces, "end": end, "kind": kind,
               "signal": sig, "offset": 0.0, "scale": 1.0, "checked": True,
               "color": COMPARE_COLORS[len(self.sources) % len(COMPARE_COLORS)]}
        self.sources.append(src)
        self._busy = True
        it = QListWidgetItem(label); it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Checked); it.setForeground(QBrush(QColor(src["color"])))
        self.lst.addItem(it)
        self._busy = False
        self.lst.setCurrentRow(len(self.sources) - 1)
        self.canvas.reset_view()
        self.replot()

    def add_file(self):
        fn, _ = _open_dialog(self, "Add file to compare", "",
                             "All supported (*.txt *.seq *.json *.csv *.tsv *.dat *.xlsx);;"
                             "All files (*)")
        if not fn: return
        self.add_path(fn)

    def add_path(self, fn):
        unit = None
        low = fn.lower()
        is_seq = low.endswith(".json")
        if low.endswith((".txt", ".seq")):
            try:
                with open(fn, encoding="utf-8", errors="replace") as fh:
                    is_seq = bool(core.parse_sequence_text(fh.read()).steps)
            except OSError:
                pass
        if not is_seq:
            try:
                first = core.read_table_file(fn)[0][0]
            except (OSError, ValueError, IndexError):
                first = ""
            guess = core.guess_time_unit(first) or "s"
            units = list(core.TIME_UNITS)
            unit, ok = QInputDialog.getItem(self, "Time unit",
                                            f"Time unit of the first column ('{first}'):",
                                            units, units.index(guess), False)
            if not ok: return
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            tr, end, kind = core.load_traces(fn, unit, self.main.sp_simtime.value(),
                                             self.main._parse_inputs())
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Compare", str(e)); return
        finally:
            QApplication.restoreOverrideCursor()
        self._add(os.path.basename(fn), tr, end, kind)

    def add_editor(self):
        cfg = self.main.cfg
        if core.compile_sequence(cfg).errors:
            QMessageBox.warning(self, "Compare", "The editor sequence has errors."); return
        r = core.simulate_settings(cfg, 2 if cfg.repeat == 0 else max(cfg.repeat, 1))
        self._add(f"Editor: {cfg.name}", r.traces, r.end_time, "sequence")

    def add_imported(self):
        m = self.main
        if not m.imported:
            QMessageBox.information(self, "Compare", "Open or apply a sequence script first.")
            return
        r = core.simulate(m.imported, max_time=m.sp_simtime.value(),
                          inputs=m._parse_inputs(), step_time=0.0)
        self._add(f"Script: {m.imported.name}", r.traces, r.end_time, "sequence")

    def remove(self):
        r = self.lst.currentRow()
        if r < 0: return
        del self.sources[r]
        self.lst.takeItem(r)
        self.replot()

    def _item_changed(self, it):
        if self._busy: return
        r = self.lst.row(it)
        if 0 <= r < len(self.sources):
            self.sources[r]["checked"] = it.checkState() == Qt.Checked
            self.replot()

    def _select(self, r):
        if not 0 <= r < len(self.sources): return
        s = self.sources[r]
        self._busy = True
        self.cb_sig.clear(); self.cb_sig.addItems(list(s["traces"]))
        self.cb_sig.setCurrentText(s["signal"])
        self.sp_off.setValue(s["offset"]); self.sp_scale.setValue(s["scale"])
        self._busy = False

    def _edit(self, *_):
        if self._busy: return
        r = self.lst.currentRow()
        if not 0 <= r < len(self.sources): return
        s = self.sources[r]
        s["signal"] = self.cb_sig.currentText() or s["signal"]
        s["offset"] = self.sp_off.value(); s["scale"] = self.sp_scale.value()
        self.replot()

    def _tol(self):
        if not self.chk_tol.isChecked():
            return None
        return {"abs": self.sp_tabs.value(), "pct": self.sp_tpct.value(),
                "settle": self.sp_settle.value()}

    def replot(self, *_):
        self.canvas.plot(self.sources, self.chk_diff.isChecked(), self._tol())
        r = self.canvas.tol_result
        if r:
            self.lbl_tol.setText(f"<b>{'PASS' if r.passed else 'FAIL'}"
                                 f"</b> – {r.n_fail} of {r.n_checked} points outside, "
                                 f"max |dev| {r.max_dev:.4g}, RMS {r.rms_dev:.4g}")
        elif self.chk_tol.isChecked():
            self.lbl_tol.setText("Tick at least two signals (A = first, B = second).")
        else:
            self.lbl_tol.setText("")

    def report(self):
        shown = [s for s in self.sources if s["checked"] and s["signal"] in s["traces"]]
        if len(shown) < 2:
            QMessageBox.information(self, "Report", "Tick two signals: A (planned) and "
                                    "B (measured)."); return
        dlg = ReportInfoDialog(self, "Comparison report")
        if dlg.exec_() != QDialog.Accepted:
            return
        a, b = shown[0], shown[1]
        key = b["signal"]
        planned = {key: [(t + a["offset"], v * a["scale"]) for t, v in a["traces"][a["signal"]]]
                   + [(a["end"] + a["offset"],
                       a["traces"][a["signal"]][-1][1] * a["scale"])]}
        measured = {key: [(t + b["offset"], v * b["scale"]) for t, v in b["traces"][b["signal"]]]}
        info = dlg.info()
        info.update({"A (planned)": f"{a['label']}: {a['signal']}",
                     "B (measured)": f"{b['label']}: {b['signal']}"})
        results = {}
        self.replot()
        if self.canvas.tol_result:
            results[key] = self.canvas.tol_result
            info["Tolerance"] = (f"± max({self.sp_tabs.value():g}, {self.sp_tpct.value():g} %), "
                                 f"settle {self.sp_settle.value():g} s")
        save_pdf_report(self, info, planned, measured, results,
                        dlg.ed_notes.toPlainText().strip())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Delta Elektronika Sequence Builder")
        self.resize(1300, 800)
        self.cfg = core.SequenceSettings(segments=[core.default_segment("Ramp")])
        self.current_file: str | None = None
        self._loading = False
        self._history: list[str] = []
        self._hidx = -1
        self._restoring = False
        self._build_ui()
        dev = settings().value("ui/device", "", type=str)
        if dev in core.DEVICE_PROFILES:
            self.cfg.device = dev
            for k, v in core.DEVICE_PROFILES[dev].items():
                setattr(self.cfg, k, v)
        self._load_settings_into_ui()
        self.settings_changed()
        self._mark_saved()
        self._restore_ui_state()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        self.setAcceptDrops(True)
        acts = {}
        for key, text, slot, sc, tip in [
            ("new", "New", self.new_project, "Ctrl+N", "New empty project"),
            ("open", "Open project…", self.open_project, "Ctrl+O", "Open a .json project"),
            ("save", "Save project", self.save_project, "Ctrl+S", None),
            ("saveas", "Save project as…", self.save_project_as, "Ctrl+Shift+S", None),
            ("opentxt", "Open sequence .txt…", self.import_txt, "Ctrl+I",
             "Open, plot and edit an existing sequence file"),
            ("samples", "Import samples…", self.import_samples, "Ctrl+M",
             "Import time/value samples from CSV, TXT or Excel"),
            ("export", "Export sequence .txt…", self.export_txt, "Ctrl+E",
             "Save the editor's sequence as a .txt file"),
            ("expsamples", "Export samples…", self.export_editor_samples,
             "Ctrl+Shift+E", "Save the editor's signal as time/value samples"),
            ("upload", "Upload to PSU…", self.upload_psu, None, None),
            ("undo", "Undo", self.undo, "Ctrl+Z", None),
            ("redo", "Redo", self.redo, "Ctrl+Y", None),
            ("exit", "Exit", self.close, "Ctrl+Q", None),
            ("conn", "Connection settings…", self.connection_settings, None,
             "IP address, port and measurement queries"),
            ("test", "Test connection", self.test_connection, None, None),
            ("upload_script", "Upload script sequence…", self.upload_script, None,
             "Upload the sequence from the 'Sequence script' tab"),
            ("readback", "Read sequence from PSU…", self.read_back, None,
             "Download a stored sequence, plot and edit it"),
            ("live", "Live monitor…", self.live_monitor, "Ctrl+L",
             "Log measured voltage/current and compare with the planned profile"),
            ("run", "Run sequence on PSU", self.run_on_psu, None, None),
            ("stopseq", "Stop sequence on PSU", self.stop_on_psu, None, None),
            ("outoff", "Output OFF", self.output_off, None, "Switch the supply output off"),
        ]:
            a = QAction(text, self); a.triggered.connect(slot)
            if sc: a.setShortcut(sc)
            if tip: a.setToolTip(tip); a.setStatusTip(tip)
            acts[key] = a
        self.acts = acts
        mb = self.menuBar()
        m = mb.addMenu("&File")
        for k in ("new", "open", "save", "saveas", None, "opentxt", "samples", None,
                  "export", "expsamples", None, "recent", None, "exit"):
            if k is None:
                m.addSeparator()
            elif k == "recent":
                self.menu_recent = m.addMenu("Recent files")
            else:
                m.addAction(acts[k])
        m = mb.addMenu("&Edit")
        m.addAction(acts["undo"]); m.addAction(acts["redo"])
        m = mb.addMenu("&Device")
        for k in ("conn", "test", None, "upload", "upload_script", "readback", None,
                  "live", None, "run", "stopseq", "outoff"):
            m.addSeparator() if k is None else m.addAction(acts[k])
        self.menu_tpl = mb.addMenu("&Templates")
        self._rebuild_templates()
        self._rebuild_recent()
        tb = QToolBar("Main"); tb.setObjectName("main_toolbar"); self.addToolBar(tb)
        for k in ("new", "open", "save", None, "undo", "redo", None, "opentxt",
                  "samples", None, "export", "expsamples", None, "upload", "readback",
                  "live"):
            tb.addSeparator() if k is None else tb.addAction(acts[k])

        # ---- left: settings + segments
        left = QWidget(); lv = QVBoxLayout(left)

        g = QGroupBox("Sequence settings"); f = QFormLayout(g)
        self.ed_name = QLineEdit(); self.ed_name.setMaxLength(16)
        self.cb_channel = QComboBox(); self.cb_channel.addItems(CHANNELS)
        self.sp_vlim = self._dspin(0, 2000, 3); self.sp_clim = self._dspin(0, 2000, 3)
        self.sp_vmax = self._dspin(0, 2000, 3); self.sp_cmax = self._dspin(0, 2000, 3)
        self.cb_device = QComboBox()
        self.cb_device.addItems(list(core.DEVICE_PROFILES) + [core.CUSTOM_DEVICE])
        self.cb_device.setToolTip("Selects the model limits used to check the sequence")
        self.cb_device.currentIndexChanged.connect(self.device_changed)
        self.sp_pmax = self._dspin(0, 100000, 1)
        self.sp_repeat = QSpinBox(); self.sp_repeat.setRange(0, 65535)
        self.sp_repeat.setSpecialValueText("∞ (infinite)")
        self.chk_final = QCheckBox("Set at end:")
        self.sp_final = self._dspin(-100000, 100000, 3)
        hf = QHBoxLayout(); hf.addWidget(self.chk_final); hf.addWidget(self.sp_final)
        self.sp_dec = QSpinBox(); self.sp_dec.setRange(0, 4)
        self.chk_merge = QCheckBox("Merge equal consecutive values")
        self.chk_nv = QCheckBox("Store non-volatile (PROG:SAV)")
        self.chk_clear = QCheckBox("Delete old sequence before upload")
        self.chk_run = QCheckBox("Run after upload")
        f.addRow("Name", self.ed_name)
        f.addRow("Controlled", self.cb_channel)
        f.addRow("Voltage limit [V]", self.sp_vlim)
        f.addRow("Current limit [A]", self.sp_clim)
        f.addRow("Device", self.cb_device)
        f.addRow("Model Vmax / Cmax", self._row(self.sp_vmax, self.sp_cmax))
        f.addRow("Model Pmax [W]", self.sp_pmax)
        f.addRow("Repeat", self.sp_repeat)
        f.addRow(hf)
        f.addRow("Decimals", self.sp_dec)
        for w in (self.chk_merge, self.chk_nv, self.chk_clear, self.chk_run):
            f.addRow(w)
        self.chk_compact = QCheckBox("Compact ramps (INC loops – far fewer steps)")
        self.chk_compact.setToolTip(
            "Straight ramps are written as small loops (INC + jump, variable #B)\n"
            "instead of one SV=/W= pair per point. A 1000-point ramp needs ~7 steps.\n"
            "Every value stays within half a digit of the normal output.")
        f.addRow(self.chk_compact)
        lv.addWidget(g)

        gsafe = QGroupBox("Safety checks"); fs = QFormLayout(gsafe)
        self.sp_maxstep = self._dspin(0, 1e6, 3); self.sp_maxstep.setSpecialValueText("off")
        self.sp_maxstep.setToolTip("Largest allowed change between two consecutive set values")
        self.sp_maxrate = self._dspin(0, 1e9, 3); self.sp_maxrate.setSpecialValueText("off")
        self.sp_maxrate.setToolTip("Largest allowed |change| divided by the hold time "
                                   "before it (units per second)")
        self.chk_safe_err = QCheckBox("Block export/upload when a check fails")
        fs.addRow("Max step size", self.sp_maxstep)
        fs.addRow("Max rate [/s]", self.sp_maxrate)
        fs.addRow(self.chk_safe_err)
        lbl = QLabel("Power (V × I) is always checked against the device rating. "
                     "High-voltage confirmation: Device → Connection settings.")
        lbl.setWordWrap(True); lbl.setStyleSheet("color: grey; font-size: 8pt")
        fs.addRow(lbl)
        lv.addWidget(gsafe)
        self.chk_compact.toggled.connect(self.settings_changed)
        self.chk_safe_err.toggled.connect(self.settings_changed)
        self.sp_maxstep.valueChanged.connect(self.settings_changed)
        self.sp_maxrate.valueChanged.connect(self.settings_changed)

        for w in (self.ed_name,):
            w.textChanged.connect(self.settings_changed)
        self.cb_channel.currentIndexChanged.connect(self.settings_changed)
        for w in (self.sp_vlim, self.sp_clim, self.sp_vmax, self.sp_cmax,
                  self.sp_pmax, self.sp_final):
            w.valueChanged.connect(self.settings_changed)
        for w in (self.sp_repeat, self.sp_dec):
            w.valueChanged.connect(self.settings_changed)
        for w in (self.chk_final, self.chk_merge, self.chk_nv, self.chk_clear,
                  self.chk_run):
            w.toggled.connect(self.settings_changed)

        gs = QGroupBox("Signal segments"); sv = QVBoxLayout(gs)
        self.lst = QListWidget()
        self.lst.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst.currentRowChanged.connect(self.segment_selected)
        sv.addWidget(self.lst)
        hb = QHBoxLayout()
        self.cb_type = QComboBox(); self.cb_type.addItems(core.SEGMENT_TYPES)
        b_add = QPushButton("Add"); b_add.clicked.connect(self.add_segment)
        hb.addWidget(self.cb_type); hb.addWidget(b_add); sv.addLayout(hb)
        hb2 = QHBoxLayout()
        for text, slot in [("Duplicate", self.dup_segment), ("Remove", self.del_segment),
                           ("▲", lambda: self.move_segment(-1)),
                           ("▼", lambda: self.move_segment(1))]:
            b = QPushButton(text); b.clicked.connect(slot); hb2.addWidget(b)
        sv.addLayout(hb2)
        hb4 = QHBoxLayout()
        b = QPushButton("Combine selected (+ − ×)…")
        b.setToolTip("Ctrl+click two segments, then combine them into one signal")
        b.clicked.connect(self.combine_selected); hb4.addWidget(b)
        b = QPushButton("Split"); b.setToolTip("Turn a Combine segment back into A and B")
        b.clicked.connect(self.split_segment); hb4.addWidget(b)
        sv.addLayout(hb4)
        lv.addWidget(gs, 1)

        self.grp_params = QGroupBox("Segment parameters")
        self.form_params = QFormLayout(self.grp_params)
        lv.addWidget(self.grp_params)

        # ---- right: plot + output
        right = QSplitter(Qt.Vertical)
        self.plot_tabs = QTabWidget()
        pw = QWidget(); pv = QVBoxLayout(pw)
        self.canvas = PlotCanvas()
        pv.addWidget(PlotPanel(self.canvas))
        self.plot_tabs.addTab(pw, "Editor preview")

        iw = QWidget(); iv = QVBoxLayout(iw)
        self.imp_canvas = ImportCanvas()
        iv.addWidget(PlotPanel(self.imp_canvas), 1)
        hi = QHBoxLayout()
        hi.addWidget(QLabel("Sim. limit [s]"))
        self.sp_simtime = self._dspin(0.1, 1e6, 1); self.sp_simtime.setValue(600)
        hi.addWidget(self.sp_simtime)
        hi.addWidget(QLabel("Inputs"))
        self.ed_inputs = QLineEdit(); self.ed_inputs.setPlaceholderText("e.g. IA1=1, IB2=0")
        hi.addWidget(self.ed_inputs, 1)
        b = QPushButton("Re-simulate"); b.clicked.connect(self.run_import_sim)
        hi.addWidget(b)
        b = QPushButton("Convert to editable…"); b.clicked.connect(self.convert_import)
        hi.addWidget(b)
        b = QPushButton("Save as .txt…"); b.clicked.connect(self.save_script_as)
        hi.addWidget(b)
        b = QPushButton("Export samples…"); b.clicked.connect(self.export_imported_samples)
        hi.addWidget(b)
        iv.addLayout(hi)
        self.lbl_import = QLabel("Use 'Open sequence .txt…' to load an existing file.")
        self.lbl_import.setWordWrap(True)
        iv.addWidget(self.lbl_import)
        self.plot_tabs.addTab(iw, "Imported sequence")
        self.compare = ComparePanel(self)
        self.plot_tabs.addTab(self.compare, "Compare")
        right.addWidget(self.plot_tabs)
        self.imported: core.ParsedSequence | None = None
        self.imported_file = ""
        self.sim: core.SimResult | None = None

        ow = QWidget(); ov = QVBoxLayout(ow)
        hb3 = QHBoxLayout()
        hb3.addWidget(QLabel("Output format:"))
        self.cb_fmt = QComboBox()
        self.cb_fmt.addItems(["SCPI upload commands", "Step list"])
        self.cb_fmt.currentIndexChanged.connect(self.refresh)
        hb3.addWidget(self.cb_fmt); hb3.addStretch()
        self.lbl_status = QLabel(); hb3.addWidget(self.lbl_status)
        ov.addLayout(hb3)
        self.tabs = QTabWidget()
        self.txt_out = QPlainTextEdit(); self.txt_out.setReadOnly(True)
        self.txt_out.setFont(QFont("Consolas", 10))
        self.txt_msg = QPlainTextEdit(); self.txt_msg.setReadOnly(True)
        self.tabs.addTab(self.txt_out, "Generated file")
        self.tabs.addTab(self.txt_msg, "Messages")
        sw = QWidget(); sv2 = QVBoxLayout(sw); sv2.setContentsMargins(0, 0, 0, 0)
        hs = QHBoxLayout()
        b = QPushButton("Apply && simulate  (Ctrl+Enter)")
        b.clicked.connect(self.apply_script); hs.addWidget(b)
        b = QPushButton("Save as .txt…"); b.clicked.connect(self.save_script_as)
        hs.addWidget(b)
        b = QPushButton("Load editor's sequence"); b.setToolTip(
            "Copy the generated sequence here so you can hand-edit it")
        b.clicked.connect(self.load_generated_into_script); hs.addWidget(b)
        hs.addStretch()
        self.lbl_script = QLabel(""); hs.addWidget(self.lbl_script)
        sv2.addLayout(hs)
        self.txt_import = QPlainTextEdit()
        self.txt_import.setFont(QFont("Consolas", 10))
        self.txt_import.setPlaceholderText(
            "Open a sequence .txt file, or click \"Load editor's sequence\", then "
            "edit the steps here (e.g. 'PROG:SEL:STE 5 SV=12' or '5 SV=12').")
        self.txt_import.textChanged.connect(
            lambda: self.lbl_script.setText("Modified – click Apply"))
        sv2.addWidget(self.txt_import)
        a = QAction(self); a.setShortcut("Ctrl+Return"); a.triggered.connect(self.apply_script)
        self.txt_import.addAction(a)
        a.setShortcutContext(Qt.WidgetShortcut)
        self.tabs.addTab(sw, "Sequence script")
        ov.addWidget(self.tabs)
        right.addWidget(ow)
        right.setSizes([450, 350])

        split = QSplitter(Qt.Horizontal)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(left)
        scroll.setMinimumWidth(360)
        split.addWidget(scroll); split.addWidget(right); split.setSizes([420, 880])
        self.setCentralWidget(split)

    @staticmethod
    def _dspin(lo, hi, dec):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setKeyboardTracking(False)
        return s

    @staticmethod
    def _row(*widgets):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in widgets: h.addWidget(x)
        return w

    # ------------------------------------------------------- settings <-> UI
    def _load_settings_into_ui(self):
        self._loading = True
        c = self.cfg
        self.ed_name.setText(c.name)
        self.cb_channel.setCurrentIndex(list(CHANNELS.values()).index(c.channel))
        self.sp_vlim.setValue(c.limit_voltage); self.sp_clim.setValue(c.limit_current)
        self.cb_device.setCurrentText(c.device if c.device in core.DEVICE_PROFILES
                                      else core.CUSTOM_DEVICE)
        self.sp_vmax.setValue(c.vmax); self.sp_cmax.setValue(c.cmax)
        self.sp_pmax.setValue(c.pmax)
        self._apply_device_enable()
        self.sp_repeat.setValue(c.repeat)
        self.chk_final.setChecked(c.final_value_enabled); self.sp_final.setValue(c.final_value)
        self.sp_dec.setValue(c.decimals); self.chk_merge.setChecked(c.merge_equal)
        self.chk_nv.setChecked(c.nonvolatile); self.chk_clear.setChecked(c.clear_before_upload)
        self.chk_run.setChecked(c.run_after_upload)
        self.chk_compact.setChecked(c.compact_ramps)
        self.sp_maxstep.setValue(c.max_step); self.sp_maxrate.setValue(c.max_rate)
        self.chk_safe_err.setChecked(c.safety_errors)
        self._loading = False
        self._rebuild_list(0)

    def _apply_device_enable(self):
        custom = self.cb_device.currentText() == core.CUSTOM_DEVICE
        for w in (self.sp_vmax, self.sp_cmax, self.sp_pmax):
            w.setEnabled(custom)

    def device_changed(self, *_):
        if self._loading:
            return
        prof = core.DEVICE_PROFILES.get(self.cb_device.currentText())
        if prof:
            self._loading = True
            self.sp_vmax.setValue(prof["vmax"]); self.sp_cmax.setValue(prof["cmax"])
            self.sp_pmax.setValue(prof["pmax"])
            self._loading = False
        self._apply_device_enable()
        settings().setValue("ui/device", self.cb_device.currentText())
        self.settings_changed()

    def settings_changed(self, *_):
        if self._loading:
            return
        c = self.cfg
        c.name = self.ed_name.text().strip()
        c.channel = CHANNELS[self.cb_channel.currentText()]
        c.limit_voltage = self.sp_vlim.value(); c.limit_current = self.sp_clim.value()
        c.vmax = self.sp_vmax.value(); c.cmax = self.sp_cmax.value()
        c.pmax = self.sp_pmax.value()
        c.device = self.cb_device.currentText()
        c.repeat = self.sp_repeat.value()
        c.final_value_enabled = self.chk_final.isChecked()
        c.final_value = self.sp_final.value()
        c.decimals = self.sp_dec.value(); c.merge_equal = self.chk_merge.isChecked()
        c.nonvolatile = self.chk_nv.isChecked()
        c.clear_before_upload = self.chk_clear.isChecked()
        c.run_after_upload = self.chk_run.isChecked()
        c.compact_ramps = self.chk_compact.isChecked()
        c.max_step = self.sp_maxstep.value(); c.max_rate = self.sp_maxrate.value()
        c.safety_errors = self.chk_safe_err.isChecked()
        self.sp_vlim.setEnabled(c.channel != "SV")
        self.sp_clim.setEnabled(c.channel != "SC")
        self.refresh()

    # ------------------------------------------------------------- segments
    def _rebuild_list(self, select=None):
        self.lst.blockSignals(True)
        self.lst.clear()
        for i, s in enumerate(self.cfg.segments, 1):
            self.lst.addItem(f"{i}. {core.describe_segment(s)}")
        self.lst.blockSignals(False)
        if select is not None and self.cfg.segments:
            self.lst.setCurrentRow(max(0, min(select, len(self.cfg.segments) - 1)))
        else:
            self.segment_selected(self.lst.currentRow())

    def add_segment(self):
        seg = core.default_segment(self.cb_type.currentText())
        # continue from the previous segment's last value
        if self.cfg.segments:
            try:
                pts = core.segment_preview(self.cfg.segments[-1])
            except (ValueError, ZeroDivisionError, KeyError):
                pts = []
            last = pts[-1][0] if pts else 0.0
            for key in ("value", "start", "low", "offset"):
                if key in seg:
                    seg[key] = round(last, 3); break
        self.cfg.segments.append(seg)
        self._rebuild_list(len(self.cfg.segments) - 1)

    def dup_segment(self):
        r = self.lst.currentRow()
        if r < 0: return
        self.cfg.segments.insert(r + 1, copy.deepcopy(self.cfg.segments[r]))
        self._rebuild_list(r + 1)

    def del_segment(self):
        r = self.lst.currentRow()
        if r < 0: return
        del self.cfg.segments[r]
        self._rebuild_list(r)
        self.refresh()

    def combine_selected(self):
        rows = sorted({i.row() for i in self.lst.selectedIndexes()})
        if len(rows) != 2:
            QMessageBox.information(
                self, "Combine",
                "Select exactly two segments (Ctrl+click), then click Combine.\n\n"
                "Tip: you can also add a 'Combine' segment and edit A and B directly.")
            return
        op, ok = QInputDialog.getItem(self, "Combine", "Operation (A ∘ B):",
                                      list(core.COMBINE_OPS), 2, False)
        if not ok: return
        a, b = (copy.deepcopy(self.cfg.segments[r]) for r in rows)
        dts = [x["dt"] for x in (a, b) if "dt" in x]
        seg = {"type": "Combine", "op": op, "dt": min(dts) if dts else 0.05,
               "a": a, "b": b}
        self.cfg.segments[rows[0]] = seg
        del self.cfg.segments[rows[1]]
        self._rebuild_list(rows[0])

    def split_segment(self):
        r = self.lst.currentRow()
        if r < 0 or self.cfg.segments[r]["type"] != "Combine":
            QMessageBox.information(self, "Split", "Select a Combine segment first.")
            return
        seg = self.cfg.segments[r]
        self.cfg.segments[r:r + 1] = [seg["a"], seg["b"]]
        self._rebuild_list(r)

    def move_segment(self, d):
        r = self.lst.currentRow(); n = r + d
        if r < 0 or not 0 <= n < len(self.cfg.segments): return
        s = self.cfg.segments
        s[r], s[n] = s[n], s[r]
        self._rebuild_list(n)

    def segment_selected(self, row):
        while self.form_params.rowCount():
            self.form_params.removeRow(0)
        if row < 0 or row >= len(self.cfg.segments):
            self.grp_params.setTitle("Segment parameters")
            self.refresh(); return
        seg = self.cfg.segments[row]
        self.grp_params.setTitle(f"Segment {row + 1}: {seg['type']}")
        build_segment_form(self.form_params, seg,
                           lambda r=row: self._seg_edited(r), self)
        self.refresh()

    def _seg_edited(self, row):
        item = self.lst.item(row)
        if item:
            item.setText(f"{row + 1}. {core.describe_segment(self.cfg.segments[row])}")
        self.refresh()

    # --------------------------------------------------------------- output
    def _fmt_key(self):
        return "scpi" if self.cb_fmt.currentIndex() == 0 else "steps"

    def refresh(self):
        if self._loading or not hasattr(self, "canvas"):
            return
        comp = core.compile_sequence(self.cfg)
        self.comp = comp
        # segment time bounds for highlighting
        bounds, t = [], 0.0
        for s in self.cfg.segments:
            try:
                d = core.segment_compiled_duration(s)
            except (ValueError, ZeroDivisionError, KeyError):
                d = 0
            bounds.append((t, t + d)); t += d
        self.canvas.plot(comp.points, self.cfg.channel, self.cfg.repeat,
                         bounds, self.lst.currentRow(), comp.markers, comp.lead_waits)
        self.txt_out.setPlainText(core.to_text(self.cfg, comp, self._fmt_key()))
        msgs = [f"ERROR: {e}" for e in comp.errors] + [f"Warning: {w}" for w in comp.warnings]
        self.txt_msg.setPlainText("\n".join(msgs) or "No problems.")
        state = "Errors" if comp.errors else ("Warnings" if comp.warnings else "OK")
        self.lbl_status.setText(
            f"{len(comp.steps)}/{core.MAX_STEPS} steps · "
            f"{comp.duration_one_pass:.3f} s per pass · {state}")
        self.tabs.setTabText(1, f"Messages ({len(msgs)})" if msgs else "Messages")
        self._push_history()
        self._update_title()

    # ------------------------------------------------------------ undo / redo
    def _push_history(self):
        if self._restoring:
            return
        snap = self.cfg.to_json()
        if self._hidx >= 0 and self._history[self._hidx] == snap:
            return
        del self._history[self._hidx + 1:]
        self._history.append(snap)
        if len(self._history) > 300:
            self._history.pop(0)
        self._hidx = len(self._history) - 1
        self._update_undo_actions()

    def _update_undo_actions(self):
        if hasattr(self, "acts"):
            self.acts["undo"].setEnabled(self._hidx > 0)
            self.acts["redo"].setEnabled(self._hidx < len(self._history) - 1)

    def _restore(self, idx):
        row = self.lst.currentRow()
        self._restoring = True
        try:
            self._hidx = idx
            self.cfg = core.SequenceSettings.from_json(self._history[idx])
            self._load_settings_into_ui()
            self.settings_changed()
            if self.cfg.segments:
                self.lst.setCurrentRow(max(0, min(row, len(self.cfg.segments) - 1)))
        finally:
            self._restoring = False
        self._update_undo_actions()

    def undo(self):
        if self._hidx > 0:
            self._restore(self._hidx - 1)

    def redo(self):
        if self._hidx < len(self._history) - 1:
            self._restore(self._hidx + 1)

    # ---------------------------------------------------------- file actions
    def _fresh_settings(self, **kw) -> core.SequenceSettings:
        """New settings that keep the device the user selected."""
        cfg = core.SequenceSettings(**kw)
        dev = self.cfg.device if hasattr(self, "cfg") else ""
        if dev in core.DEVICE_PROFILES:
            cfg.device = dev
            for k, v in core.DEVICE_PROFILES[dev].items():
                if k != "sink":
                    setattr(cfg, k, v)
        elif hasattr(self, "cfg"):
            cfg.device = core.CUSTOM_DEVICE
            cfg.vmax, cfg.cmax, cfg.pmax = self.cfg.vmax, self.cfg.cmax, self.cfg.pmax
        return cfg

    def new_project(self):
        if not self._maybe_save():
            return
        self.cfg = self._fresh_settings(segments=[])
        self.current_file = None
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self._mark_saved()

    def open_project(self, fn=None):
        if not self._maybe_save():
            return
        if not fn:
            fn, _ = _open_dialog(self, "Open project", "",
                                                "Sequence project (*.json)")
        if not fn: return
        try:
            with open(fn, encoding="utf-8") as fh:
                cfg = core.SequenceSettings.from_json(fh.read())
        except (OSError, ValueError, TypeError) as e:
            QMessageBox.critical(self, "Open failed", f"{os.path.basename(fn)}:\n{e}")
            return
        self.cfg = cfg
        self.current_file = fn
        self._add_recent(fn)
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self._mark_saved()

    def save_project(self) -> bool:
        if not self.current_file:
            return self.save_project_as()
        try:
            with open(self.current_file, encoding="utf-8", mode="w") as fh:
                fh.write(self.cfg.to_json())
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e))
            return False
        self._add_recent(self.current_file)
        self._mark_saved()
        self.statusBar().showMessage(f"Saved {self.current_file}", 4000)
        return True

    def save_project_as(self) -> bool:
        fn, _ = _save_dialog(self, "Save project", f"{self.cfg.name}.json",
                             "Sequence project (*.json)")
        if not fn:
            return False
        if not fn.lower().endswith(".json"):
            fn += ".json"
        self.current_file = fn
        return self.save_project()

    # ---- unsaved-changes tracking
    def _mark_saved(self):
        self._saved_snapshot = self.cfg.to_json()
        self._update_title()

    def _is_modified(self) -> bool:
        return bool(self.cfg.segments) and \
            self.cfg.to_json() != getattr(self, "_saved_snapshot", None)

    def _update_title(self):
        name = os.path.basename(self.current_file) if self.current_file else "untitled"
        mark = " *" if self._is_modified() else ""
        self.setWindowTitle(f"{name}{mark} – Delta Elektronika Sequence Builder")

    def _maybe_save(self) -> bool:
        """Ask before throwing away unsaved changes. True = go ahead."""
        if not hasattr(self, "cfg") or not self._is_modified():
            return True
        r = QMessageBox.question(
            self, "Unsaved changes", "The current sequence has unsaved changes. Save them?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel, QMessageBox.Save)
        if r == QMessageBox.Save:
            return self.save_project()
        return r == QMessageBox.Discard

    # ------------------------------------------------------- import .txt
    def import_txt(self, fn=None):
        if not fn:
            fn, _ = _open_dialog(
                self, "Open sequence file", "", "Sequence text (*.txt *.seq);;All files (*)")
        if not fn: return
        try:
            with open(fn, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError as e:
            QMessageBox.critical(self, "Open failed", str(e)); return
        self.imported = core.parse_sequence_text(text)
        self.imported_file = fn
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(text)
        self.txt_import.blockSignals(False)
        self.lbl_script.setText(os.path.basename(fn))
        self._add_recent(fn)
        self.imp_canvas.reset_view()
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()

    def import_samples(self, fn=None):
        dlg = SampleImportDialog(self, self.cfg)
        if fn:
            dlg.load(fn)
        if dlg.exec_() != QDialog.Accepted or not dlg.points:
            return
        if dlg.cb_target.currentIndex() == 0 and not self._maybe_save():
            return
        seg = {"type": "Table", "points": dlg.points}
        self._add_recent(dlg.path)
        if dlg.cb_target.currentIndex() == 0:
            name = "".join(c for c in os.path.splitext(os.path.basename(dlg.path))[0]
                           if c.isalnum() or c == "_")[:16]
            if not name or not name[0].isalpha():
                name = "SAMPLES"
            self.cfg.segments = [seg]
            self.cfg.name = name
            self.current_file = None
        else:
            self.cfg.segments.append(seg)
        self.cfg.channel = dlg.channel()
        self.cfg.repeat = dlg.repeat()
        self.canvas.reset_view()
        self._load_settings_into_ui()
        self.settings_changed()
        self.lst.setCurrentRow(len(self.cfg.segments) - 1)
        self.plot_tabs.setCurrentIndex(0)

    def _parse_inputs(self) -> dict:
        out = {}
        for part in self.ed_inputs.text().replace(";", ",").split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                try: out[k.strip().upper()] = int(float(v))
                except ValueError: pass
        return out

    def run_import_sim(self):
        if not self.imported:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.sim = core.simulate(self.imported, max_time=self.sp_simtime.value(),
                                     inputs=self._parse_inputs())
        finally:
            QApplication.restoreOverrideCursor()
        r, p = self.sim, self.imported
        name = self.imported_file.replace("\\", "/").split("/")[-1]
        self.imp_canvas.plot(r, f"{name}  –  sequence '{p.name}'")
        self.lbl_import.setText(
            f"<b>{len(p.steps)} steps</b>, labels: "
            f"{', '.join(f'{k}={v}' for k, v in p.labels.items()) or 'none'} · "
            f"simulated {r.end_time:.3f} s, {r.executed} steps executed · "
            f"{r.stop_reason}")
        msgs = [f"ERROR: {e}" for e in r.errors] + [f"Warning: {w}" for w in r.warnings]
        body = "\n".join(f"{n:>5}  {c}" for n, c in p.steps.items())
        self.txt_msg.setPlainText(
            ("\n".join(msgs) or "Imported file: no problems.")
            + "\n\n--- Parsed steps ---\n" + body)
        self.tabs.setCurrentIndex(1)

    def convert_import(self):
        if not self.sim:
            QMessageBox.information(self, "Convert", "Open a sequence file first."); return
        r, p = self.sim, self.imported
        analog = [c for c in ("SV", "SC", "SP", "SCN", "SPN") if c in r.traces
                  and (c in ("SV", "SC") or len({v for _, v in r.traces[c]}) > 1)]
        changes = {c: len(r.traces[c]) for c in analog}
        best = max(analog, key=changes.get)
        ch, ok = QInputDialog.getItem(self, "Convert to editable",
                                      "Channel to turn into the editable signal:",
                                      analog, analog.index(best), False)
        if not ok: return
        if not r.stop_reason.startswith("END"):
            if QMessageBox.question(
                    self, "Convert",
                    f"The simulation did not reach END:\n{r.stop_reason}\n\n"
                    f"Loops are unrolled up to the simulated time "
                    f"({r.end_time:.1f} s). Continue?") != QMessageBox.Yes:
                return
        pts = core.trace_to_points(r.traces[ch], r.end_time)
        if not self._maybe_save():
            return
        name = "".join(c for c in p.name if c.isalnum() or c == "_")[:16]
        if not name or not name[0].isalpha():
            name = "IMPORTED"
        cfg = self._fresh_settings(name=name, channel=ch, repeat=1,
                                   final_value_enabled=False,
                                   segments=[{"type": "Table", "points": pts}])
        if ch != "SV" and r.traces["SV"]:
            cfg.limit_voltage = max(v for _, v in r.traces["SV"])
        if ch != "SC" and r.traces["SC"]:
            cfg.limit_current = max(v for _, v in r.traces["SC"])
        self.cfg = cfg; self.current_file = None
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self.plot_tabs.setCurrentIndex(0)
        if len(pts) * 2 > core.MAX_STEPS:
            QMessageBox.warning(self, "Convert",
                                "The unrolled signal needs more than 2000 steps. "
                                "Use the Repeat setting or shorten the table.")

    # ------------------------------------------------------- script editing
    def apply_script(self):
        text = self.txt_import.toPlainText()
        if not text.strip():
            return
        self.imported = core.parse_sequence_text(text)
        if not self.imported_file:
            self.imported_file = "edited script"
        self.lbl_script.setText("Applied")
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()
        self.tabs.setCurrentIndex(2)          # stay in the script editor

    def load_generated_into_script(self):
        text = core.to_text(self.cfg, self.comp, self._fmt_key())
        if self.txt_import.toPlainText().strip() and QMessageBox.question(
                self, "Sequence script",
                "Replace the text in the script editor with the editor's "
                "sequence?") != QMessageBox.Yes:
            return
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(text)
        self.txt_import.blockSignals(False)
        self.imported_file = f"{self.cfg.name} (from editor)"
        self.imported = core.parse_sequence_text(text)
        self.imp_canvas.reset_view()
        self.tabs.setCurrentIndex(2)
        self.lbl_script.setText("Loaded from editor")
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()

    def save_script_as(self):
        if not self.txt_import.toPlainText().strip():
            QMessageBox.information(self, "Save script",
                                    "Open a sequence file or load the editor's "
                                    "sequence first."); return
        self.apply_script()
        seq = self.imported
        choice, ok = QInputDialog.getItem(
            self, "Save sequence as",
            "How should the file be written?",
            ["Exactly as in the editor (unchanged text)",
             "SCPI upload commands (renumbered, clean)",
             "Step list (renumbered, clean)"], 0, False)
        if not ok: return
        name = seq.name
        if not choice.startswith("Exactly"):
            name, ok = QInputDialog.getText(self, "Save sequence as",
                                            "Sequence name (max 16 chars):", text=seq.name)
            if not ok: return
            name = name.strip()[:16] or seq.name
            if not name[0].isalpha():
                QMessageBox.warning(self, "Name", "The name must start with a letter.")
                return
        fn, _ = _save_dialog(self, "Save sequence as",
                                            f"{name}.txt", "Text (*.txt)")
        if not fn: return
        if choice.startswith("Exactly"):
            text = self.txt_import.toPlainText()
        else:
            text = core.parsed_to_text(
                seq, name, "steps" if choice.startswith("Step") else "scpi",
                clear_before_upload=self.cfg.clear_before_upload)
        try:
            with open(fn, "w", encoding="ascii", errors="replace", newline="\n") as fh:
                fh.write(text if text.endswith("\n") else text + "\n")
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e)); return
        self.statusBar().showMessage(f"Saved {fn}", 4000)

    # ------------------------------------------------------- sample export
    def export_editor_samples(self):
        if self.comp.errors:
            return self._check_ok()
        cfg = copy.deepcopy(self.cfg)
        dlg = ExportSamplesDialog(self, lambda n: core.simulate_settings(cfg, n),
                                  "Export samples – editor signal", cfg.name,
                                  can_passes=cfg.repeat != 1)
        if dlg.exec_() == QDialog.Accepted:
            self.statusBar().showMessage("Samples exported.", 4000)

    def export_imported_samples(self):
        if not self.imported:
            QMessageBox.information(self, "Export samples",
                                    "Open a sequence .txt file first."); return
        seq, lim, inp = self.imported, self.sp_simtime.value(), self._parse_inputs()
        dlg = ExportSamplesDialog(
            self, lambda n: core.simulate(seq, max_time=lim, inputs=inp, step_time=0.0),
            "Export samples – imported sequence", seq.name, can_passes=False)
        if dlg.exec_() == QDialog.Accepted:
            self.statusBar().showMessage("Samples exported.", 4000)

    # ------------------------------------------------------- drag & drop
    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        urls = [u.toLocalFile() for u in ev.mimeData().urls() if u.isLocalFile()]
        if not urls:
            return
        self.open_any(urls[0])

    def open_any(self, fn):
        if not os.path.exists(fn):
            QMessageBox.warning(self, "Open", f"File not found:\n{fn}")
            return
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".json":
            self.open_project(fn)
        elif ext in (".csv", ".tsv", ".dat", ".xlsx", ".xlsm"):
            self.import_samples(fn)
        else:
            try:
                with open(fn, encoding="utf-8", errors="replace") as fh:
                    looks_seq = bool(core.parse_sequence_text(fh.read()).steps)
            except OSError:
                looks_seq = False
            self.import_txt(fn) if looks_seq else self.import_samples(fn)

    def _check_ok(self) -> bool:
        if self.comp.errors:
            QMessageBox.warning(self, "Sequence has errors",
                                "\n".join(self.comp.errors))
            return False
        return True

    def export_txt(self):
        if not self._check_ok(): return
        fn, _ = _save_dialog(self, "Export sequence",
                                            f"{self.cfg.name}.txt", "Text (*.txt)")
        if not fn: return
        try:
            with open(fn, "w", encoding="ascii", errors="replace", newline="\n") as fh:
                fh.write(core.to_text(self.cfg, self.comp, self._fmt_key()))
        except OSError as e:
            QMessageBox.critical(self, "Export failed", str(e)); return
        self.statusBar().showMessage(f"Exported {fn}", 4000)

    # ------------------------------------------------------- device actions
    def connection_settings(self):
        ConnectionDialog(self).exec_()

    def test_connection(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                idn = core.identify(con)
            QMessageBox.information(self, "Connection", f"Connected:\n{idn}")
        except core.PsuError as e:
            QMessageBox.critical(self, "Connection", str(e))
        finally:
            QApplication.restoreOverrideCursor()

    def _upload(self, lines: list[str], name: str, steps: list[str]):
        p = conn_params()
        if not confirm_high_voltage(self, core.max_setpoint(steps, "SV")):
            return
        box = QMessageBox(QMessageBox.Question, "Upload",
                          f"Upload sequence '{name}' ({len(steps)} steps) to "
                          f"{p['host']}:{p['port']}?", QMessageBox.Yes | QMessageBox.No, self)
        chk = QCheckBox("Verify afterwards (read every step back)")
        chk.setChecked(settings().value("ui/verify", True, type=bool))
        box.setCheckBox(chk)
        if box.exec_() != QMessageBox.Yes:
            return
        settings().setValue("ui/verify", chk.isChecked())
        log = []
        try:
            with make_conn() as con:
                run_with_progress(self, "Uploading…",
                                  lambda prog: core.upload_sequence(con, lines, prog, log.append))
                diffs = core.verify_upload(con, name, steps, log.append) \
                    if chk.isChecked() else None
        except core.PsuError as e:
            QMessageBox.critical(self, "Upload failed", str(e)); return
        if diffs:
            self.txt_msg.setPlainText("Upload verification differences:\n" + "\n".join(diffs))
            self.tabs.setCurrentIndex(1)
            QMessageBox.warning(self, "Upload", f"Uploaded, but {len(diffs)} step(s) differ "
                                "– see Messages.")
        else:
            QMessageBox.information(self, "Upload", "Upload finished." +
                                    (" Verified OK." if diffs is not None else ""))

    def upload_psu(self):
        if not self._check_ok(): return
        self._upload(core.to_scpi_lines(self.cfg, self.comp), self.cfg.name, self.comp.steps)

    def upload_script(self):
        if not self.txt_import.toPlainText().strip():
            QMessageBox.information(self, "Upload", "The script editor is empty."); return
        self.apply_script()
        seq = core.renumber_steps(self.imported)
        name, ok = QInputDialog.getText(self, "Upload script", "Sequence name on the supply:",
                                        text=seq.name[:16])
        if not ok or not name.strip(): return
        name = name.strip()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,15}", name):
            QMessageBox.warning(self, "Upload script",
                                "The name must start with a letter and have at most 16 "
                                "letters, digits or _.")
            return
        text = core.parsed_to_text(seq, name, "scpi",
                                   clear_before_upload=self.cfg.clear_before_upload)
        self._upload(text.splitlines(), name, list(seq.steps.values()))

    def read_back(self):
        dlg = ReadBackDialog(self)
        if dlg.exec_() != QDialog.Accepted:
            return
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(dlg.text)
        self.txt_import.blockSignals(False)
        self.imported = core.parse_sequence_text(dlg.text)
        self.imported.name = dlg.name
        self.imported_file = f"PSU: {dlg.name}"
        self.lbl_script.setText("read from PSU")
        self.imp_canvas.reset_view()
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()
        self.txt_msg.appendPlainText("\n--- Raw replies from the supply ---\n"
                                     + "\n".join(dlg.raw[:400]))

    def live_monitor(self):
        if getattr(self, "_live", None) is None:
            self._live = LiveMonitorDialog(self)
        self._live.show(); self._live.raise_(); self._live.activateWindow()

    def _quick(self, cmds, done):
        try:
            with make_conn() as con:
                for c in cmds:
                    con.write(c)
            self.statusBar().showMessage(done, 4000)
        except core.PsuError as e:
            QMessageBox.critical(self, "Power supply", str(e))

    def run_on_psu(self):
        name, ok = QInputDialog.getText(self, "Run sequence", "Sequence name:",
                                        text=self.cfg.name)
        if ok and name.strip():
            self._quick([f"PROG:SEL:NAM {name.strip()}", "PROG:SEL:STA RUN"],
                        f"Sequence '{name.strip()}' started.")

    def stop_on_psu(self):
        self._quick(["PROG:SEL:STA STOP"], "Sequence stopped.")

    def output_off(self):
        self._quick(["OUTP 0"], "Output switched OFF.")

    # ------------------------------------------------------- templates
    def _user_templates(self) -> dict:
        try:
            return json.loads(settings().value("templates_json", "{}", type=str))
        except ValueError:
            return {}

    def _rebuild_templates(self):
        m = self.menu_tpl
        m.clear()
        hdr = m.addAction("Project"); hdr.setEnabled(False)
        user = self._user_templates()
        if user:
            for name in sorted(user):
                a = m.addAction("   " + name)
                a.triggered.connect(lambda _=False, n=name:
                                    self.insert_template(self._user_templates()[n], n))
        else:
            a = m.addAction("   (none saved yet)"); a.setEnabled(False)
        m.addSeparator()
        a = m.addAction("Save selected segments as template…")
        a.triggered.connect(self.save_template)
        if user:
            d = m.addMenu("Delete template")
            for name in sorted(user):
                d.addAction(name).triggered.connect(
                    lambda _=False, n=name: self.delete_template(n))

    def insert_template(self, tpl: dict, name: str):
        segs = copy.deepcopy(tpl["segments"])
        ch = tpl.get("channel", self.cfg.channel)
        replace = True
        if self.cfg.segments:
            box = QMessageBox(QMessageBox.Question, "Insert template",
                              f"Insert template '{name}'?", parent=self)
            b_app = box.addButton("Append to current", QMessageBox.AcceptRole)
            b_rep = box.addButton("Replace current", QMessageBox.DestructiveRole)
            box.addButton(QMessageBox.Cancel)
            box.exec_()
            if box.clickedButton() not in (b_app, b_rep):
                return
            replace = box.clickedButton() is b_rep
        if replace:
            self.cfg.segments = segs
            self.cfg.channel = ch
            self.canvas.reset_view()
        else:
            self.cfg.segments.extend(segs)
            if ch != self.cfg.channel:
                QMessageBox.information(
                    self, "Template", f"This template was made for {ch}; the sequence "
                    f"controls {self.cfg.channel}. Values were kept as they are.")
        self._load_settings_into_ui()
        self.settings_changed()
        self.lst.setCurrentRow(len(self.cfg.segments) - 1)
        self.plot_tabs.setCurrentIndex(0)

    def save_template(self):
        rows = sorted({i.row() for i in self.lst.selectedIndexes()})
        segs = [self.cfg.segments[r] for r in rows] if rows else list(self.cfg.segments)
        if not segs:
            QMessageBox.information(self, "Template", "There are no segments to save.")
            return
        name, ok = QInputDialog.getText(
            self, "Save template",
            f"Name for this template ({len(segs)} segment(s)"
            f"{'' if rows else ', all segments'}):")
        if not ok or not name.strip():
            return
        user = self._user_templates()
        name = name.strip()
        if name in user and QMessageBox.question(
                self, "Template", f"Replace the existing template '{name}'?") \
                != QMessageBox.Yes:
            return
        user[name] = {"channel": self.cfg.channel, "segments": copy.deepcopy(segs)}
        settings().setValue("templates_json", json.dumps(user))
        self._rebuild_templates()
        self.statusBar().showMessage(f"Template '{name}' saved.", 4000)

    def delete_template(self, name):
        if QMessageBox.question(self, "Template", f"Delete template '{name}'?") \
                != QMessageBox.Yes:
            return
        user = self._user_templates()
        user.pop(name, None)
        settings().setValue("templates_json", json.dumps(user))
        self._rebuild_templates()

    # ------------------------------------------------------- recent / layout
    def _recent(self) -> list[str]:
        try:
            return json.loads(settings().value("recent_json", "[]", type=str))
        except ValueError:
            return []

    def _add_recent(self, fn):
        if not fn:
            return
        fn = os.path.abspath(fn)
        lst = [fn] + [x for x in self._recent() if x != fn]
        settings().setValue("recent_json", json.dumps(lst[:10]))
        self._rebuild_recent()

    def _rebuild_recent(self):
        if not hasattr(self, "menu_recent"):
            return
        self.menu_recent.clear()
        lst = self._recent()
        for fn in lst:
            a = self.menu_recent.addAction(os.path.basename(fn))
            a.setToolTip(fn); a.setStatusTip(fn)
            a.triggered.connect(lambda _=False, f=fn: self.open_any(f))
        if lst:
            self.menu_recent.addSeparator()
            a = self.menu_recent.addAction("Clear list")
            a.triggered.connect(lambda: (settings().setValue("recent_json", "[]"),
                                         self._rebuild_recent()))
        else:
            self.menu_recent.addAction("(empty)").setEnabled(False)

    def _restore_ui_state(self):
        s = settings()
        g = s.value("ui/geometry")
        if g is not None:
            self.restoreGeometry(g)
        st = s.value("ui/state")
        if st is not None:
            self.restoreState(st)
        self.cb_fmt.setCurrentIndex(int(s.value("ui/format", 0)))
        self.sp_simtime.setValue(float(s.value("ui/simtime", 600.0)))
        self.ed_inputs.setText(s.value("ui/inputs", "", type=str))

    def closeEvent(self, ev):
        if not self._maybe_save():
            ev.ignore()
            return
        s = settings()
        s.setValue("ui/geometry", self.saveGeometry())
        s.setValue("ui/state", self.saveState())
        s.setValue("ui/format", self.cb_fmt.currentIndex())
        s.setValue("ui/simtime", self.sp_simtime.value())
        s.setValue("ui/inputs", self.ed_inputs.text())
        live = getattr(self, "_live", None)
        if live is not None:
            live.close()
        super().closeEvent(ev)

def _excepthook(exc_type, exc, tb):
    """Show unexpected errors in a dialog instead of letting PyQt abort the app."""
    import traceback
    text = "".join(traceback.format_exception(exc_type, exc, tb))
    try:
        sys.__stderr__.write(text)
    except (UnicodeError, AttributeError, OSError):
        pass
    if QApplication.instance():
        box = QMessageBox(QMessageBox.Critical, "Unexpected error", str(exc))
        box.setDetailedText(text)
        box.exec_()


def main():
    sys.excepthook = _excepthook
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    w = MainWindow(); w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
