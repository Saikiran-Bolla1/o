"""
Core logic for building Delta Elektronika (SM15K / SM3300 ...) sequencer files
from ControlDesk-style signal segments.  No GUI dependencies - can be used and
tested on its own.

Sequencer syntax used (see "Ethernet & Sequencer Programming" manual):
    SV=<v>  SC=<i>  SP=<p>      settings
    W=<s>                       wait 0.001 .. 65535 s
    #A=<n>  INC #A,1            variable / increment
    CJL <op>,<value>,<step>     conditional jump if less
    JP <label>                  unconditional jump
    END                         mandatory last step
Upload commands:
    PROG:SEL:NAM <name>, PROG:SEL:STE <n> <cmd>, PROG:SEL:LAB <label>,<step>,
    PROG:SEL:STA RUN, PROG:SEL:NON, PROG:SAV
"""
from __future__ import annotations

import json
import math
import re
import sys
import socket
import time
from dataclasses import dataclass, field, asdict

MAX_STEPS = 2000
MIN_WAIT = 0.001
MAX_WAIT = 65535.0

# --------------------------------------------------------------------------
# Segment definitions:  type -> list of (key, label, default, is_int)
# --------------------------------------------------------------------------
SEGMENT_TYPES: dict[str, list[tuple[str, str, float, bool]]] = {
    "Constant": [
        ("value", "Value", 0.0, False),
        ("duration", "Duration [s]", 1.0, False),
    ],
    "Ramp": [
        ("start", "Start value", 0.0, False),
        ("end", "End value", 10.0, False),
        ("duration", "Duration [s]", 5.0, False),
        ("dt", "Step time [s]", 0.1, False),
    ],
    "Sine": [
        ("offset", "Offset", 10.0, False),
        ("amplitude", "Amplitude", 5.0, False),
        ("freq", "Frequency [Hz]", 0.5, False),
        ("phase", "Phase [deg]", 0.0, False),
        ("duration", "Duration [s]", 4.0, False),
        ("dt", "Sample time [s]", 0.05, False),
    ],
    "Square": [
        ("low", "Low value", 0.0, False),
        ("high", "High value", 10.0, False),
        ("period", "Period [s]", 2.0, False),
        ("duty", "Duty cycle [%]", 50.0, False),
        ("cycles", "Cycles", 3, True),
    ],
    "Table": [],      # free list of [value, hold_time] points
    "Combine": [      # two child segments combined with an operation
        ("dt", "Sample time [s]", 0.05, False),
    ],
    "Exponential": [
        ("start", "Start value", 0.0, False),
        ("end", "Final value", 10.0, False),
        ("tau", "Time constant τ [s]", 1.0, False),
        ("duration", "Duration [s]", 5.0, False),
        ("dt", "Step time [s]", 0.05, False),
    ],
    "PWM": [
        ("low", "Low value", 0.0, False),
        ("high", "High value", 10.0, False),
        ("freq", "Frequency [Hz]", 1.0, False),
        ("duty_start", "Duty at start [%]", 10.0, False),
        ("duty_end", "Duty at end [%]", 90.0, False),
        ("duration", "Duration [s]", 10.0, False),
    ],
    "Battery": [      # approximate discharge curve
        ("v_full", "Full voltage", 4.2, False),
        ("v_nominal", "Nominal voltage", 3.7, False),
        ("v_cutoff", "Cut-off voltage", 3.0, False),
        ("duration", "Duration [s]", 60.0, False),
        ("dt", "Step time [s]", 0.5, False),
    ],
    "Wait for input": [
        ("preview", "Assumed wait (preview only) [s]", 1.0, False),
    ],
    "Wait for trigger": [
        ("preview", "Assumed wait (preview only) [s]", 1.0, False),
    ],
    "Triangle": [
        ("low", "Low value", 0.0, False),
        ("high", "High value", 10.0, False),
        ("period", "Period [s]", 4.0, False),
        ("cycles", "Cycles", 2, True),
        ("dt", "Step time [s]", 0.1, False),
    ],
}


DIGITAL_INPUTS = [f"I{l}{n}" for n in range(1, 5) for l in "ABCDEFGH"]

# choice parameters (shown as drop-down lists): type -> key -> (label, options)
SEGMENT_CHOICES: dict[str, dict[str, tuple[str, list[str]]]] = {
    "Wait for input": {
        "input": ("Digital input", DIGITAL_INPUTS),
        "level": ("Continue when", ["1 (high)", "0 (low)"]),
    },
}
WAIT_TYPES = ("Wait for input", "Wait for trigger")


def default_segment(kind: str) -> dict:
    seg = {"type": kind}
    for key, (_label, options) in SEGMENT_CHOICES.get(kind, {}).items():
        seg[key] = options[0]
    if kind == "Table":
        seg["points"] = [[0.0, 1.0], [10.0, 1.0]]
    if kind == "Combine":
        seg["op"] = "Multiply"
        seg["a"] = default_segment("Sine")
        seg["b"] = default_segment("Ramp") | {"start": 0.0, "end": 1.0,
                                             "duration": 4.0}
    for key, _label, default, is_int in SEGMENT_TYPES[kind]:
        seg[key] = int(default) if is_int else float(default)
    return seg


def describe_segment(seg: dict) -> str:
    k = seg["type"]
    if k == "Constant":
        return f"Constant {seg['value']:g} for {seg['duration']:g} s"
    if k == "Ramp":
        return f"Ramp {seg['start']:g} → {seg['end']:g} in {seg['duration']:g} s"
    if k == "Sine":
        return (f"Sine {seg['offset']:g} ± {seg['amplitude']:g}, "
                f"{seg['freq']:g} Hz, {seg['duration']:g} s")
    if k == "Square":
        return (f"Square {seg['low']:g}/{seg['high']:g}, T={seg['period']:g} s, "
                f"{seg['cycles']}×")
    if k == "Table":
        pts = seg.get("points", [])
        return f"Table, {len(pts)} points, {sum(p[1] for p in pts):g} s"
    if k == "Exponential":
        return (f"Exponential {seg['start']:g} → {seg['end']:g}, τ={seg['tau']:g} s, "
                f"{seg['duration']:g} s")
    if k == "PWM":
        return (f"PWM {seg['low']:g}/{seg['high']:g}, {seg['freq']:g} Hz, duty "
                f"{seg['duty_start']:g}→{seg['duty_end']:g} %, {seg['duration']:g} s")
    if k == "Battery":
        return (f"Battery {seg['v_full']:g}→{seg['v_cutoff']:g} "
                f"(nom. {seg['v_nominal']:g}) in {seg['duration']:g} s")
    if k == "Wait for input":
        return f"Wait until {seg['input']} = {seg['level'][0]}"
    if k == "Wait for trigger":
        return "Wait for trigger (TRIG:IMM)"
    if k == "Combine":
        sym = COMBINE_OPS[seg["op"]][0]
        a, b = describe_segment(seg["a"]), describe_segment(seg["b"])
        if sym in ("min", "max"):
            return f"{sym}({a}, {b})"
        return f"({a}) {sym} ({b})"
    if k == "Triangle":
        return (f"Triangle {seg['low']:g}/{seg['high']:g}, T={seg['period']:g} s, "
                f"{seg['cycles']}×")
    return k


# --------------------------------------------------------------------------
# Continuous evaluation (used by Combine)
# --------------------------------------------------------------------------
COMBINE_OPS = {
    "Add": ("+", lambda a, b: a + b),
    "Subtract": ("−", lambda a, b: a - b),
    "Multiply": ("×", lambda a, b: a * b),
    "Min": ("min", min),
    "Max": ("max", max),
}


def segment_duration(seg: dict) -> float:
    k = seg["type"]
    if k in ("Constant", "Ramp", "Sine"):
        return float(seg["duration"])
    if k in ("Square", "Triangle"):
        return float(seg["period"]) * int(seg["cycles"])
    if k == "Table":
        return float(sum(p[1] for p in seg.get("points", [])))
    if k == "Combine":
        return max(segment_duration(seg["a"]), segment_duration(seg["b"]))
    if k in ("Exponential", "PWM", "Battery"):
        return float(seg["duration"])
    if k in WAIT_TYPES:
        return float(seg["preview"])
    raise ValueError(f"Unknown segment type {k}")


def _pwm_cycles(seg):
    if seg["freq"] <= 0:
        raise ValueError("PWM frequency must be > 0")
    period = 1.0 / seg["freq"]
    n = max(1, int(round(seg["duration"] * seg["freq"])))
    out = []
    for k in range(n):
        f = k / (n - 1) if n > 1 else 0.0
        duty = seg["duty_start"] + (seg["duty_end"] - seg["duty_start"]) * f
        duty = min(max(duty, 0.0), 100.0)
        out.append((period * duty / 100.0, period * (1 - duty / 100.0)))
    return out


def _battery_value(seg, t):
    dur = seg["duration"] or 1.0
    s = min(max(t / dur, 0.0), 1.0)
    vf, vn, vc = seg["v_full"], seg["v_nominal"], seg["v_cutoff"]
    plateau = vn - (vn - vc) * 0.25 * s
    initial = (vf - vn) * math.exp(-s / 0.06)
    knee = (plateau - vc) * math.exp((s - 1.0) / 0.04)
    return plateau + initial - knee


def value_at(seg: dict, t: float) -> float:
    """Value of a segment at time t (s, relative to segment start).
    Beyond its end a segment holds its final value."""
    k = seg["type"]
    dur = segment_duration(seg)
    t = min(max(t, 0.0), dur)
    if k == "Constant":
        return seg["value"]
    if k == "Ramp":
        return seg["start"] + (seg["end"] - seg["start"]) * (t / dur if dur else 1)
    if k == "Sine":
        return seg["offset"] + seg["amplitude"] * math.sin(
            2 * math.pi * seg["freq"] * t + math.radians(seg["phase"]))
    if k == "Square":
        p = seg["period"]
        if p <= 0:
            return seg["low"]
        tt = (t % p) if t < dur else p
        return seg["high"] if tt < p * seg["duty"] / 100.0 else seg["low"]
    if k == "Triangle":
        p = seg["period"]
        if p <= 0 or t >= dur:
            return seg["low"]
        x = (t % p) / p
        f = 2 * x if x < 0.5 else 2 - 2 * x
        return seg["low"] + (seg["high"] - seg["low"]) * f
    if k == "Table":
        acc = 0.0
        pts = seg.get("points", [])
        for v, h in pts:
            acc += h
            if t < acc:
                return v
        return pts[-1][0] if pts else 0.0
    if k == "Combine":
        return COMBINE_OPS[seg["op"]][1](value_at(seg["a"], t), value_at(seg["b"], t))
    if k == "Exponential":
        tau = seg["tau"]
        if tau <= 0:
            return seg["end"]
        return seg["end"] + (seg["start"] - seg["end"]) * math.exp(-t / tau)
    if k == "PWM":
        acc = 0.0
        for hi, lo in _pwm_cycles(seg):
            if t < acc + hi:
                return seg["high"]
            if t < acc + hi + lo:
                return seg["low"]
            acc += hi + lo
        return seg["low"]
    if k == "Battery":
        return _battery_value(seg, t)
    if k in WAIT_TYPES:
        raise ValueError("Wait steps cannot be used inside Combine")
    raise ValueError(f"Unknown segment type {k}")


# --------------------------------------------------------------------------
# Sampling:  segment -> list of (value, hold_time)
# --------------------------------------------------------------------------
def _n(duration: float, dt: float) -> int:
    if dt <= 0:
        raise ValueError("Step/sample time must be > 0")
    return max(1, int(round(duration / dt)))


def sample_segment(seg: dict) -> list[tuple[float, float]]:
    k = seg["type"]
    if k == "Constant":
        return [(seg["value"], seg["duration"])]

    if k == "Ramp":
        n = _n(seg["duration"], seg["dt"])
        dt = seg["duration"] / n
        if n == 1:
            return [(seg["end"], seg["duration"])]
        return [(seg["start"] + (seg["end"] - seg["start"]) * i / (n - 1), dt)
                for i in range(n)]

    if k == "Sine":
        n = _n(seg["duration"], seg["dt"])
        dt = seg["duration"] / n
        ph = math.radians(seg["phase"])
        return [(seg["offset"] + seg["amplitude"]
                 * math.sin(2 * math.pi * seg["freq"] * i * dt + ph), dt)
                for i in range(n)]

    if k == "Table":
        out = []
        for v, t in seg.get("points", []):
            if t <= 0:
                raise ValueError("Table hold times must be > 0")
            out.append((float(v), float(t)))
        return out

    if k in ("Exponential", "Battery"):
        n = _n(seg["duration"], seg["dt"])
        dt = seg["duration"] / n
        # sample so the last step lands exactly on the final value
        return [(value_at(seg, (i / (n - 1)) * seg["duration"] if n > 1 else 0.0), dt)
                for i in range(n)] if n > 1 else [(value_at(seg, seg["duration"]), dt)]

    if k == "PWM":
        out = []
        for hi, lo in _pwm_cycles(seg):
            if hi > 0:
                out.append((seg["high"], hi))
            if lo > 0:
                out.append((seg["low"], lo))
        return out

    if k == "Wait for input":
        lvl = seg["level"][0]
        return [(None, float(seg["preview"]), ("wait_input", seg["input"], lvl))]

    if k == "Wait for trigger":
        return [(None, float(seg["preview"]), ("wait_trigger",))]

    if k == "Combine":
        dur = segment_duration(seg)
        if dur <= 0:
            raise ValueError("Combined signal has zero duration")
        n = _n(dur, seg["dt"])
        dt = dur / n
        return [(value_at(seg, i * dt), dt) for i in range(n)]

    if k == "Square":
        t_high = seg["period"] * seg["duty"] / 100.0
        t_low = seg["period"] - t_high
        out = []
        for _ in range(int(seg["cycles"])):
            if t_high > 0:
                out.append((seg["high"], t_high))
            if t_low > 0:
                out.append((seg["low"], t_low))
        return out

    if k == "Triangle":
        half = seg["period"] / 2.0
        n = _n(half, seg["dt"])
        dt = half / n
        lo, hi = seg["low"], seg["high"]
        up = [lo + (hi - lo) * i / n for i in range(n)]
        down = [hi - (hi - lo) * i / n for i in range(n)]
        return [(v, dt) for _ in range(int(seg["cycles"])) for v in up + down]

    raise ValueError(f"Unknown segment type {k}")


def segment_preview(seg: dict, start_value: float = 0.0) -> list[tuple[float, float]]:
    """(value, hold) pairs for plotting; wait steps keep the previous value."""
    out, last = [], start_value
    for p in sample_segment(seg):
        v = last if p[0] is None else p[0]
        out.append((v, p[1])); last = v
    return out


# --------------------------------------------------------------------------
# Sequence settings + compilation
# --------------------------------------------------------------------------
@dataclass
class SequenceSettings:
    name: str = "SEQ1"
    channel: str = "SV"            # SV, SC, SP, or sink: SCN (current), SPN (power)
    limit_voltage: float = 50.0    # applied when channel != SV
    limit_current: float = 10.0    # applied when channel != SC
    vmax: float = 70.0             # model limits, used for validation only
    cmax: float = 450.0
    pmax: float = 15000.0
    device: str = "SM 70-CP-450"
    repeat: int = 1                # 0 = infinite loop
    final_value_enabled: bool = True
    final_value: float = 0.0
    decimals: int = 3
    merge_equal: bool = True
    nonvolatile: bool = False
    clear_before_upload: bool = True
    run_after_upload: bool = False
    compact_ramps: bool = False    # write linear ramps as INC loops
    min_ramp_points: int = 6
    max_step: float = 0.0          # safety: max change between two set values (0 = off)
    max_rate: float = 0.0          # safety: max |change| / previous hold, unit/s (0 = off)
    safety_errors: bool = False    # treat safety findings as errors
    segments: list[dict] = field(default_factory=list)

    # ---- persistence -----------------------------------------------------
    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, text: str) -> "SequenceSettings":
        data = json.loads(text)
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class CompiledSequence:
    steps: list[str]
    labels: dict[str, int]
    points: list[tuple[float, float]]   # (value, hold) for one pass
    duration_one_pass: float
    warnings: list[str]
    errors: list[str]
    markers: list = field(default_factory=list)   # (time, label) of wait steps


def _fmt(x: float, decimals: int) -> str:
    s = f"{x:.{decimals}f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def compile_sequence(cfg: SequenceSettings) -> CompiledSequence:
    warnings: list[str] = []
    errors: list[str] = []

    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,15}", cfg.name or ""):
        errors.append("Name must start with a letter and be max 16 characters "
                      "(letters, digits, _).")
    if not cfg.segments:
        errors.append("Add at least one segment.")

    # 1. sample all segments  (items: (value|None, hold, meta|None))
    items: list[tuple] = []
    for i, seg in enumerate(cfg.segments, 1):
        try:
            for p in sample_segment(seg):
                items.append((p[0], p[1], p[2] if len(p) > 2 else None))
        except (ValueError, ZeroDivisionError, KeyError) as e:
            errors.append(f"Segment {i}: {e}")

    # 2. round, clamp wait times, merge equal neighbours (never across waits)
    clean: list[list] = []
    short = 0
    last_v = 0.0
    for v, t, meta in items:
        if meta is not None:
            clean.append([last_v, max(float(t), 0.0), meta])
            continue
        v = round(v, cfg.decimals)
        t = round(t, 3)
        if t < MIN_WAIT:
            short += 1
            t = MIN_WAIT
        if (cfg.merge_equal and clean and clean[-1][2] is None
                and clean[-1][0] == v):
            clean[-1][1] += t
        else:
            clean.append([v, t, None])
        last_v = v
    if short:
        warnings.append(f"{short} point(s) shorter than 1 ms were raised to 1 ms.")

    points = [(v, t) for v, t, _m in clean]
    markers, acc = [], 0.0
    for v, t, m in clean:
        if m is not None:
            markers.append((acc, "wait " + (f"{m[1]}={m[2]}" if m[0] == "wait_input"
                                             else "trigger")))
        acc += t
    if markers:
        warnings.append("Wait steps: the preview assumes the wait time you entered; "
                        "on the supply the sequence waits for the real input/trigger.")

    # 3. range checks
    ch = cfg.channel
    vmax = {"SV": cfg.vmax, "SC": cfg.cmax, "SP": cfg.pmax,
            "SCN": cfg.cmax, "SPN": cfg.pmax}[ch]
    vals = [v for v, _t, m in clean if m is None]
    lo, hi = min(vals, default=0), max(vals, default=0)
    if ch in SINK_CHANNELS:
        if hi > 0:
            errors.append(f"{ch} is a sink setting: use values ≤ 0 (e.g. −50), "
                          f"found {hi:g}.")
        if lo < -vmax:
            errors.append(f"{ch} value {lo:g} exceeds model sink max −{vmax:g}.")
        prof = DEVICE_PROFILES.get(cfg.device)
        if prof is not None and not prof.get("sink", False):
            warnings.append(f"{cfg.device} has no built-in sink – {ch} needs a "
                            f"sink-capable model (e.g. SM15K or SM3300 Power Sink option).")
    else:
        if lo < 0:
            errors.append(f"Negative {ch} values ({lo:g}) are not allowed "
                          f"(choose a sink channel SCN/SPN for sink mode).")
        if hi > vmax:
            errors.append(f"{ch} value {hi:g} exceeds model max {vmax:g}.")

    # 3b. safety checks
    safety: list[str] = []
    peak_p = {"SV": hi * cfg.limit_current, "SC": hi * cfg.limit_voltage,
              "SCN": -lo * cfg.limit_voltage}.get(ch)
    if peak_p is not None and peak_p > cfg.pmax * 1.0001:
        safety.append(f"Up to {peak_p:.6g} W possible (V × I) – above the model's "
                      f"{cfg.pmax:g} W; the supply will limit power.")
    seq_vals = [(acc_v, v, t) for acc_v, (v, t, m) in
                zip(_running_times(clean), clean) if m is None]
    if cfg.max_step > 0:
        bad = [(tt, b[1] - a[1]) for a, b in zip(seq_vals, seq_vals[1:])
               for tt in [b[0]] if abs(b[1] - a[1]) > cfg.max_step + 1e-12]
        if bad:
            safety.append(f"{len(bad)} step(s) larger than {cfg.max_step:g} "
                          f"(first at t = {bad[0][0]:.6g} s: Δ = {bad[0][1]:+.6g}).")
    if cfg.max_rate > 0:
        bad = [(b[0], abs(b[1] - a[1]) / a[2]) for a, b in zip(seq_vals, seq_vals[1:])
               if a[2] > 0 and abs(b[1] - a[1]) / a[2] > cfg.max_rate * (1 + 1e-9)]
        if bad:
            worst = max(r for _, r in bad)
            safety.append(f"{len(bad)} change(s) faster than {cfg.max_rate:g}/s "
                          f"(first at t = {bad[0][0]:.6g} s, worst {worst:.6g}/s).")
    for msg in safety:
        (errors if cfg.safety_errors else warnings).append("Safety: " + msg)
    if ch != "SV" and cfg.limit_voltage > cfg.vmax:
        errors.append(f"Voltage limit {cfg.limit_voltage:g} exceeds model max {cfg.vmax:g}.")
    if cfg.channel != "SC" and cfg.limit_current > cfg.cmax:
        errors.append(f"Current limit {cfg.limit_current:g} exceeds model max {cfg.cmax:g}.")

    # 4. build steps
    steps: list[str] = []
    labels: dict[str, int] = {}
    d = cfg.decimals
    if cfg.channel != "SV":
        steps.append(f"SV={_fmt(cfg.limit_voltage, d)}")
    if cfg.channel != "SC":
        steps.append(f"SC={_fmt(cfg.limit_current, d)}")
    if cfg.repeat > 1:
        steps.append("#A=0")

    loop_start = len(steps) + 1
    i = 0
    n_compact = 0
    while i < len(clean):
        v, t, meta = clean[i]
        if meta is not None:
            if meta[0] == "wait_input":
                n = len(steps) + 1
                steps.append("NOP")
                steps.append(f"CJNE {meta[1]},{meta[2]},{n}")
            else:
                steps.append("TRG")
            i += 1
            continue
        if cfg.compact_ramps:
            run, inc = _linear_run(clean, i, d)
            if run >= max(cfg.min_ramp_points, 3):
                steps.append(f"{ch}={_fmt(v, d)}")
                steps.append("#B=0")
                w_step = len(steps) + 1
                steps.append(f"W={_fmt(t, 3)}")
                steps.append(f"INC {ch},{_fmt(inc, d + 4)}" if inc > 0
                             else f"DEC {ch},{_fmt(-inc, d + 4)}")
                steps.append("INC #B,1")
                steps.append(f"CJL #B,{run - 1},{w_step}")
                steps.append(f"W={_fmt(clean[i + run - 1][1], 3)}")
                i += run
                n_compact += 1
                continue
        steps.append(f"{ch}={_fmt(v, d)}")
        while t > MAX_WAIT:
            steps.append(f"W={_fmt(MAX_WAIT, 3)}")
            t -= MAX_WAIT
        steps.append(f"W={_fmt(t, 3)}")
        i += 1
    if n_compact:
        warnings.append(f"Compact ramps: {n_compact} linear run(s) written as INC loops "
                        f"(uses variable #B).")

    if cfg.repeat == 0:
        labels["LOOP"] = loop_start
        steps.append("JP LOOP")
    elif cfg.repeat > 1:
        if cfg.repeat > 65535:
            errors.append("Repeat count max is 65535.")
        steps.append("INC #A,1")
        steps.append(f"CJL #A,{cfg.repeat},{loop_start}")

    if cfg.final_value_enabled and cfg.repeat != 0:
        steps.append(f"{cfg.channel}={_fmt(cfg.final_value, d)}")
    steps.append("END")

    if len(steps) > MAX_STEPS:
        errors.append(f"{len(steps)} steps – the sequencer holds max {MAX_STEPS}. "
                      f"Increase step/sample times or shorten the signal.")
    elif len(steps) > 0.9 * MAX_STEPS:
        warnings.append(f"{len(steps)} of {MAX_STEPS} steps used.")

    return CompiledSequence(
        steps=steps, labels=labels, points=points,
        duration_one_pass=sum(t for _, t in points),
        warnings=warnings, errors=errors, markers=markers)


SINK_CHANNELS = ("SCN", "SPN")


def _running_times(clean):
    acc = 0.0
    for p in clean:
        yield acc
        acc += p[1]


def _linear_run(clean, i, decimals):
    """Length of a linear run starting at i (equal holds, constant increment)
    and the increment (with 4 extra decimals). Every value the supply produces
    (v0 + k·inc) stays within half an LSB of the value in the file."""
    if i + 1 >= len(clean) or clean[i + 1][2] is not None:
        return 1, 0.0
    v0, t0 = clean[i][0], clean[i][1]
    if t0 > MAX_WAIT:
        return 1, 0.0
    tol = 0.5 * 10 ** (-decimals) * (1 + 1e-6)
    lo, hi = -math.inf, math.inf
    n, k = 1, i + 1
    best = None
    while (k < len(clean) and clean[k][2] is None
           and abs(clean[k - 1][1] - t0) < 1e-9 and k - i < 65535):
        j = k - i
        nlo = max(lo, (clean[k][0] - v0 - tol) / j)
        nhi = min(hi, (clean[k][0] - v0 + tol) / j)
        if nlo > nhi:
            break
        inc = round((nlo + nhi) / 2, decimals + 4)
        if not (nlo <= inc <= nhi) or (nlo <= 0 <= nhi):
            if nlo <= 0 <= nhi and j == 1:
                return 1, 0.0          # flat, not a ramp
            if not (nlo <= inc <= nhi):
                break
        lo, hi = nlo, nhi
        if not (lo <= 0 <= hi):
            best = (j + 1, inc)
        n, k = j + 1, k + 1
    if best is None:
        return 1, 0.0
    run, inc = best
    # final check with the rounded increment
    for j in range(run):
        if abs(clean[i + j][0] - (v0 + j * inc)) > tol + 1e-12:
            return 1, 0.0
    return run, inc


# --------------------------------------------------------------------------
# Text output
# --------------------------------------------------------------------------
def to_scpi_lines(cfg: SequenceSettings, comp: CompiledSequence) -> list[str]:
    """Commands to send over TCP to upload (and optionally run) the sequence."""
    out = [f"PROG:SEL:NAM {cfg.name}"]
    if cfg.clear_before_upload:
        out += ["PROG:SEL:DEL", f"PROG:SEL:NAM {cfg.name}"]
    for i, s in enumerate(comp.steps, 1):
        out.append(f"PROG:SEL:STE {i} {s}")
    for lbl, step in comp.labels.items():
        out.append(f"PROG:SEL:LAB {lbl},{step}")
    if cfg.nonvolatile:
        out += ["PROG:SEL:NON", "PROG:SAV"]
    if cfg.run_after_upload:
        out.append("PROG:SEL:STA RUN")
    return out


def to_text(cfg: SequenceSettings, comp: CompiledSequence, fmt: str = "scpi") -> str:
    header = [
        f"# Delta Elektronika sequence '{cfg.name}'",
        f"# channel={cfg.channel} steps={len(comp.steps)} "
        f"one_pass={comp.duration_one_pass:.3f}s "
        f"repeat={'infinite' if cfg.repeat == 0 else cfg.repeat}",
    ]
    if fmt == "steps":
        body = [f"{i} {s}" for i, s in enumerate(comp.steps, 1)]
        body += [f"# label {k} = step {v}" for k, v in comp.labels.items()]
    else:
        body = to_scpi_lines(cfg, comp)
    return "\n".join(header + body) + "\n"


# --------------------------------------------------------------------------
# Upload over Ethernet
# --------------------------------------------------------------------------
def upload(host: str, port: int, lines: list[str], delay: float = 0.01,
           timeout: float = 3.0, log=print) -> None:
    with socket.create_connection((host, port), timeout=timeout) as s:
        for line in lines:
            if not line or line.startswith("#"):
                continue
            s.sendall((line + "\n").encode("ascii"))
            time.sleep(delay)
        s.sendall(b"PROG:SEL:STA?\n")
        try:
            log("Sequencer state: " + s.recv(256).decode(errors="replace").strip())
        except socket.timeout:
            log("No reply to PROG:SEL:STA? (upload sent anyway).")


# ==========================================================================
# Reading existing sequence files + simulation
# ==========================================================================
STEP_EXEC_TIME = 125e-6          # approx. execution time of one step

_NUM = r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?"
_RE_STE = re.compile(r"^PROG(?:RAM)?:SEL(?:ECTED)?:STE(?:P)?\s+(\d+)\s+(.+)$", re.I)
_RE_NAM = re.compile(r"^PROG(?:RAM)?:SEL(?:ECTED)?:NAME?\s+(\S+)", re.I)
_RE_LAB = re.compile(r"^PROG(?:RAM)?:SEL(?:ECTED)?:LAB(?:EL)?\s+([^,\s]+)\s*,\s*(\S+)", re.I)
_RE_LAB_COMMENT = re.compile(r"^#\s*label\s+(\S+)\s*=\s*step\s+(\d+)", re.I)
_RE_NUMBERED = re.compile(r"^(\d+)\s*[:.)]?\s+(.+)$")
_RE_BARE = re.compile(
    r"^(SCN|SPN|SV|SC|SP|W|#[A-J]|O[A-H]\d|JP|JS|RET|CJNE|CJE|CJG|CJL|INC|DEC|NOP|TRG|END)\b",
    re.I)


@dataclass
class ParsedSequence:
    name: str
    steps: dict[int, str]              # step number -> command (upper case)
    labels: dict[str, int]
    warnings: list[str]


def _strip_comment(line: str) -> str:
    for mark in ("//", ";"):
        if mark in line:
            line = line.split(mark, 1)[0]
    return line.strip()


def parse_sequence_text(text: str) -> ParsedSequence:
    """Accepts SCPI upload files (PROG:SEL:STE n cmd), numbered step lists
    ('n cmd') or bare command lists (one step per line)."""
    name, steps, labels, warnings = "IMPORTED", {}, {}, []
    bare: list[str] = []
    for ln, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        m = _RE_LAB_COMMENT.match(line)
        if m:
            labels[m.group(1).upper()] = int(m.group(2)); continue
        if line.startswith("#") and (len(line) == 1 or line[1] in " \t#"):
            continue                                  # comment, not '#A=0'
        line = _strip_comment(line)
        if not line:
            continue
        if m := _RE_STE.match(line):
            n, cmd = int(m.group(1)), m.group(2)
            if n in steps:
                warnings.append(f"Line {ln}: step {n} defined twice, last one wins.")
            steps[n] = cmd.strip().upper(); continue
        if m := _RE_NAM.match(line):
            name = m.group(1); continue
        if m := _RE_LAB.match(line):
            lbl, val = m.group(1).upper(), m.group(2)
            if val.upper() == "DELETE":
                labels.pop(lbl, None)
            elif val.isdigit():
                labels[lbl] = int(val)
            continue
        if line.upper().startswith(("PROG", "*", "SYST", "OUTP", "SOUR", "TRIG")):
            continue                                  # other remote commands
        if m := _RE_NUMBERED.match(line):
            if _RE_BARE.match(m.group(2).strip()):
                steps[int(m.group(1))] = m.group(2).strip().upper(); continue
        if _RE_BARE.match(line):
            bare.append(line.upper()); continue
        warnings.append(f"Line {ln}: not understood, ignored: {raw.strip()}")

    if bare and not steps:
        steps = {i: c for i, c in enumerate(bare, 1)}
    elif bare:
        warnings.append(f"{len(bare)} un-numbered command line(s) ignored "
                        f"(file also contains numbered steps).")
    if not steps:
        warnings.append("No sequencer steps found in file.")
    return ParsedSequence(name, dict(sorted(steps.items())), labels, warnings)


@dataclass
class SimResult:
    traces: dict[str, list[tuple[float, float]]]  # channel -> [(t, value)]
    end_time: float
    executed: int
    stop_reason: str
    warnings: list[str]
    errors: list[str]


def simulate(seq: ParsedSequence, max_time: float = 600.0,
             max_exec: int = 500_000, inputs: dict[str, int] | None = None,
             step_time: float = STEP_EXEC_TIME) -> SimResult:
    inputs = {k.upper(): v for k, v in (inputs or {}).items()}
    order = list(seq.steps)
    index = {n: i for i, n in enumerate(order)}
    state = {"SV": 0.0, "SC": 0.0, "SP": 0.0, "SCN": 0.0, "SPN": 0.0}
    var = {c: 0 for c in "ABCDEFGH"}
    timers = {"I": (0, 0.0), "J": (0, 0.0)}           # value, set-time
    tick = {"I": 0.001, "J": 0.1}
    outputs: dict[str, int] = {}
    traces: dict[str, list[tuple[float, float]]] = {}
    used: set[str] = set()
    warnings: list[str] = []
    errors: list[str] = []
    warned: set[str] = set()
    stack: list[int] = []
    t, executed, pc = 0.0, 0, 0

    def warn_once(key, msg):
        if key not in warned:
            warned.add(key); warnings.append(msg)

    def record(ch, v):
        traces.setdefault(ch, [])
        if traces[ch] and traces[ch][-1][0] == t:
            traces[ch][-1] = (t, v)
        else:
            traces[ch].append((t, v))

    for ch in state:                                   # start at 0
        traces[ch] = [(0.0, 0.0)]

    def timer_val(c):
        v, t0 = timers[c]
        return max(0, v - int((t - t0) / tick[c] + 1e-9))

    def get(op: str) -> float:
        op = op.strip().upper()
        if op in state:
            return state[op]
        if op in ("MV", "MC", "MP", "MCN", "MPN"):
            warn_once("meas", "Measured values (MV/MC/MP) are assumed equal "
                              "to the set values in the simulation.")
            return state[{"MV": "SV", "MC": "SC", "MP": "SP",
                          "MCN": "SCN", "MPN": "SPN"}[op]]
        if re.fullmatch(r"#[A-H]", op):
            return var[op[1]]
        if op in ("#I", "#J"):
            return timer_val(op[1])
        if re.fullmatch(r"I[A-H]\d", op):
            if op not in inputs:
                warn_once("in" + op, f"Digital input {op} assumed 0 "
                                     f"(set it in the simulation options).")
            return inputs.get(op, 0)
        if re.fullmatch(r"O[A-H]\d", op):
            return outputs.get(op, 0)
        try:
            return float(op)
        except ValueError:
            raise ValueError(f"unknown operand '{op}'")

    def target(tok: str, here: int) -> int:
        tok = tok.strip().upper()
        n = int(tok) if tok.isdigit() else seq.labels.get(tok)
        if n is None:
            raise ValueError(f"step {here}: unknown label '{tok}'")
        if n not in index:
            raise ValueError(f"step {here}: jump to non-existing step {n}")
        return index[n]

    def set_value(op: str, v: float):
        op = op.upper()
        if op in state:
            state[op] = v; record(op, v); used.add(op)
        elif re.fullmatch(r"#[A-H]", op):
            var[op[1]] = int(v) & 0xFFFF
        elif op in ("#I", "#J"):
            timers[op[1]] = (max(0, int(v)), t)
        elif re.fullmatch(r"O[A-H]\d", op):
            outputs[op] = 1 if v else 0
            record(op, outputs[op]); used.add(op)
        else:
            raise ValueError(f"cannot assign to '{op}'")

    stop = "Sequence is empty." if not order else ""
    while order and not stop:
        if pc >= len(order):
            stop = "Ran past the last step (no END)."; break
        if executed >= max_exec:
            stop = (f"Stopped after {executed} executed steps without reaching "
                    f"END – probably waiting on an input or timer at step "
                    f"{order[pc]}."); break
        if t >= max_time:
            stop = (f"Stopped at the simulation limit of {max_time:g} s "
                    f"(sequence loops / still running)."); break
        n = order[pc]
        cmd = seq.steps[n]
        executed += 1
        t += step_time
        nxt = pc + 1
        try:
            if m := re.fullmatch(r"(SCN|SPN|SV|SC|SP|#[A-J]|O[A-H]\d)\s*=\s*(\S+)", cmd):
                op, val = m.groups()
                if val in ("ON", "TRUE"): val = "1"
                if val in ("OFF", "FALSE"): val = "0"
                set_value(op, float(val))
            elif m := re.fullmatch(rf"W\s*=\s*({_NUM})", cmd):
                w = float(m.group(1))
                if not MIN_WAIT <= w <= MAX_WAIT:
                    warn_once(f"w{n}", f"Step {n}: wait {w:g} s outside "
                                       f"0.001..65535 s.")
                t += w
            elif m := re.fullmatch(r"(JP|JS)\s+(\S+)", cmd):
                if m.group(1) == "JS":
                    if len(stack) >= 6:
                        raise ValueError(f"step {n}: more than 6 nested JS")
                    stack.append(nxt)
                nxt = target(m.group(2), n)
            elif cmd == "RET":
                if not stack:
                    raise ValueError(f"step {n}: RET without JS")
                nxt = stack.pop()
            elif m := re.fullmatch(r"(CJE|CJNE|CJG|CJL)\s+([^,]+),([^,]+),(.+)", cmd):
                kind, a, b, tgt = m.groups()
                va, vb = get(a), get(b)
                ok = {"CJE": va == vb, "CJNE": va != vb,
                      "CJG": va > vb, "CJL": va < vb}[kind]
                if ok:
                    nxt = target(tgt, n)
            elif m := re.fullmatch(r"(INC|DEC)\s+([^,]+),\s*(\S+)", cmd):
                kind, op, d = m.groups()
                d = float(d) * (1 if kind == "INC" else -1)
                cur = get(op)
                new = cur + d
                if op.strip() in ("SV", "SC", "SP"):
                    new = max(0.0, new)
                set_value(op.strip(), new)
            elif cmd == "NOP":
                pass
            elif cmd == "TRG":
                warn_once("trg", f"Step {n}: TRG (wait for trigger) treated as "
                                 f"triggered immediately.")
            elif cmd == "END":
                stop = f"END reached at step {n}."
            else:
                warn_once(f"u{n}", f"Step {n}: '{cmd}' not understood, "
                                   f"treated as NOP.")
        except ValueError as e:
            errors.append(str(e)); stop = f"Simulation error: {e}"; break
        pc = nxt

    # keep only channels that were actually used (but always SV/SC)
    traces = {k: v for k, v in traces.items() if k in used or k in ("SV", "SC")}
    if "END" not in seq.steps.values():
        warnings.append("Sequence has no END step.")
    return SimResult(traces, t, executed, stop, seq.warnings + warnings, errors)


def trace_to_points(trace: list[tuple[float, float]], end_time: float,
                    decimals: int = 3) -> list[list[float]]:
    """Convert a simulated trace into [value, hold] pairs (for a Table segment)."""
    pts: list[list[float]] = []
    for i, (t0, v) in enumerate(trace):
        t1 = trace[i + 1][0] if i + 1 < len(trace) else end_time
        hold = round(t1 - t0, 3)
        if hold < MIN_WAIT:
            continue
        v = round(v, decimals)
        if pts and pts[-1][0] == v:
            pts[-1][1] = round(pts[-1][1] + hold, 3)
        else:
            pts.append([v, hold])
    return pts


# ==========================================================================
# Importing measured samples (timestamp / value) from CSV, TXT or Excel
# ==========================================================================
TIME_UNITS = {"µs": 1e-6, "ms": 1e-3, "s": 1.0, "min": 60.0, "h": 3600.0,
              "hh:mm:ss / date-time": None}


def read_table_file(path: str) -> list[list[str]]:
    """Return the raw cells of a CSV/TXT/TSV or Excel file as strings."""
    low = path.lower()
    if low.endswith((".xlsx", ".xlsm")):
        try:
            import openpyxl
        except ImportError:
            raise ValueError("Reading Excel needs 'openpyxl' (pip install openpyxl).")
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.worksheets[0]
        rows = [["" if c is None else str(c) for c in r]
                for r in ws.iter_rows(values_only=True)]
        wb.close()
        return [r for r in rows if any(x.strip() for x in r)]

    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        lines = [ln.rstrip("\r\n") for ln in fh if ln.strip()]
    lines = [ln for ln in lines if not ln.lstrip().startswith(("#", "//"))]
    sample = lines[:50]
    # choose delimiter: the one that gives a consistent column count > 1
    best, best_score = None, 0
    for d in ("\t", ";", ",", "|"):
        counts = [len(ln.split(d)) for ln in sample]
        if counts and min(counts) > 1:
            score = sum(1 for c in counts if c == counts[-1])
            if score > best_score:
                best, best_score = d, score
    if best is None:
        return [ln.split() for ln in lines]          # whitespace separated
    rows = [[c.strip().strip('"') for c in ln.split(best)] for ln in lines]
    if best == ";":                                  # European decimal comma
        rows = [[c.replace(",", ".") if re.fullmatch(r"[-+]?\d+,\d+", c) else c
                 for c in r] for r in rows]
    return rows


def _to_float(s: str) -> float | None:
    try:
        return float(str(s).strip().replace(",", ".") if re.fullmatch(
            r"\s*[-+]?\d+,\d+\s*", str(s)) else s)
    except (TypeError, ValueError):
        return None


def _parse_clock(s: str) -> float | None:
    """'12:03:04.5', '03:04', '2026-11-19 12:03:04.500' -> seconds."""
    from datetime import datetime
    s = str(s).strip()
    try:
        return datetime.fromisoformat(s.replace("/", "-")).timestamp()
    except ValueError:
        pass
    m = re.fullmatch(r"(?:(\d+):)?(\d+):(\d+(?:[.,]\d+)?)", s)
    if m:
        h, mi, sec = m.groups()
        return int(h or 0) * 3600 + int(mi) * 60 + float(sec.replace(",", "."))
    return None


def detect_header(rows: list[list[str]]) -> bool:
    if not rows:
        return False
    first = rows[0]
    return not any(_to_float(c) is not None or _parse_clock(c) is not None
                   for c in first if c.strip())


def extract_samples(rows: list[list[str]], tcol: int, vcol: int, unit: str,
                    has_header: bool) -> tuple[list[tuple[float, float]], int]:
    """Return ([(t_seconds, value)], skipped_row_count)."""
    out, skipped = [], 0
    factor = TIME_UNITS[unit]
    for r in rows[1 if has_header else 0:]:
        if max(tcol, vcol) >= len(r):
            skipped += 1; continue
        v = _to_float(r[vcol])
        t = _parse_clock(r[tcol]) if factor is None else _to_float(r[tcol])
        if t is None or v is None:
            skipped += 1; continue
        out.append((t if factor is None else t * factor, v))
    return out, skipped


@dataclass
class SampleImportOptions:
    time_is_duration: bool = False   # False: timestamps, True: hold time per sample
    zero_start: bool = True          # shift first timestamp to t = 0
    continuous: bool = False         # False: step/hold, True: linear interpolation
    resample_dt: float = 0.1         # s, used when continuous
    last_hold: float = 1.0           # s, hold time of the last sample
    min_hold: float = 0.001          # s, shorter steps are merged (step mode)
    scale: float = 1.0
    offset: float = 0.0
    decimals: int = 3


def samples_to_points(samples: list[tuple[float, float]],
                      o: SampleImportOptions) -> tuple[list[list[float]], list[str]]:
    """Turn (time, value) samples into [value, hold] points for a Table segment."""
    warn: list[str] = []
    if not samples:
        return [], ["No numeric samples found."]

    # durations -> timestamps
    if o.time_is_duration:
        ts, acc = [], 0.0
        for d, v in samples:
            ts.append((acc, v)); acc += d
        samples, end_t = ts, acc
    else:
        if any(b[0] < a[0] for a, b in zip(samples, samples[1:])):
            warn.append("Timestamps were not in order – samples sorted by time.")
            samples = sorted(samples, key=lambda x: x[0])
        dup = sum(1 for a, b in zip(samples, samples[1:]) if a[0] == b[0])
        if dup:
            warn.append(f"{dup} duplicate timestamp(s) – the later value is used.")
            dedup = {}
            for t, v in samples:
                dedup[t] = v
            samples = sorted(dedup.items())
        end_t = samples[-1][0] + o.last_hold

    samples = [(t, v * o.scale + o.offset) for t, v in samples]
    t0 = samples[0][0]
    lead = []
    if o.zero_start:
        samples = [(t - t0, v) for t, v in samples]
        end_t -= t0
    elif t0 > 0:
        lead = [[0.0, t0]]                     # output 0 until the first sample
        warn.append(f"Output is 0 for the first {t0:g} s (before the first sample).")
    elif t0 < 0:
        warn.append("Negative timestamps – enable 'start at 0'.")
        samples = [(t - t0, v) for t, v in samples]; end_t -= t0

    pts: list[list[float]] = []
    if o.continuous and len(samples) > 1:
        if o.resample_dt < MIN_WAIT:
            raise ValueError("Resample step must be at least 1 ms.")
        last_t = samples[-1][0]
        n = max(1, int(math.ceil((last_t - samples[0][0]) / o.resample_dt - 1e-9)))
        j = 0
        for k in range(n):
            t = samples[0][0] + k * o.resample_dt
            while j < len(samples) - 2 and samples[j + 1][0] <= t:
                j += 1
            (ta, va), (tb, vb) = samples[j], samples[j + 1]
            v = va if tb == ta else va + (vb - va) * (t - ta) / (tb - ta)
            hold = min(o.resample_dt, last_t - t)
            pts.append([v, hold])
        tail = end_t - last_t
        pts.append([samples[-1][1], tail if tail > 0 else MIN_WAIT])
    else:
        for i, (t, v) in enumerate(samples):
            t_next = samples[i + 1][0] if i + 1 < len(samples) else end_t
            pts.append([v, t_next - t])
        if pts[-1][1] <= 0:
            pts[-1][1] = MIN_WAIT

    # round, merge short steps and equal neighbours
    merged: list[list[float]] = []
    short = 0
    pending_extra = 0.0
    for v, h in lead + pts:
        v = round(v, o.decimals)
        if h < o.min_hold and not o.continuous:
            short += 1
            if merged:
                merged[-1][1] += h        # absorb into previous step
            else:
                pending_extra += h
            continue
        h += pending_extra; pending_extra = 0.0
        if merged and merged[-1][0] == v:
            merged[-1][1] += h
        else:
            merged.append([v, h])
    if pending_extra and merged:
        merged[0][1] += pending_extra
    for p in merged:
        p[1] = max(MIN_WAIT, round(p[1], 3))
    if short:
        warn.append(f"{short} sample(s) shorter than the minimum hold "
                    f"({o.min_hold * 1000:g} ms) were merged into the previous step.")
    return merged, warn


# ==========================================================================
# Re-exporting (edited) sequence scripts
# ==========================================================================
_JUMP_RE = re.compile(r"^(JP|JS)\s+(\d+)$")
_CJ_RE = re.compile(r"^(CJE|CJNE|CJG|CJL)\s+([^,]+),([^,]+),\s*(\d+)$")


def renumber_steps(seq: ParsedSequence) -> ParsedSequence:
    """Number steps 1..n without gaps and fix numeric jump targets / labels."""
    old = list(seq.steps)
    if old == list(range(1, len(old) + 1)):
        return seq
    new_of = {o: i for i, o in enumerate(old, 1)}

    def fix(n: int) -> int:
        if n in new_of:
            return new_of[n]
        later = [o for o in old if o > n]          # target was an empty step
        return new_of[later[0]] if later else len(old)

    steps = {}
    for o, cmd in seq.steps.items():
        if m := _JUMP_RE.match(cmd):
            cmd = f"{m.group(1)} {fix(int(m.group(2)))}"
        elif m := _CJ_RE.match(cmd):
            cmd = f"{m.group(1)} {m.group(2)},{m.group(3)},{fix(int(m.group(4)))}"
        steps[new_of[o]] = cmd
    labels = {k: fix(v) for k, v in seq.labels.items()}
    return ParsedSequence(seq.name, steps, labels, list(seq.warnings))


def parsed_to_text(seq: ParsedSequence, name: str | None = None, fmt: str = "scpi",
                   clear_before_upload: bool = True, renumber: bool = True,
                   nonvolatile: bool = False, run: bool = False) -> str:
    """Write a (possibly hand-edited) parsed sequence back to a file, keeping
    loops, labels and jumps exactly as they are."""
    if renumber:
        seq = renumber_steps(seq)
    name = name or seq.name
    out = [f"# Delta Elektronika sequence '{name}'",
           f"# steps={len(seq.steps)}"]
    if fmt == "steps":
        out += [f"{n} {c}" for n, c in seq.steps.items()]
        out += [f"# label {k} = step {v}" for k, v in seq.labels.items()]
    else:
        out.append(f"PROG:SEL:NAM {name}")
        if clear_before_upload:
            out += ["PROG:SEL:DEL", f"PROG:SEL:NAM {name}"]
        out += [f"PROG:SEL:STE {n} {c}" for n, c in seq.steps.items()]
        out += [f"PROG:SEL:LAB {k},{v}" for k, v in seq.labels.items()]
        if nonvolatile:
            out += ["PROG:SEL:NON", "PROG:SAV"]
        if run:
            out.append("PROG:SEL:STA RUN")
    return "\n".join(out) + "\n"


# ==========================================================================
# Step-signal measurements (used by the plot cursors) and sample export
# ==========================================================================
CHANNEL_UNITS = {"SV": "V", "SC": "A", "SP": "W", "SCN": "A", "SPN": "W"}


def step_value_at(xs: list[float], ys: list[float], t: float) -> float | None:
    """Value of a 'step-post' signal at time t."""
    import bisect
    if not xs:
        return None
    i = bisect.bisect_right(xs, t) - 1
    return ys[max(0, min(i, len(ys) - 1))]


def step_stats(xs: list[float], ys: list[float], a: float, b: float) -> dict | None:
    """min / max / time-weighted mean / RMS of a step signal between a and b."""
    if not xs:
        return None
    a, b = min(a, b), max(a, b)
    if b <= a:
        v = step_value_at(xs, ys, a)
        return {"min": v, "max": v, "mean": v, "rms": abs(v)}
    vmin, vmax, area, area2 = math.inf, -math.inf, 0.0, 0.0
    bounds = list(xs) + [math.inf]
    v0 = step_value_at(xs, ys, a)
    segs = [(a, v0)] + [(x, y) for x, y in zip(xs, ys) if a < x < b]
    for i, (x, y) in enumerate(segs):
        x_end = segs[i + 1][0] if i + 1 < len(segs) else b
        w = x_end - x
        vmin, vmax = min(vmin, y), max(vmax, y)
        area += y * w; area2 += y * y * w
    span = b - a
    return {"min": vmin, "max": vmax, "mean": area / span,
            "rms": math.sqrt(max(area2, 0) / span)}


def traces_to_table(traces: dict[str, list[tuple[float, float]]], end_time: float,
                    style: str = "steps", dt: float = 0.01, unit: str = "s",
                    decimals: int = 6) -> tuple[list[str], list[list[float]]]:
    """Convert step traces into rows of samples.

    style: 'steps'  – two rows at every change (exact step shape)
           'changes'– one row per change point
           'fixed'  – one row every dt seconds
    """
    factor = TIME_UNITS.get(unit) or 1.0
    names = list(traces)
    xs = {n: [t for t, _ in traces[n]] for n in names}
    ys = {n: [v for _, v in traces[n]] for n in names}

    def row(t, before=False):
        vals = []
        for n in names:
            if before:
                import bisect
                i = bisect.bisect_left(xs[n], t) - 1
                vals.append(ys[n][max(i, 0)])
            else:
                vals.append(step_value_at(xs[n], ys[n], t))
        return [round(t / factor, decimals)] + [round(v, decimals) for v in vals]

    rows: list[list[float]] = []
    if style == "fixed":
        if dt <= 0:
            raise ValueError("Sample interval must be > 0")
        n = int(math.floor(end_time / dt + 1e-9))
        if n > 2_000_000:
            raise ValueError("Too many rows – use a larger sample interval.")
        rows = [row(k * dt) for k in range(n + 1)]
    else:
        times = sorted({t for n in names for t in xs[n] if t <= end_time} | {end_time, 0.0})
        for t in times:
            r = row(t)
            if style == "steps" and rows and t > 0:
                rb = row(t, before=True)
                if rb[1:] != r[1:]:
                    rows.append(rb)
            if not rows or rows[-1] != r:
                rows.append(r)
    header = [f"Time [{unit}]"] + [
        f"{n} [{CHANNEL_UNITS[n]}]" if n in CHANNEL_UNITS else n for n in names]
    return header, rows


def write_table_file(path: str, header: list[str], rows: list[list[float]],
                     delimiter: str = ",") -> None:
    if path.lower().endswith((".xlsx", ".xlsm")):
        try:
            import openpyxl
        except ImportError:
            raise ValueError("Writing Excel needs 'openpyxl' (pip install openpyxl).")
        wb = openpyxl.Workbook(write_only=True)
        ws = wb.create_sheet("Samples")
        ws.append(header)
        for r in rows:
            ws.append(r)
        wb.save(path)
        return
    import csv
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, delimiter=delimiter)
        w.writerow(header)
        for r in rows:
            w.writerow([f"{x:g}" if isinstance(x, float) else x for x in r])


def simulate_settings(cfg: SequenceSettings, passes: int = 1) -> SimResult:
    """Simulate the sequence that the editor would generate (ideal timing)."""
    comp = compile_sequence(cfg)
    seq = parse_sequence_text(to_text(cfg, comp, "steps"))
    inputs = {}
    for sg in _walk_segments(cfg.segments):
        if sg["type"] == "Wait for input":
            inputs[sg["input"]] = int(sg["level"][0])
    one = max(comp.duration_one_pass, 1e-3)
    if cfg.repeat > 0 and passes >= cfg.repeat:
        limit = one * cfg.repeat + 3600.0          # runs to END
    else:
        limit = one * max(passes, 1) - 1e-9        # stop after N passes
    return simulate(seq, max_time=limit, step_time=0.0, inputs=inputs)


def _walk_segments(segs):
    for sg in segs:
        yield sg
        if sg.get("type") == "Combine":
            yield from _walk_segments([sg["a"], sg["b"]])


# ==========================================================================
# Device profiles (ratings from the Delta Elektronika SM15K / SM3300 datasheets)
# ==========================================================================
DEVICE_PROFILES: dict[str, dict] = {
    # SM15K series – 15 kW bi-directional
    "SM 70-CP-450":     {"vmax": 70.0,   "cmax": 450.0, "pmax": 15000.0, "sink": True},
    "SM 210-CP-150":    {"vmax": 210.0,  "cmax": 150.0, "pmax": 15000.0, "sink": True},
    "SM 500-CP-90":     {"vmax": 500.0,  "cmax": 90.0,  "pmax": 15000.0, "sink": True},
    "SM 1000-CP-45":    {"vmax": 1000.0, "cmax": 45.0,  "pmax": 15000.0, "sink": True},
    "SM 1500-CP-30":    {"vmax": 1500.0, "cmax": 30.0,  "pmax": 15000.0, "sink": True},
    # SM3300 series – 3.3 kW (auto-ranging models: full-range maxima)
    "SM 18-220":      {"vmax": 18.0,   "cmax": 220.0, "pmax": 3300.0, "sink": False},
    "SM 66-AR-110":   {"vmax": 66.0,   "cmax": 110.0, "pmax": 3300.0, "sink": False},
    "SM 100-AR-75":   {"vmax": 100.0,  "cmax": 75.0,  "pmax": 3300.0, "sink": False},
    "SM 330-AR-22":   {"vmax": 330.0,  "cmax": 22.0,  "pmax": 3300.0, "sink": False},
    "SM 660-AR-11":   {"vmax": 660.0,  "cmax": 11.0,  "pmax": 3300.0, "sink": False},
}
CUSTOM_DEVICE = "Custom"
DEFAULT_PORT = 8462          # Delta Elektronika standard TCP port

DEFAULT_QUERIES = {"V": "MEAS:VOLT?", "I": "MEAS:CURR?", "P": "MEAS:POW?"}


# ==========================================================================
# Communication with the power supply (TCP, line based)
# ==========================================================================
class PsuError(Exception):
    pass


class PsuConnection:
    """Minimal line-based TCP client for Delta Elektronika supplies."""

    def __init__(self, host: str, port: int = DEFAULT_PORT, timeout: float = 2.0,
                 delay: float = 0.0):
        self.host, self.port, self.timeout, self.delay = host, port, timeout, delay
        self.sock: socket.socket | None = None
        self._buf = b""

    def open(self):
        try:
            self.sock = socket.create_connection((self.host, self.port),
                                                 timeout=self.timeout)
        except OSError as e:
            raise PsuError(f"Cannot connect to {self.host}:{self.port} – {e}") from e
        self._buf = b""
        return self

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            finally:
                self.sock = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *exc):
        self.close()

    def write(self, cmd: str):
        if not self.sock:
            raise PsuError("Not connected")
        try:
            self.sock.sendall((cmd.strip() + "\n").encode("ascii", "replace"))
        except OSError as e:
            raise PsuError(f"Send failed: {e}") from e
        if self.delay:
            time.sleep(self.delay)

    def _readline(self, timeout: float) -> str | None:
        end = time.monotonic() + timeout
        while b"\n" not in self._buf:
            left = end - time.monotonic()
            if left <= 0:
                return None
            self.sock.settimeout(left)
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout:
                return None
            except OSError as e:
                raise PsuError(f"Receive failed: {e}") from e
            if not chunk:
                raise PsuError("Connection closed by the power supply")
            self._buf += chunk
        line, self._buf = self._buf.split(b"\n", 1)
        return line.decode("ascii", "replace").strip("\r ")

    def query(self, cmd: str, timeout: float | None = None) -> str:
        self.write(cmd)
        line = self._readline(self.timeout if timeout is None else timeout)
        if line is None:
            raise PsuError(f"No reply to '{cmd}'")
        return line

    def query_lines(self, cmd: str, first_timeout: float | None = None,
                    idle: float = 0.3) -> list[str]:
        """Send a query and collect reply lines until the line goes quiet."""
        self.write(cmd)
        lines = []
        line = self._readline(self.timeout if first_timeout is None else first_timeout)
        while line is not None:
            lines.append(line)
            line = self._readline(idle)
        return lines


_NUM_RE = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")


def parse_number(reply: str) -> float | None:
    m = _NUM_RE.search(reply or "")
    return float(m.group()) if m else None


def identify(conn: PsuConnection) -> str:
    return conn.query("*IDN?")


def list_sequences(conn: PsuConnection) -> list[str]:
    reply = " ".join(conn.query_lines("PROG:CAT?"))
    names = [n.strip().strip('"').strip("'") for n in re.split(r"[,;\s]+", reply)]
    return [n for n in names if n and re.match(r"[A-Za-z]", n)]


def _strip_step_reply(n: int, reply: str) -> str:
    r = reply.strip().strip('"')
    r = re.sub(rf"^(?:PROG\S*\s+)?(?:STE\S*\s+)?{n}\s*[:,]?\s+", "", r, flags=re.I)
    return r.strip().upper()


def read_sequence(conn: PsuConnection, name: str, max_steps: int = MAX_STEPS,
                  stop_after_empty: int = 50, progress=None,
                  log=lambda s: None) -> tuple[str, list[str]]:
    """Download a stored sequence. Returns (step-list text, raw reply lines)."""
    conn.write(f"PROG:SEL:NAM {name}")
    raw: list[str] = []
    steps: dict[int, str] = {}

    # 1) whole sequence in one query
    try:
        lines = conn.query_lines("PROG:SEL:STE?", first_timeout=conn.timeout)
    except PsuError:
        lines = []
    raw += [f"STE? -> {ln}" for ln in lines]
    parts: list[str] = []
    for ln in lines:
        parts += [p for p in re.split(r";|\t", ln) if p.strip()] if ";" in ln else [ln]
    numbered = [re.match(r"^\s*(\d+)\s*[:,]?\s+(\S.*)$", p) for p in parts]
    if parts and all(numbered):
        for m in numbered:
            steps[int(m.group(1))] = m.group(2).strip().upper()
    elif parts and all(_RE_BARE.match(p.strip()) for p in parts):
        steps = {i: p.strip().upper() for i, p in enumerate(parts, 1)}
    if steps:
        log(f"Read {len(steps)} steps with one query.")

    # 2) fall back to one query per step
    if not steps:
        log("Full-sequence query gave no usable reply – reading step by step.")
        empty_run, seen_end = 0, False
        for n in range(1, max_steps + 1):
            if progress and progress(n, max_steps) is False:
                break
            try:
                reply = conn.query(f"PROG:SEL:STE {n}?")
            except PsuError:
                reply = ""
            raw.append(f"STE {n}? -> {reply}")
            cmd = _strip_step_reply(n, reply)
            if cmd and _RE_BARE.match(cmd):
                steps[n] = cmd
                empty_run = 0
                seen_end |= cmd == "END"
            else:
                empty_run += 1
                if seen_end and empty_run >= stop_after_empty:
                    break

    # 3) labels (if the firmware supports a label query)
    labels: dict[str, int] = {}
    try:
        for ln in conn.query_lines("PROG:SEL:LAB?", first_timeout=0.5):
            raw.append(f"LAB? -> {ln}")
            for m in re.finditer(r"([A-Za-z]\w{0,9})\s*,\s*(\d+)", ln):
                labels[m.group(1).upper()] = int(m.group(2))
    except PsuError:
        pass

    out = [f"# Read back from {conn.host}: sequence '{name}'"]
    out += [f"{n} {c}" for n, c in sorted(steps.items())]
    out += [f"# label {k} = step {v}" for k, v in labels.items()]
    if any(re.match(r"^(JP|JS)\s+[A-Z]", c) for c in steps.values()) and not labels:
        out.append("# NOTE: jumps use labels but no labels could be read back - "
                   "add them with '# label NAME = step N'")
    return "\n".join(out) + "\n", raw


def upload_sequence(conn: PsuConnection, lines: list[str], progress=None,
                    log=lambda s: None) -> None:
    cmds = [ln for ln in lines if ln.strip() and not ln.lstrip().startswith("#")]
    for i, ln in enumerate(cmds, 1):
        conn.write(ln)
        if progress and progress(i, len(cmds)) is False:
            raise PsuError("Upload cancelled")
    log(f"Sent {len(cmds)} commands.")


def verify_upload(conn: PsuConnection, name: str, steps: list[str],
                  log=lambda s: None) -> list[str]:
    """Read every step back and compare. Returns a list of differences."""
    conn.write(f"PROG:SEL:NAM {name}")
    diffs = []
    for n, want in enumerate(steps, 1):
        try:
            got = _strip_step_reply(n, conn.query(f"PROG:SEL:STE {n}?"))
        except PsuError as e:
            diffs.append(f"step {n}: no reply ({e})"); continue
        if got.replace(" ", "") != want.upper().replace(" ", ""):
            diffs.append(f"step {n}: sent '{want}', supply has '{got}'")
    log("Verify: OK" if not diffs else f"Verify: {len(diffs)} difference(s)")
    return diffs


def measure(conn: PsuConnection, queries: dict[str, str]) -> dict[str, float | None]:
    out = {}
    for key, q in queries.items():
        if not q:
            continue
        try:
            out[key] = parse_number(conn.query(q))
        except PsuError:
            out[key] = None
    return out


# ==========================================================================
# Loading any file as traces (for the compare view)
# ==========================================================================
def guess_time_unit(header_cell: str) -> str | None:
    h = (header_cell or "").lower()
    for key, unit in (("µs", "µs"), ("[us]", "µs"), ("(us)", "µs"), ("ms", "ms"),
                      ("[s]", "s"), ("(s)", "s"), ("sec", "s"), ("[min]", "min"),
                      ("min", "min"), ("[h]", "h")):
        if key in h:
            return unit
    return None


def samples_file_traces(path: str, unit: str) -> tuple[dict, float]:
    """Every numeric column after the first (time) column becomes a trace."""
    rows = read_table_file(path)
    if not rows:
        raise ValueError("File is empty")
    hdr = detect_header(rows)
    ncol = max(len(r) for r in rows[:50])
    names = [(rows[0][i] if hdr and i < len(rows[0]) and rows[0][i].strip()
              else f"Column {i + 1}") for i in range(ncol)]
    traces, end = {}, 0.0
    for c in range(1, ncol):
        smp, _ = extract_samples(rows, 0, c, unit, hdr)
        if smp:
            t0 = smp[0][0] if unit == "hh:mm:ss / date-time" else 0.0
            traces[names.get(c, c)] = [(t - t0, v) for t, v in smp]
            end = max(end, traces[names.get(c, c)][-1][0])
    if not traces:
        raise ValueError("No numeric value columns found")
    return traces, end


def load_traces(path: str, unit: str | None = None, max_time: float = 600.0,
                inputs: dict | None = None) -> tuple[dict, float, str]:
    """Return (traces, end_time, kind) for a project, sequence or samples file.
    kind is 'sequence' (step signal) or 'samples' (measured points)."""
    low = path.lower()
    if low.endswith(".json"):
        with open(path, encoding="utf-8") as fh:
            cfg = SequenceSettings.from_json(fh.read())
        r = simulate_settings(cfg, 1)
        return r.traces, r.end_time, "sequence"
    if low.endswith((".txt", ".seq")):
        with open(path, encoding="utf-8", errors="replace") as fh:
            seq = parse_sequence_text(fh.read())
        if seq.steps:
            r = simulate(seq, max_time=max_time, inputs=inputs, step_time=0.0)
            return r.traces, r.end_time, "sequence"
    tr, end = samples_file_traces(path, unit or "s")
    return tr, end, "samples"


def difference_trace(a: list[tuple[float, float]], b: list[tuple[float, float]],
                     a_off: float = 0.0, b_off: float = 0.0, a_step=True,
                     b_step=True) -> list[tuple[float, float]]:
    """A − B on the union of both time bases (step or linear interpolation)."""
    import bisect

    def val(tr, xs, t, step):
        if step:
            return step_value_at(xs, [v for _, v in tr], t)
        i = bisect.bisect_right(xs, t) - 1
        if i < 0:
            return tr[0][1]
        if i >= len(tr) - 1:
            return tr[-1][1]
        (t0, v0), (t1, v1) = tr[i], tr[i + 1]
        return v0 if t1 == t0 else v0 + (v1 - v0) * (t - t0) / (t1 - t0)

    A = [(t + a_off, v) for t, v in a]
    B = [(t + b_off, v) for t, v in b]
    xa, xb = [t for t, _ in A], [t for t, _ in B]
    times = sorted(set(xa) | set(xb))
    return [(t, val(A, xa, t, a_step) - val(B, xb, t, b_step)) for t in times]


# ==========================================================================
# Tolerance checking (planned step signal vs measured samples)
# ==========================================================================
@dataclass
class ToleranceResult:
    n: int
    n_checked: int
    n_fail: int
    max_dev: float
    rms_dev: float
    passed: bool
    fail_times: list[float]
    band: list[tuple[float, float, float]]      # (t, lower, upper) – step-post
    deviations: list[tuple[float, float]]       # (t, measured − planned)


def tolerance_check(planned: list[tuple[float, float]], measured: list[tuple[float, float]],
                    tol_abs: float = 0.0, tol_pct: float = 0.0, settle: float = 0.0,
                    planned_offset: float = 0.0, measured_offset: float = 0.0,
                    end_time: float | None = None) -> ToleranceResult:
    """Check measured points against planned ± max(tol_abs, tol_pct·|planned|).
    Points within `settle` seconds after a planned change are not judged."""
    import bisect
    P = [(t + planned_offset, v) for t, v in planned]
    xs = [t for t, _ in P]; ys = [v for _, v in P]
    change_t = [P[k][0] for k in range(1, len(P)) if P[k][1] != P[k - 1][1]]

    def limit(v):
        return max(tol_abs, abs(v) * tol_pct / 100.0)

    band = [(t, v - limit(v), v + limit(v)) for t, v in P]
    if end_time is not None and P:
        band.append((end_time + planned_offset, band[-1][1], band[-1][2]))
    devs, fails, sq, checked, max_dev = [], [], 0.0, 0, 0.0
    for t, m in measured:
        t += measured_offset
        if m is None or (isinstance(m, float) and math.isnan(m)) or not xs or t < xs[0]:
            continue
        pv = step_value_at(xs, ys, t)
        dev = m - pv
        devs.append((t, dev))
        k = bisect.bisect_right(change_t, t) - 1
        if settle > 0 and k >= 0 and t - change_t[k] < settle:
            continue
        checked += 1
        sq += dev * dev
        max_dev = max(max_dev, abs(dev))
        if abs(dev) > limit(pv) + 1e-12:
            fails.append(t)
    return ToleranceResult(len(measured), checked, len(fails), max_dev,
                           math.sqrt(sq / checked) if checked else 0.0,
                           checked > 0 and not fails, fails, band, devs)


# ==========================================================================
# PDF test report (matplotlib only – works without the GUI)
# ==========================================================================
def make_report(path: str, info: dict, planned: dict, measured: dict,
                results: dict | None = None, notes: str = "") -> None:
    """planned:  {"V": [(t, v)...], "I": [...]}  step signals (may be empty)
       measured: {"V": [(t, v)...], "I": [...], "P": [...]}
       results:  {"V": ToleranceResult, ...}"""
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_pdf import PdfPages
    results = results or {}
    units = {"V": "V", "I": "A", "P": "W"}
    names = {"V": "Voltage", "I": "Current", "P": "Power"}
    chans = [c for c in measured if measured.get(c)]

    with PdfPages(path) as pdf:
        # ---- page 1: summary + overview
        fig = Figure(figsize=(8.27, 11.69))          # A4 portrait
        fig.text(0.07, 0.96, info.get("title", "Power supply test report"),
                 fontsize=16, weight="bold", va="top")
        lines = [f"{k}: {v}" for k, v in info.items() if k != "title" and v]
        overall = None
        if results:
            overall = all(r.passed for r in results.values())
        y = 0.925
        for ln in lines:
            fig.text(0.07, y, ln, fontsize=9, va="top"); y -= 0.018
        if notes:
            fig.text(0.07, y, "Notes: " + notes, fontsize=9, va="top", wrap=True)
            y -= 0.03
        if overall is not None:
            fig.text(0.93, 0.955, "PASS" if overall else "FAIL", fontsize=22,
                     weight="bold", ha="right", va="top",
                     color="#1a7f37" if overall else "#c62828")
        # result table
        rows = []
        for c in chans:
            m = [v for _, v in measured[c] if v is not None and not math.isnan(v)]
            r = results.get(c)
            rows.append([names.get(c, c),
                         f"{min(m):.5g}" if m else "–", f"{max(m):.5g}" if m else "–",
                         f"{sum(m) / len(m):.5g}" if m else "–",
                         f"{r.max_dev:.4g}" if r else "–",
                         f"{r.rms_dev:.4g}" if r else "–",
                         f"{r.n_fail}/{r.n_checked}" if r else "–",
                         ("PASS" if r.passed else "FAIL") if r else "–"])
        top = y - 0.01
        ax_t = fig.add_axes([0.07, top - 0.03 - 0.025 * len(rows), 0.86,
                             0.03 + 0.025 * len(rows)])
        ax_t.axis("off")
        tbl = ax_t.table(cellText=rows, colLabels=["Signal", "Min", "Max", "Mean",
                                                   "Max |dev|", "RMS dev", "Fails",
                                                   "Result"],
                         loc="upper center", cellLoc="center")
        tbl.auto_set_font_size(False); tbl.set_fontsize(8); tbl.scale(1, 1.3)
        for (r, cidx), cell in tbl.get_celld().items():
            if r > 0 and cidx == 7:
                txt = cell.get_text().get_text()
                cell.set_facecolor("#d8f0dc" if txt == "PASS" else
                                   "#f8d7da" if txt == "FAIL" else "white")
        # plots
        n = max(len(chans), 1)
        bottom, height = 0.05, (top - 0.1 - 0.025 * len(rows)) - 0.05
        for k, c in enumerate(chans):
            h = height / n
            ax = fig.add_axes([0.1, bottom + (n - 1 - k) * h + 0.035, 0.85, h - 0.06])
            r = results.get(c)
            if r and r.band:
                bx = [b[0] for b in r.band]
                ax.fill_between(bx, [b[1] for b in r.band], [b[2] for b in r.band],
                                step="post", color="#9ecae1", alpha=0.45,
                                label="Tolerance")
            p = planned.get(c)
            if p:
                ax.step([t for t, _ in p], [v for _, v in p], where="post",
                        color="#08519c", lw=1.0, ls="--", label="Planned")
            mx = [t for t, _ in measured[c]]; my = [v for _, v in measured[c]]
            ax.plot(mx, my, color="#d62728" if c != "V" else "#e6550d", lw=1.1,
                    label="Measured")
            if r and r.fail_times:
                import bisect
                fy = [my[min(bisect.bisect_left(mx, t), len(my) - 1)]
                      for t in r.fail_times[:2000]]
                ax.plot(r.fail_times[:2000], fy, "x", color="#c62828", ms=4,
                        label="Out of tolerance")
            ax.set_ylabel(f"{names.get(c, c)} [{units.get(c, '')}]", fontsize=8)
            ax.tick_params(labelsize=7); ax.grid(True, alpha=0.3)
            ax.legend(fontsize=7, loc="best")
            if k == len(chans) - 1:
                ax.set_xlabel("Time [s]", fontsize=8)
        fig.text(0.5, 0.015, f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')} · "
                 f"Delta Sequence Builder", ha="center", fontsize=7, color="grey")
        pdf.savefig(fig)

        # ---- page 2: deviations
        if results:
            fig = Figure(figsize=(8.27, 11.69))
            fig.text(0.07, 0.96, "Deviation from planned (measured − planned)",
                     fontsize=13, weight="bold", va="top")
            rc = [c for c in chans if c in results]
            for k, c in enumerate(rc):
                r = results[c]
                h = 0.85 / max(len(rc), 1)
                ax = fig.add_axes([0.1, 0.07 + (len(rc) - 1 - k) * h, 0.85, h - 0.07])
                ax.plot([t for t, _ in r.deviations], [d for _, d in r.deviations],
                        color="#444", lw=0.9)
                if r.band:
                    up = [(b[2] - b[1]) / 2 for b in r.band]
                    bx = [b[0] for b in r.band]
                    ax.step(bx, up, where="post", color="#c62828", lw=0.8, ls="--")
                    ax.step(bx, [-u for u in up], where="post", color="#c62828",
                            lw=0.8, ls="--")
                ax.axhline(0, color="grey", lw=0.6)
                ax.set_title(f"{names.get(c, c)}: max |dev| {r.max_dev:.4g} {units.get(c, '')}, "
                             f"RMS {r.rms_dev:.4g}, {r.n_fail} of {r.n_checked} "
                             f"checked points outside", fontsize=9)
                ax.set_ylabel(f"Δ [{units.get(c, '')}]", fontsize=8)
                ax.tick_params(labelsize=7); ax.grid(True, alpha=0.3)
            fig.axes[-1].set_xlabel("Time [s]", fontsize=8)
            pdf.savefig(fig)


def max_setpoint(steps: list[str], channel: str = "SV") -> float:
    """Highest value a step list sets for `channel` (loops are simulated)."""
    seq = parse_sequence_text("\n".join(f"{i} {s}" for i, s in enumerate(steps, 1)))
    r = simulate(seq, max_time=1e7, max_exec=200_000, step_time=0.0)
    vals = [v for _, v in r.traces.get(channel, [])]
    return max(vals, default=0.0)


# ==========================================================================
# Built-in templates (generic examples – not certified test standards)
# ==========================================================================
def _c(value, duration):
    return {"type": "Constant", "value": float(value), "duration": float(duration)}


def _r(start, end, duration, dt):
    return {"type": "Ramp", "start": float(start), "end": float(end),
            "duration": float(duration), "dt": float(dt)}


BUILTIN_TEMPLATES: dict[str, dict] = {
    "Soft start 0 → 24 V in 10 s": {
        "channel": "SV", "segments": [_r(0, 24, 10, 0.1), _c(24, 5)]},
    "Staircase 0 → 50 V, 10 V steps": {
        "channel": "SV", "segments": [_c(v, 2) for v in (0, 10, 20, 30, 40, 50)]},
    "Voltage dip 12 V → 6 V for 100 ms": {
        "channel": "SV", "segments": [_c(12, 2), _c(6, 0.1), _c(12, 2)]},
    "Short dropout 12 V → 0 V for 10 ms": {
        "channel": "SV", "segments": [_c(12, 1), _c(0, 0.01), _c(12, 1)]},
    "Crank-like dip 12 V (approximate, not a standard pulse)": {
        "channel": "SV", "segments": [
            _c(12, 1), _r(12, 6, 0.01, 0.002), _c(6, 0.015),
            {"type": "Sine", "offset": 7.0, "amplitude": 1.0, "freq": 2.0,
             "phase": -90.0, "duration": 0.5, "dt": 0.01},
            _r(7, 12, 0.1, 0.01), _c(12, 1)]},
    "Ripple 48 V ± 2 V, 5 Hz, 2 s": {
        "channel": "SV", "segments": [
            {"type": "Sine", "offset": 48.0, "amplitude": 2.0, "freq": 5.0,
             "phase": 0.0, "duration": 2.0, "dt": 0.01}]},
    "Battery discharge 4.2 → 3.0 V (1 cell, 60 s)": {
        "channel": "SV", "segments": [
            {"type": "Battery", "v_full": 4.2, "v_nominal": 3.7, "v_cutoff": 3.0,
             "duration": 60.0, "dt": 0.5}]},
    "Sink current steps 0 → −50 A (SM15K)": {
        "channel": "SCN", "segments": [_c(0, 1), _c(-10, 2), _c(-25, 2), _c(-50, 2),
                                       _c(0, 1)]},
    "Current pulses 0 / 20 A, 1 s period": {
        "channel": "SC", "segments": [
            {"type": "Square", "low": 0.0, "high": 20.0, "period": 1.0, "duty": 50.0,
             "cycles": 5}]},
}


# ==========================================================================
# Command-line interface
# ==========================================================================
def _write_out(text: str, out: str | None):
    if out:
        with open(out, "w", encoding="ascii", errors="replace", newline="\n") as fh:
            fh.write(text)
    else:
        sys.stdout.write(text)


def _load_settings_or_seq(path: str):
    """Return (SequenceSettings|None, ParsedSequence)."""
    with open(path, encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    if path.lower().endswith(".json"):
        cfg = SequenceSettings.from_json(text)
        comp = compile_sequence(cfg)
        if comp.errors:
            raise ValueError("; ".join(comp.errors))
        return cfg, parse_sequence_text(to_text(cfg, comp, "steps"))
    seq = parse_sequence_text(text)
    if not seq.steps:
        raise ValueError(f"No sequence steps found in {path}")
    return None, seq


def main_cli(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(
        prog="delta_seq_core.py",
        description="Delta Elektronika sequence tool – command-line mode "
                    "(run delta_seq_gui.py for the window).")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def conn_args(p):
        p.add_argument("--host", required=True)
        p.add_argument("--port", type=int, default=DEFAULT_PORT)
        p.add_argument("--timeout", type=float, default=2.0)

    p = sub.add_parser("compile", help="project .json -> sequence .txt")
    p.add_argument("project"); p.add_argument("-o", "--out")
    p.add_argument("--format", choices=["scpi", "steps"], default="scpi")

    p = sub.add_parser("convert", help="samples CSV/TXT/XLSX -> sequence .txt")
    p.add_argument("samples"); p.add_argument("-o", "--out")
    p.add_argument("--time-col", type=int, default=0)
    p.add_argument("--value-col", type=int, default=1)
    p.add_argument("--unit", default="s", choices=list(TIME_UNITS))
    p.add_argument("--continuous", action="store_true",
                   help="linear interpolation (default: step/hold)")
    p.add_argument("--dt", type=float, default=0.1, help="resample step [s]")
    p.add_argument("--last-hold", type=float, default=1.0)
    p.add_argument("--name", default="SAMPLES")
    p.add_argument("--channel", default="SV", choices=["SV", "SC", "SP", "SCN", "SPN"])
    p.add_argument("--repeat", type=int, default=1, help="0 = forever")
    p.add_argument("--device", default="SM 70-CP-450",
                   choices=list(DEVICE_PROFILES))
    p.add_argument("--compact", action="store_true", help="compact ramps (INC loops)")
    p.add_argument("--format", choices=["scpi", "steps"], default="scpi")
    p.add_argument("--save-project", help="also save a .json project")

    p = sub.add_parser("simulate", help="sequence .txt/.json -> samples CSV")
    p.add_argument("file"); p.add_argument("-o", "--out")
    p.add_argument("--unit", default="s", choices=["µs", "ms", "s", "min"])
    p.add_argument("--style", default="steps", choices=["steps", "changes", "fixed"])
    p.add_argument("--dt", type=float, default=0.01)
    p.add_argument("--max-time", type=float, default=600.0)

    p = sub.add_parser("upload", help="upload a sequence (.txt or .json)")
    p.add_argument("file"); conn_args(p)
    p.add_argument("--name", help="sequence name on the supply")
    p.add_argument("--verify", action="store_true")
    p.add_argument("--run", action="store_true", help="start it after upload")

    p = sub.add_parser("read", help="download a stored sequence")
    p.add_argument("name"); conn_args(p); p.add_argument("-o", "--out")

    p = sub.add_parser("list", help="list stored sequences"); conn_args(p)
    p = sub.add_parser("idn", help="identify the supply"); conn_args(p)
    p = sub.add_parser("run", help="start a stored sequence")
    p.add_argument("name"); conn_args(p)
    p = sub.add_parser("stop", help="stop the sequencer"); conn_args(p)
    p = sub.add_parser("measure", help="print V, I, P (CSV)"); conn_args(p)
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--interval", type=float, default=0.5)

    a = ap.parse_args(argv)
    try:
        if a.cmd == "compile":
            with open(a.project, encoding="utf-8") as fh:
                cfg = SequenceSettings.from_json(fh.read())
            comp = compile_sequence(cfg)
            for w in comp.warnings:
                print("warning:", w, file=sys.stderr)
            if comp.errors:
                for e in comp.errors:
                    print("error:", e, file=sys.stderr)
                return 2
            _write_out(to_text(cfg, comp, a.format), a.out)

        elif a.cmd == "convert":
            rows = read_table_file(a.samples)
            smp, skipped = extract_samples(rows, a.time_col, a.value_col, a.unit,
                                           detect_header(rows))
            pts, warns = samples_to_points(smp, SampleImportOptions(
                continuous=a.continuous, resample_dt=a.dt, last_hold=a.last_hold))
            prof = DEVICE_PROFILES[a.device]
            cfg = SequenceSettings(name=a.name, channel=a.channel, repeat=a.repeat,
                                   device=a.device, vmax=prof["vmax"], cmax=prof["cmax"],
                                   pmax=prof["pmax"], compact_ramps=a.compact,
                                   segments=[{"type": "Table", "points": pts}])
            comp = compile_sequence(cfg)
            for w in warns + comp.warnings:
                print("warning:", w, file=sys.stderr)
            if comp.errors:
                for e in comp.errors:
                    print("error:", e, file=sys.stderr)
                return 2
            if a.save_project:
                with open(a.save_project, "w", encoding="utf-8") as fh:
                    fh.write(cfg.to_json())
            _write_out(to_text(cfg, comp, a.format), a.out)
            print(f"{len(smp)} samples -> {len(comp.steps)} steps", file=sys.stderr)

        elif a.cmd == "simulate":
            _cfg, seq = _load_settings_or_seq(a.file)
            r = simulate(seq, max_time=a.max_time, step_time=0.0)
            traces = {k: v for k, v in r.traces.items() if len({x for _, x in v}) > 1} \
                or r.traces
            header, rows = traces_to_table(traces, r.end_time, a.style, a.dt, a.unit)
            if a.out:
                write_table_file(a.out, header, rows)
            else:
                print(",".join(header))
                for row in rows:
                    print(",".join(f"{x:g}" for x in row))
            print(r.stop_reason, file=sys.stderr)

        elif a.cmd == "upload":
            cfg, seq = _load_settings_or_seq(a.file)
            seq = renumber_steps(seq)
            name = a.name or (cfg.name if cfg else seq.name)
            text = parsed_to_text(seq, name, "scpi", run=a.run)
            with PsuConnection(a.host, a.port, a.timeout) as con:
                upload_sequence(con, text.splitlines(), log=lambda s: print(s, file=sys.stderr))
                if a.verify:
                    diffs = verify_upload(con, name, list(seq.steps.values()))
                    for d in diffs:
                        print("verify:", d, file=sys.stderr)
                    if diffs:
                        return 3
                    print("verify: OK", file=sys.stderr)

        elif a.cmd == "read":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                text, _raw = read_sequence(con, a.name)
            _write_out(text, a.out)

        elif a.cmd == "list":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                print("\n".join(list_sequences(con)))

        elif a.cmd == "idn":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                print(identify(con))

        elif a.cmd == "run":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                con.write(f"PROG:SEL:NAM {a.name}"); con.write("PROG:SEL:STA RUN")

        elif a.cmd == "stop":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                con.write("PROG:SEL:STA STOP")

        elif a.cmd == "measure":
            with PsuConnection(a.host, a.port, a.timeout) as con:
                print("time_s,V,I,P")
                t0 = time.monotonic()
                for k in range(a.count):
                    m = measure(con, DEFAULT_QUERIES)
                    print(f"{time.monotonic() - t0:.3f},{m.get('V')},{m.get('I')},{m.get('P')}",
                          flush=True)
                    if k + 1 < a.count:
                        time.sleep(a.interval)
    except (PsuError, ValueError, OSError) as e:
        print("error:", e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main_cli())
