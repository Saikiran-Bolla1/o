# Delta Elektronika Sequence Builder

A desktop tool (PyQt5 + matplotlib) to build, edit, plot, upload and monitor
sequences for Delta Elektronika SM15K / SM3300 power supplies.

## Files

| File | Purpose |
|---|---|
| `delta_seq_gui.py` | The application – **run this one** |
| `delta_seq_core.py` | Sequence logic, file I/O and power-supply communication (no GUI). Must be in the same folder. |
| `requirements.txt` | Python packages |
| `build_exe.bat` / `build_exe.sh` | Build a single executable with PyInstaller |
| `tests/` | Automated tests (`python -m pytest tests -q`) incl. a fake power supply |

## Run

```
pip install -r requirements.txt
python delta_seq_gui.py
```

## Build a stand-alone .exe (Windows)

Double-click `build_exe.bat` (or run it in a terminal). The result is
`dist\DeltaSequenceBuilder.exe` – copy it to any Windows PC, no Python needed.
Antivirus tools sometimes flag new PyInstaller executables; this is a known
false positive.

## Main features

- **Signal editor** – Constant, Ramp, Sine, Square, Triangle, Exponential, PWM
  (duty ramp), Battery discharge curve, Table, Combine (A + − × min max B),
  Wait for digital input, Wait for trigger. Repeat once / N times / forever.
- **Device profiles** – SM15K (70-CP-450 … 1500-CP-30) and SM3300
  (18-220 … 660-AR-11) limits; *Custom* for anything else.
- **Files** – export sequence `.txt` (SCPI upload commands or step list),
  open and hand-edit existing sequence files, import samples (CSV/TXT/Excel,
  µs…h, step or continuous), export samples, save/open projects (`.json`),
  drag & drop, recent files.
- **Plots** – mouse-wheel zoom (Ctrl = time only, Shift = Y only), drag to pan,
  double-click to fit, two measurement cursors with Δt, 1/Δt, ΔV, min, max,
  mean, RMS; ←/→ jumps between step edges.
- **Compare** – overlay editor, script and any files; time offset and scale per
  signal; A − B difference plot.
- **Device menu** – connection settings (default port 8462), test connection,
  upload with read-back verification, read a stored sequence back from the
  supply, run / stop / output OFF, **Live monitor** (logs measured V/I/P over
  the planned profile, saves CSV/Excel).

- **Compact ramps** – straight ramps become small INC loops: a 1000-point ramp
  needs ~10 steps instead of 2000 (within half a digit of the normal output).
- **Sink mode** – sink current (SCN) and sink power (SPN) profiles for SM15K.
- **Safety checks** – power (V × I) vs. rating, max step size, max rate,
  optional blocking, extra confirmation above a set voltage (default 60 V).
- **Tolerance + reports** – ± absolute / % bands with settling time in the
  Compare tab and Live monitor, PASS/FAIL, PDF test report.
- **Templates** – built-in examples plus your own (Templates menu).

## Command-line mode

`delta_seq_core.py` also works without the window, e.g. for test rigs:

```
python delta_seq_core.py compile project.json -o seq.txt
python delta_seq_core.py convert log.csv --unit ms --continuous --dt 0.05 --compact -o seq.txt
python delta_seq_core.py simulate seq.txt -o samples.csv
python delta_seq_core.py upload seq.txt --host 192.168.0.100 --verify --run
python delta_seq_core.py read SEQ1 --host 192.168.0.100 -o seq1.txt
python delta_seq_core.py measure --host 192.168.0.100 --count 10 --interval 0.5
```

Run `python delta_seq_core.py --help` (or `<command> --help`) for all options.

## Please verify on your supply first

The sequencer syntax comes from Delta's *Ethernet & Sequencer Programming*
manual, but some details could not be confirmed without hardware:

- the read-back reply format of `PROG:SEL:STE?` (the tool tries one full query,
  then step by step – raw replies are shown under *Messages*),
- whether `PROG:SEL:LAB?` exists (labels may need re-adding after read-back),
- the measurement queries (`MEAS:VOLT?`, `MEAS:CURR?`, `MEAS:POW?`) – editable
  under *Device → Connection settings*,
- that `INC`/`DEC` accept decimal values for SV/SC (used by *Compact ramps* –
  off by default) and the sink settings `SCN`/`SPN` on your firmware.

Test with a short sequence and no load connected before using it on a real
setup.
