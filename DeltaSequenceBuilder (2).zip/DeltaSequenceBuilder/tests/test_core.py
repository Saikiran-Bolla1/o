"""Automated tests for delta_seq_core (no GUI, no hardware).

    pip install pytest
    python -m pytest tests -q
"""
import copy
import math
import os
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import delta_seq_core as c          # noqa: E402
from fake_psu import FakePSU        # noqa: E402

d = c.default_segment


def run(cfg, max_time=1e5, allow_too_long=False):
    comp = c.compile_sequence(cfg)
    errs = [e for e in comp.errors if not (allow_too_long and "max 2000" in e)]
    assert not errs, errs
    seq = c.parse_sequence_text(c.to_text(cfg, comp))
    return comp, c.simulate(seq, max_time=max_time, step_time=0.0)


def trace_dev(ra, rb, ch):
    xa = [t for t, _ in ra.traces[ch]]; ya = [v for _, v in ra.traces[ch]]
    xb = [t for t, _ in rb.traces[ch]]; yb = [v for _, v in rb.traces[ch]]
    ts = sorted(set(round(x, 9) for x in xa + xb))
    return max(abs(c.step_value_at(xa, ya, t + 1e-9) - c.step_value_at(xb, yb, t + 1e-9))
               for t in ts)


# ---------------------------------------------------------------- compile
def test_basic_ramp_compiles_and_simulates():
    comp, r = run(c.SequenceSettings(segments=[d("Ramp")]))
    assert comp.steps[-1] == "END"
    assert r.stop_reason.startswith("END")
    assert r.end_time == pytest.approx(comp.duration_one_pass)


@pytest.mark.parametrize("repeat", [1, 2, 5])
def test_repeat_runs_n_times(repeat):
    comp, r = run(c.SequenceSettings(repeat=repeat, segments=[d("Square")]))
    assert r.end_time == pytest.approx(comp.duration_one_pass * repeat)


def test_infinite_loop_uses_label():
    cfg = c.SequenceSettings(repeat=0, segments=[d("Constant")])
    comp = c.compile_sequence(cfg)
    assert "JP LOOP" in comp.steps and "LOOP" in comp.labels
    seq = c.parse_sequence_text(c.to_text(cfg, comp))
    r = c.simulate(seq, max_time=5, step_time=0.0)
    assert r.stop_reason.startswith("Stopped at the simulation limit")


def test_too_many_steps_is_an_error():
    cfg = c.SequenceSettings(segments=[d("Sine") | {"duration": 100, "dt": 0.01}])
    assert any("max 2000" in e for e in c.compile_sequence(cfg).errors)


def test_value_above_model_limit_is_an_error():
    cfg = c.SequenceSettings(vmax=70, segments=[d("Constant") | {"value": 80}])
    assert any("exceeds" in e for e in c.compile_sequence(cfg).errors)


@pytest.mark.parametrize("kind", [k for k in c.SEGMENT_TYPES if k not in c.WAIT_TYPES])
def test_every_segment_type_compiles(kind):
    seg = d(kind)
    cfg = c.SequenceSettings(segments=[seg], vmax=1000)
    comp = c.compile_sequence(cfg)
    assert not comp.errors, comp.errors


def test_combine_multiply():
    seg = {"type": "Combine", "op": "Multiply", "dt": 0.5,
           "a": d("Constant") | {"value": 4, "duration": 2},
           "b": d("Constant") | {"value": 2.5, "duration": 2}}
    assert all(v == pytest.approx(10) for v, _ in c.sample_segment(seg))


def test_wait_steps_generate_poll_loop_and_trigger():
    cfg = c.SequenceSettings(segments=[d("Constant"), d("Wait for input") |
                                       {"input": "IB2", "level": "0 (low)"},
                                       d("Wait for trigger"), d("Constant")])
    comp = c.compile_sequence(cfg)
    i = comp.steps.index("NOP")
    assert comp.steps[i + 1] == f"CJNE IB2,0,{i + 1}"
    assert "TRG" in comp.steps
    assert len(comp.markers) == 2


# ---------------------------------------------------------------- compact ramps
@pytest.mark.parametrize("cfg", [
    c.SequenceSettings(segments=[d("Ramp") | {"end": 50, "duration": 100, "dt": 0.1}]),
    c.SequenceSettings(segments=[d("Ramp") | {"start": 50, "end": 0, "duration": 10,
                                              "dt": 0.01}]),
    c.SequenceSettings(repeat=3, segments=[d("Triangle") | {"cycles": 3, "dt": 0.05},
                                           d("Constant"), d("Ramp")]),
    c.SequenceSettings(decimals=2, segments=[d("Ramp") | {"end": 7, "duration": 9,
                                                          "dt": 0.03}]),
    c.SequenceSettings(channel="SCN", limit_voltage=40, segments=[
        d("Ramp") | {"start": 0, "end": -100, "duration": 5, "dt": 0.01}]),
])
def test_compact_ramps_match_expanded_output(cfg):
    a = copy.deepcopy(cfg); a.compact_ramps = False
    b = copy.deepcopy(cfg); b.compact_ramps = True
    ca, ra = run(a, allow_too_long=True)     # reference: may exceed 2000 steps
    cb, rb = run(b)
    assert len(cb.steps) < len(ca.steps)
    assert ra.end_time == pytest.approx(rb.end_time)
    assert trace_dev(ra, rb, cfg.channel) <= 0.5 * 10 ** -cfg.decimals * 1.00001


def test_compact_makes_long_ramp_fit():
    cfg = c.SequenceSettings(compact_ramps=True, segments=[
        d("Ramp") | {"end": 60, "duration": 600, "dt": 0.05}])
    comp = c.compile_sequence(cfg)
    assert not comp.errors and len(comp.steps) < 100


# ---------------------------------------------------------------- sink + safety
def test_sink_channel_rejects_positive_values():
    cfg = c.SequenceSettings(channel="SCN", segments=[d("Constant") | {"value": 5}])
    assert any("sink" in e for e in c.compile_sequence(cfg).errors)


def test_sink_warning_on_device_without_sink():
    cfg = c.SequenceSettings(channel="SCN", device="SM 18-220", cmax=220,
                             segments=[d("Constant") | {"value": -5}])
    assert any("no built-in sink" in w for w in c.compile_sequence(cfg).warnings)


def test_safety_checks_warn_or_block():
    cfg = c.SequenceSettings(limit_current=400, max_step=5, max_rate=20, segments=[
        d("Square") | {"high": 60, "cycles": 1}])
    comp = c.compile_sequence(cfg)
    assert sum(w.startswith("Safety") for w in comp.warnings) == 3
    cfg.safety_errors = True
    assert sum(e.startswith("Safety") for e in c.compile_sequence(cfg).errors) == 3


def test_max_setpoint_follows_loops():
    cfg = c.SequenceSettings(compact_ramps=True, segments=[
        d("Ramp") | {"end": 42, "duration": 10, "dt": 0.1}])
    assert c.max_setpoint(c.compile_sequence(cfg).steps) == pytest.approx(42, abs=1e-3)


# ---------------------------------------------------------------- files
def test_parse_formats_and_renumber():
    txt = "1 SV=5\n2 #A=0\n5 SV=10\n6 W=1\n8 INC #A,1\n9 CJL #A,3,5\n12 JP 15\n15 END\n"
    seq = c.parse_sequence_text(txt)
    out = c.parsed_to_text(seq, "NEW", "steps")
    assert "6 CJL #A,3,3" in out and "7 JP 8" in out
    r1 = c.simulate(seq, step_time=0)
    r2 = c.simulate(c.parse_sequence_text(c.parsed_to_text(seq, "NEW")), step_time=0)
    assert r1.traces["SV"] == r2.traces["SV"]


def test_samples_import_step_and_continuous(tmp_path):
    f = tmp_path / "s.csv"
    f.write_text("Time_ms;Voltage\n0;0\n500;10,5\n1000;20\n2000;5\n")
    rows = c.read_table_file(str(f))
    smp, skipped = c.extract_samples(rows, 0, 1, "ms", c.detect_header(rows))
    assert skipped == 0 and smp[1] == (0.5, 10.5)
    step, _ = c.samples_to_points(smp, c.SampleImportOptions())
    assert step[:2] == [[0.0, 0.5], [10.5, 0.5]]
    cont, _ = c.samples_to_points(smp, c.SampleImportOptions(continuous=True,
                                                             resample_dt=0.25))
    assert cont[1][0] == pytest.approx(5.25)


def test_export_samples_roundtrip(tmp_path):
    cfg = c.SequenceSettings(segments=[d("Square") | {"cycles": 1}])
    r = c.simulate_settings(cfg)
    header, rows = c.traces_to_table({"SV": r.traces["SV"]}, r.end_time, "steps")
    path = tmp_path / "out.xlsx"
    c.write_table_file(str(path), header, rows)
    back = c.read_table_file(str(path))
    assert back[0] == header and len(back) == len(rows) + 1


# ---------------------------------------------------------------- tolerance + report
def test_tolerance_check_and_report(tmp_path):
    planned = [(0, 0), (1, 10), (3, 5), (5, 5)]
    meas = [(i * 0.05, c.step_value_at([0, 1, 3], [0, 10, 5], i * 0.05)
             + (0.4 if 80 < i < 84 else 0)) for i in range(100)]
    r = c.tolerance_check(planned, meas, tol_abs=0.2, settle=0.1, end_time=5)
    assert not r.passed and r.n_fail == 3
    assert c.tolerance_check(planned, meas, tol_abs=0.5, end_time=5).passed
    pdf = tmp_path / "r.pdf"
    c.make_report(str(pdf), {"title": "t"}, {"V": planned}, {"V": meas}, {"V": r})
    assert pdf.stat().st_size > 5000


# ---------------------------------------------------------------- power supply (fake)
@pytest.fixture
def psu():
    return FakePSU()


def test_upload_verify_readback_measure(psu):
    cfg = c.SequenceSettings(name="DEMO", repeat=0, segments=[
        d("Square") | {"cycles": 1, "period": 0.4, "high": 10}])
    comp = c.compile_sequence(cfg)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        assert "DELTA" in c.identify(con)
        c.upload_sequence(con, c.to_scpi_lines(cfg, comp))
        assert c.verify_upload(con, "DEMO", comp.steps) == []
        assert c.list_sequences(con) == ["DEMO"]
        text, _ = c.read_sequence(con, "DEMO")
        back = c.parse_sequence_text(text)
        assert list(back.steps.values()) == comp.steps
        assert back.labels == comp.labels
        con.write("PROG:SEL:STA RUN")
        time.sleep(0.05)
        m = c.measure(con, c.DEFAULT_QUERIES)
        assert m["V"] == pytest.approx(10)


def test_readback_full_query_mode():
    psu = FakePSU(full_query=True)
    cfg = c.SequenceSettings(name="FQ", segments=[d("Ramp")])
    comp = c.compile_sequence(cfg)
    with c.PsuConnection("127.0.0.1", psu.port) as con:
        c.upload_sequence(con, c.to_scpi_lines(cfg, comp))
        text, _ = c.read_sequence(con, "FQ")
    assert list(c.parse_sequence_text(text).steps.values()) == comp.steps


def test_connection_error_is_reported():
    with pytest.raises(c.PsuError):
        c.PsuConnection("127.0.0.1", 1, timeout=0.5).open()


# ---------------------------------------------------------------- command line
def test_cli_compile_convert_simulate_upload(tmp_path, psu, capsys):
    proj = tmp_path / "p.json"
    proj.write_text(c.SequenceSettings(name="CLI", segments=[d("Ramp")]).to_json())
    out = tmp_path / "p.txt"
    assert c.main_cli(["compile", str(proj), "-o", str(out)]) == 0
    assert "PROG:SEL:STE 1" in out.read_text()

    smp = tmp_path / "s.csv"
    smp.write_text("t,v\n0,0\n1,5\n2,10\n")
    out2 = tmp_path / "s.txt"
    assert c.main_cli(["convert", str(smp), "--unit", "s", "-o", str(out2),
                       "--name", "CONV"]) == 0
    assert "SV=5" in out2.read_text()

    csv = tmp_path / "sim.csv"
    assert c.main_cli(["simulate", str(out2), "-o", str(csv)]) == 0
    assert csv.read_text().startswith("Time [s]")

    assert c.main_cli(["upload", str(out2), "--host", "127.0.0.1", "--port",
                       str(psu.port), "--verify"]) == 0
    assert "CONV" in psu.seqs


def test_builtin_templates_compile():
    for name, t in c.BUILTIN_TEMPLATES.items():
        cfg = c.SequenceSettings(channel=t["channel"], segments=t["segments"])
        assert not c.compile_sequence(cfg).errors, name
