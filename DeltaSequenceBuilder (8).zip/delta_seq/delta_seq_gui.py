"""
Delta Elektronika Sequence Builder - ControlDesk-style signal editor (PyQt5).

    pip install PyQt5 matplotlib
    python delta_seq_gui.py
"""
from __future__ import annotations

import copy
import json
import math
import os
import re
import sys
import time

from PyQt5.QtCore import Qt, QPoint, QRect, QRectF, QSettings, QSize, QThread, QTimer, pyqtSignal
from PyQt5.QtGui import QBrush, QColor, QFont, QIcon, QPainter, QPalette, QPixmap
from PyQt5.QtWidgets import (
    QAction, QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QFormLayout, QGroupBox, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
    QListWidget, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QSpinBox, QSplitter, QTabWidget, QTableWidget, QTableWidgetItem, QToolBar,
    QVBoxLayout, QWidget, QHeaderView, QDialog, QDialogButtonBox,
    QAbstractItemView, QRadioButton, QButtonGroup, QProgressDialog, QListWidgetItem,
    QScrollArea, QMenu, QStyle, QToolButton, QDockWidget, QSizePolicy, QLayout,
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure
import matplotlib
matplotlib.rcParams.update({
    "axes.grid": True, "grid.color": "#dde3ea", "grid.linewidth": 0.8,
    "axes.edgecolor": "#9aa7b4", "axes.labelcolor": "#2b3a4a",
    "axes.titlesize": 10, "axes.titleweight": "bold", "axes.labelsize": 9,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "xtick.color": "#4a5866",
    "ytick.color": "#4a5866", "legend.fontsize": 8, "legend.framealpha": 0.9,
    "lines.linewidth": 1.6, "figure.facecolor": "#ffffff",
})

import delta_seq_core as core


# ==========================================================================
# Look & feel: one clear light theme, coloured badge icons, dock title bars
# ==========================================================================
ACCENT = "#1f5fa8"

THEME_QSS = """
QMainWindow { background: #e9eef4; }
QMainWindow::separator { background: #c3cdd9; width: 4px; height: 4px; }
QMainWindow::separator:hover { background: #1f5fa8; }

QWidget#dockTitle { background: #1f5fa8; }
QLabel#dockTitleText { color: #ffffff; padding: 5px 4px 5px 8px; }
QToolButton#dockTitleBtn { color: #ffffff; border: none; padding: 1px 6px;
                           font-size: 10pt; background: transparent; }
QToolButton#dockTitleBtn:hover { background: #3477c7; border-radius: 3px; }
QLabel#dockIntro { background: #dfe9f6; color: #1d3b5c; padding: 6px 10px;
                   border-bottom: 1px solid #bcd0e8; }
QWidget#dockBody { background: #f5f7fa; }

QGroupBox { background: #ffffff; border: 1px solid #c6d0dc; border-radius: 6px;
            margin-top: 18px; padding: 10px 8px 8px 8px; }
QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left;
                   left: 10px; padding: 1px 6px; color: #ffffff;
                   background: #4a6f96; border-radius: 3px; }

QPushButton { padding: 5px 12px; border: 1px solid #b4c0ce; border-radius: 4px;
              background: #ffffff; color: #1c2733; }
QPushButton:hover { border-color: #1f5fa8; background: #eaf1fb; }
QPushButton:pressed { background: #d3e2f5; }
QPushButton:disabled { color: #9aa6b3; background: #f0f2f5; border-color: #d6dce3; }
QPushButton[role="primary"] { background: #1f5fa8; color: #ffffff; border-color: #184d8a;
                              font-weight: bold; }
QPushButton[role="primary"]:hover { background: #2b70c2; }
QPushButton[role="primary"]:disabled { background: #9db6d6; border-color: #9db6d6; }
QPushButton[role="go"] { background: #2e7d32; color: #ffffff; border-color: #24642a;
                         font-weight: bold; }
QPushButton[role="go"]:hover { background: #38963d; }
QPushButton[role="danger"] { background: #c62828; color: #ffffff; border-color: #9f1f1f;
                             font-weight: bold; }
QPushButton[role="danger"]:hover { background: #dd3434; }

QToolBar { background: #ffffff; border: none; border-bottom: 1px solid #c6d0dc;
           spacing: 2px; padding: 3px; }
QToolBar QToolButton { padding: 3px 5px; border-radius: 4px; color: #1c2733; }
QToolBar QToolButton:hover { background: #e4edf8; }
QToolBar QToolButton:checked { background: #cfe0f5; border: 1px solid #1f5fa8; }
QToolBar#windows_toolbar { background: #22344a; border-right: 1px solid #16222f;
                           border-bottom: none; padding: 4px 2px; }
QToolBar#windows_toolbar QToolButton { color: #e4ebf3; min-width: 64px; }
QToolBar#windows_toolbar QToolButton:hover { background: #33506f; }
QToolBar#windows_toolbar QToolButton:checked { background: #1f5fa8; border: none; }
QLabel#barHeading { color: #8ea6c0; font-size: 7pt; padding: 6px 2px 2px 2px; }
QToolBar#plot_toolbar { background: #f3f6fa; border: 1px solid #d3dbe5; border-radius: 4px; }

QTabWidget::pane { border: 1px solid #c6d0dc; background: #ffffff; top: -1px; }
QTabBar::tab { background: #dde4ec; border: 1px solid #c6d0dc; padding: 6px 16px;
               margin-right: 2px; border-top-left-radius: 5px;
               border-top-right-radius: 5px; color: #3a4858; }
QTabBar::tab:selected { background: #ffffff; color: #1f5fa8; border-bottom-color: #ffffff;
                        font-weight: bold; }
QTabBar::tab:hover:!selected { background: #eaf0f7; }

QListWidget { background: #ffffff; border: 1px solid #c6d0dc; border-radius: 4px; }
QListWidget::item { padding: 4px 4px; border-bottom: 1px solid #edf1f5; color: #1c2733; }
QListWidget::item:selected { background: #1f5fa8; color: #ffffff; }
QListWidget::item:hover:!selected { background: #eef4fb; }
QPlainTextEdit { background: #ffffff; border: 1px solid #c6d0dc; }
QHeaderView::section { background: #e6ecf3; padding: 4px; border: none;
                       border-right: 1px solid #c6d0dc; border-bottom: 1px solid #c6d0dc; }
QStatusBar { background: #ffffff; border-top: 1px solid #c6d0dc; }

QLabel#statePill { border-radius: 6px; padding: 8px 10px; font-size: 13pt;
                   font-weight: bold; }
QLabel#connPill { border-radius: 9px; padding: 3px 10px; font-weight: bold; }
QLabel#statePill[state="ok"], QLabel#connPill[state="ok"] {
    background: #e2f4e4; color: #1b5e20; border: 1px solid #7cc283; }
QLabel#statePill[state="bad"], QLabel#connPill[state="bad"] {
    background: #fde8e6; color: #b71c1c; border: 1px solid #e79a94; }
QLabel#statePill[state="busy"], QLabel#connPill[state="busy"] {
    background: #fff4dc; color: #7a5200; border: 1px solid #e8c36e; }
QLabel#statePill[state="idle"], QLabel#connPill[state="idle"] {
    background: #eceff3; color: #4a5563; border: 1px solid #c9d0d8; }
QLabel#hint { color: #5d6b7a; font-size: 8pt; }
QLabel#reading { background: #10263d; color: #7fe3a0; border-radius: 6px; padding: 6px 10px;
                 font-family: Consolas, monospace; }
"""


def apply_theme(app):
    app.setStyle("Fusion")
    pal = app.palette()
    for role, col in ((QPalette.Window, "#eef2f6"), (QPalette.Base, "#ffffff"),
                      (QPalette.AlternateBase, "#f4f7fa"), (QPalette.Button, "#f7f9fb"),
                      (QPalette.Highlight, ACCENT), (QPalette.HighlightedText, "#ffffff"),
                      (QPalette.WindowText, "#1c2733"), (QPalette.Text, "#1c2733"),
                      (QPalette.ButtonText, "#1c2733"), (QPalette.ToolTipBase, "#ffffe8"),
                      (QPalette.ToolTipText, "#1c2733")):
        pal.setColor(role, QColor(col))
    app.setPalette(pal)
    app.setStyleSheet(THEME_QSS)


def set_role(widget, role):
    """Colour a button: 'primary' (blue), 'go' (green) or 'danger' (red)."""
    widget.setProperty("role", role)
    widget.style().unpolish(widget); widget.style().polish(widget)
    return widget


def set_state(label, state, text=None):
    """Pill label colour: ok (green), bad (red), busy (amber), idle (grey)."""
    if text is not None:
        label.setText(text)
    label.setProperty("state", state)
    label.style().unpolish(label); label.style().polish(label)


def hint_label(text):
    lab = QLabel(text); lab.setWordWrap(True); lab.setObjectName("hint")
    return lab


_ICON_CACHE: dict = {}


def badge_icon(text: str, bg: str, fg: str = "#ffffff") -> QIcon:
    """A small rounded coloured badge with 1–4 characters – easy to tell apart."""
    key = (text, bg, fg)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    icon = QIcon()
    for size in (16, 20, 24, 32, 40, 48, 64, 96):
        pm = QPixmap(size, size); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen); p.setBrush(QColor(bg))
        r = size * 0.2
        p.drawRoundedRect(QRectF(0.5, 0.5, size - 1, size - 1), r, r)
        f = QFont(); f.setBold(True)
        f.setPixelSize(max(6, int(size * (0.62 if len(text) == 1 else
                                          0.42 if len(text) == 2 else 0.31))))
        p.setFont(f); p.setPen(QColor(fg))
        p.drawText(QRectF(0, 0, size, size), Qt.AlignCenter, text)
        p.end()
        icon.addPixmap(pm)
    _ICON_CACHE[key] = icon
    return icon


# colour per category, used by toolbars, the Windows bar and the segment list
C_FILE, C_EDIT, C_DEV, C_RUN, C_STOP, C_VIEW = ("#1f5fa8", "#607d8b", "#ef6c00",
                                                "#2e7d32", "#c62828", "#6a1b9a")
SEGMENT_BADGES = {
    "Constant": ("—", "#455a64"), "Ramp": ("/", "#1565c0"), "Sine": ("∿", "#6a1b9a"),
    "Square": ("⊓", "#00838f"), "Triangle": ("Λ", "#2e7d32"), "Table": ("T", "#5d4037"),
    "Combine": ("±", "#ad1457"), "Exponential": ("e", "#ef6c00"), "PWM": ("P", "#00695c"),
    "Battery": ("B", "#827717"), "Wait for input": ("IN", "#9e9e9e"),
    "Wait for trigger": ("TR", "#9e9e9e"),
}


def segment_icon(kind):
    text, col = SEGMENT_BADGES.get(kind, ("?", "#9e9e9e"))
    return badge_icon(text, col)


class DockTitle(QWidget):
    """Coloured title bar for a dock window (drag to move, double-click to float)."""

    def __init__(self, dock: QDockWidget):
        super().__init__(dock)
        self.setObjectName("dockTitle")
        self.setAttribute(Qt.WA_StyledBackground, True)
        h = QHBoxLayout(self); h.setContentsMargins(0, 0, 4, 0); h.setSpacing(2)
        self.lbl = QLabel(dock.windowTitle()); self.lbl.setObjectName("dockTitleText")
        f = self.lbl.font(); f.setBold(True); self.lbl.setFont(f)
        h.addWidget(self.lbl, 1)
        for text, tip, fn in (("❐", "Float / dock this window",
                               lambda: dock.setFloating(not dock.isFloating())),
                              ("✕", "Close this window (open it again from the "
                                    "Windows bar on the left)", dock.close)):
            b = QToolButton(); b.setObjectName("dockTitleBtn"); b.setText(text)
            b.setToolTip(tip); b.setAutoRaise(True); b.clicked.connect(fn)
            b.setFocusPolicy(Qt.NoFocus)
            h.addWidget(b)
        dock.windowTitleChanged.connect(self.lbl.setText)


class FlowLayout(QLayout):
    """Lays widgets out left to right and wraps to a new line when there is no
    room – so rows of options never get cut off in a narrow window."""

    def __init__(self, parent=None, spacing=6):
        super().__init__(parent)
        self._items = []
        self._sp = spacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientations(Qt.Orientation(0))

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for it in self._items:
            size = size.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        return size + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _do_layout(self, rect, test_only):
        x, y, line_h = rect.x(), rect.y(), 0
        for it in self._items:
            w = it.widget()
            if w is not None and w.isHidden():
                continue
            hint = it.sizeHint()
            nx = x + hint.width() + self._sp
            if nx - self._sp > rect.right() + 1 and line_h > 0:
                x, y = rect.x(), y + line_h + self._sp
                nx, line_h = x + hint.width() + self._sp, 0
            if not test_only:
                it.setGeometry(QRect(QPoint(x, y), hint))
            x, line_h = nx, max(line_h, hint.height())
        return y + line_h - rect.y()


def pair(*widgets):
    """Keep a label and its field together inside a FlowLayout."""
    w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(4)
    for x in widgets:
        h.addWidget(QLabel(x) if isinstance(x, str) else x)
    return w


def flow(*widgets):
    box = FlowLayout()
    for x in widgets:
        box.addWidget(QLabel(x) if isinstance(x, str) else x)
    return box


def dock_body(widget, intro: str, scroll: bool = False):
    """Put a one-line explanation above a dock's content; optionally let the
    content scroll so nothing is cut off in a small window."""
    w = QWidget(); w.setObjectName("dockBody")
    w.setAttribute(Qt.WA_StyledBackground, True)
    v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
    lab = QLabel(intro); lab.setObjectName("dockIntro"); lab.setWordWrap(True)
    v.addWidget(lab)
    if scroll:
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(widget)
        sc.setFrameShape(QScrollArea.NoFrame)
        v.addWidget(sc, 1)
    else:
        v.addWidget(widget, 1)
    w.content = widget
    return w


CHANNELS = {"Voltage (SV)": "SV", "Current (SC)": "SC", "Power (SP)": "SP",
            "Sink current (SCN)": "SCN", "Sink power (SPN)": "SPN"}
UNITS = {"SV": "V", "SC": "A", "SP": "W", "SCN": "A", "SPN": "W"}


class InteractiveCanvas(FigureCanvasQTAgg):
    """Matplotlib canvas with mouse-wheel zoom, drag-pan, double-click fit and
    two measurement cursors (C1, C2) with difference read-out.

    View rules
    - The time window (X) you zoom/pan to is kept when the plot is redrawn.
    - Y follows the data that is visible in that window whenever the data
      changes (so edited curves never disappear off-screen).
    - Y zoom/pan you do yourself is kept until the data changes (live plots
      keep it until you double-click / Fit).
    """
    ZOOM = 1.25
    CURSOR_COLORS = ("#d6278f", "#0f9d9a")
    GRAB_PX = 7
    DRAG_PX = 3

    def __init__(self, figsize=(6, 4)):
        self.fig = Figure(figsize=figsize)
        super().__init__(self.fig)
        self.setFocusPolicy(Qt.StrongFocus)
        self.traces: list[dict] = []
        self.cursors_on = False
        self.cursor_t: list[float | None] = [None, None]
        self.active_cursor = 0
        self._cursor_artists: list[list] = [[], []]
        self._drag = None
        self._x_user = None          # time window the user zoomed/panned to
        self._y_user = False         # user changed Y since the last data change
        self.datatip_mode = False    # MATLAB-style data tips: click shows a value
        self._tips: list = []
        self.on_readout = None       # callback(html: str)
        self.mpl_connect("scroll_event", self._on_scroll)
        self.mpl_connect("button_press_event", self._on_press)
        self.mpl_connect("button_release_event", self._on_release)
        self.mpl_connect("motion_notify_event", self._on_motion)
        self.mpl_connect("key_press_event", self._on_key)

    # ---- layout (computed once per plot / resize – no jitter while panning) --
    def _relayout(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                self.fig.tight_layout()
            except (ValueError, RuntimeError, AttributeError):
                pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._relayout()
        self.draw_idle()

    # ---- called by subclasses while plotting --------------------------------
    def begin_traces(self):
        self.traces = []
        self._cursor_artists = [[], []]
        self._tips = []                       # tips belong to the old drawing

    def add_trace(self, name, xs, ys, unit="", step=True):
        pts = [(x, y) for x, y in zip(xs, ys)
               if y is not None and not (isinstance(y, float) and math.isnan(y))]
        if pts:
            self.traces.append({"name": name, "xs": [p[0] for p in pts],
                                "ys": [p[1] for p in pts], "unit": unit,
                                "step": step})

    def finish_plot(self):
        """Call after (re)drawing the data."""
        axes = self.fig.axes
        self._y_user = False
        if self._x_user is not None and axes:
            axes[0].set_xlim(self._x_user)
            self._autoscale_y_all()
        self._relayout()
        self._draw_cursors()
        self._update_readout()
        tb = getattr(self, "toolbar", None)
        if tb is not None and hasattr(tb, "update"):
            try:
                tb.update()            # forget the toolbar's stale back/forward views
            except (AttributeError, TypeError):
                pass
        self.draw_idle()

    # ---- view helpers --------------------------------------------------------
    def _primary_axes(self):
        return [a for a in self.fig.axes if not getattr(a, "_is_twin", False)]

    def _data_lines(self, a):
        """Lines that carry data (not cursors, separators or markers)."""
        out = []
        for ln in a.get_lines():
            if not ln.get_visible() or ln.get_transform() != a.transData:
                continue
            if ln.get_gid() == "datatip":
                continue
            if len(ln.get_xdata()) == 0:
                continue
            out.append(ln)
        return out

    def _autoscale_y(self, a):
        """Fit Y to the data that is visible in the current time window."""
        if getattr(a, "_fixed_ylim", None):
            a.set_ylim(a._fixed_ylim); return
        import bisect
        x0, x1 = sorted(a.get_xlim())
        lo, hi = math.inf, -math.inf
        for ln in self._data_lines(a):
            xs = [float(x) for x in ln.get_xdata()]
            ys = [float(y) for y in ln.get_ydata()]
            if not xs or xs[-1] < x0 or xs[0] > x1:
                continue                                    # line not in the window
            i0 = max(bisect.bisect_right(xs, x0) - 1, 0)     # value held into view
            i1 = min(bisect.bisect_left(xs, x1) + 1, len(xs))  # one past the window
            for y in ys[i0:i1]:
                if not math.isnan(y):
                    lo, hi = min(lo, y), max(hi, y)
        for coll in a.collections:                          # tolerance bands
            for path in coll.get_paths():
                for x, y in path.vertices:
                    if x0 <= x <= x1 and not math.isnan(y):
                        lo, hi = min(lo, y), max(hi, y)
        if lo == math.inf:
            return
        pad = (hi - lo) * 0.05 or max(abs(hi) * 0.05, 0.5)
        a.set_ylim(lo - pad, hi + pad)

    def _autoscale_y_all(self):
        for a in self.fig.axes:
            self._autoscale_y(a)

    def reset_view(self):
        """Forget zoom and cursor positions (new file / new project)."""
        self._x_user = None
        self._y_user = False
        self.cursor_t = [None, None]

    def fit(self):
        self._x_user = None
        self._y_user = False
        for t in self._tips:
            t.set_visible(False)
        for a in self.fig.axes:
            a.set_autoscale_on(True)
            a.relim(visible_only=True)
            a.autoscale_view()
            if getattr(a, "_fixed_ylim", None):
                a.set_ylim(a._fixed_ylim)
        for t in self._tips:
            t.set_visible(True)
        self._fit_lims = [(a.get_xlim(), a.get_ylim()) for a in self.fig.axes]
        self._after_view_change(relayout=True)

    def _after_view_change(self, relayout=False):
        if relayout:
            self._relayout()
        self.draw_idle()

    def _toolbar_busy(self):
        return bool(getattr(getattr(self, "toolbar", None), "mode", ""))

    def toolbar_changed_view(self):
        """Called by the toolbar after its own zoom/pan/back/forward."""
        axes = self.fig.axes
        if axes and [(a.get_xlim(), a.get_ylim()) for a in axes] == \
                getattr(self, "_fit_lims", None):
            self._x_user = None              # still the original view (e.g. double-click
            self._y_user = False             # in Pan mode): keep following the data
        elif axes:
            self._x_user = tuple(axes[0].get_xlim())
            self._y_user = True
        self._relayout()
        self.draw_idle()

    # ---- cursors ---------------------------------------------------------------
    def set_cursors(self, on: bool):
        self.cursors_on = on
        if on:
            self._bring_cursors_into_view()
        self._draw_cursors()
        self._update_readout()
        self.draw_idle()

    def _bring_cursors_into_view(self):
        axes = self._primary_axes()
        if not axes:
            return
        x0, x1 = sorted(axes[0].get_xlim())
        for i, f in enumerate((1 / 3, 2 / 3)):
            t = self.cursor_t[i]
            if t is None or not (x0 <= t <= x1):
                self.cursor_t[i] = x0 + (x1 - x0) * f

    def _init_cursor_positions(self):
        """Give cursors a position if they have none (keeps existing ones)."""
        if None in self.cursor_t:
            axes = self._primary_axes()
            if not axes:
                return
            x0, x1 = sorted(axes[0].get_xlim())
            for i, f in enumerate((1 / 3, 2 / 3)):
                if self.cursor_t[i] is None:
                    self.cursor_t[i] = x0 + (x1 - x0) * f

    def _remove_cursor_artists(self):
        for arts in self._cursor_artists:
            for a in arts:
                try:
                    a.remove()
                except (ValueError, AttributeError, NotImplementedError):
                    pass
        self._cursor_artists = [[], []]

    def _draw_cursors(self):
        from matplotlib.lines import Line2D
        from matplotlib.transforms import blended_transform_factory
        self._remove_cursor_artists()
        axes = self._primary_axes()
        if not self.cursors_on or not axes:
            return
        self._init_cursor_positions()
        for i in range(2):
            t = self.cursor_t[i]
            col = self.CURSOR_COLORS[i]
            lw = 1.8 if i == self.active_cursor else 1.1
            arts = []
            for a in axes:
                # added as plain artists: they never take part in autoscaling
                ln = Line2D([t, t], [0, 1], color=col, lw=lw, zorder=10,
                            transform=blended_transform_factory(a.transData, a.transAxes))
                a.add_artist(ln)
                arts.append(ln)
            tr = blended_transform_factory(axes[0].transData, axes[0].transAxes)
            arts.append(axes[0].text(t, 0.985, f"C{i + 1}", color="white",
                                     fontsize=8, fontweight="bold", va="top",
                                     ha="center", transform=tr, zorder=11, clip_on=True,
                                     bbox=dict(boxstyle="round,pad=0.2", fc=col,
                                               ec="none")))
            self._cursor_artists[i] = arts

    def _move_cursor(self, i, t):
        self.cursor_t[i] = t
        for a in self._cursor_artists[i]:
            if hasattr(a, "set_xdata"):
                a.set_xdata([t, t])
            else:
                a.set_x(t)
        self._update_readout()
        self.draw_idle()

    def _cursor_near(self, ev):
        if not self.cursors_on or ev.inaxes is None:
            return None
        best, best_d = None, self.GRAB_PX
        for i, t in enumerate(self.cursor_t):
            if t is None:
                continue
            px = ev.inaxes.transData.transform((t, 0))[0]
            d = abs(px - ev.x)
            if d <= best_d:
                best, best_d = i, d
        return best

    def _edges(self):
        """Step changes of step signals and every point of measured signals."""
        edges = set()
        for tr in self.traces:
            xs, ys = tr["xs"], tr["ys"]
            if tr.get("step", True):
                edges.update(xs[k] for k in range(len(xs))
                             if k == 0 or k == len(xs) - 1 or ys[k] != ys[k - 1])
            else:
                edges.update(xs)
        return sorted(edges)

    # ---- read-out ----------------------------------------------------------------
    @staticmethod
    def _f(v, unit=""):
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return "–"
        return f"{f'{v:.6g}'} {unit}".strip()

    def _update_readout(self):
        if not self.on_readout:
            return
        if not self.cursors_on or not self.traces:
            self.on_readout("")
            return
        self._init_cursor_positions()
        if None in self.cursor_t:
            self.on_readout("")
            return
        t1, t2 = self.cursor_t
        dt = t2 - t1
        freq = f" &nbsp;(1/Δt = {self._f(1 / abs(dt), 'Hz')})" if dt else ""
        c1, c2 = self.CURSOR_COLORS
        h = ["<table cellspacing='0' cellpadding='2' style='font-size:9pt'>",
             "<tr><th align='left'></th>"
             f"<th style='color:{c1}'>C1</th><th style='color:{c2}'>C2</th>"
             "<th>Δ (C2−C1)</th><th>Min</th><th>Max</th><th>Mean</th><th>RMS</th></tr>",
             f"<tr><td><b>t</b></td><td>{self._f(t1, 's')}</td><td>{self._f(t2, 's')}</td>"
             f"<td colspan='5'><b>{self._f(dt, 's')}</b>{freq}</td></tr>"]
        for tr in self.traces:
            u = tr["unit"]
            if tr.get("step", True):
                v1 = core.step_value_at(tr["xs"], tr["ys"], t1)
                v2 = core.step_value_at(tr["xs"], tr["ys"], t2)
                st = core.step_stats(tr["xs"], tr["ys"], t1, t2) or {}
            else:
                v1 = core.linear_value_at(tr["xs"], tr["ys"], t1)
                v2 = core.linear_value_at(tr["xs"], tr["ys"], t2)
                st = core.linear_stats(tr["xs"], tr["ys"], t1, t2) or {}
            dv = None if v1 is None or v2 is None else v2 - v1
            h.append(f"<tr><td><b>{tr['name']}</b></td><td>{self._f(v1, u)}</td>"
                     f"<td>{self._f(v2, u)}</td><td><b>{self._f(dv, u)}</b></td>"
                     f"<td>{self._f(st.get('min'), u)}</td><td>{self._f(st.get('max'), u)}</td>"
                     f"<td>{self._f(st.get('mean'), u)}</td><td>{self._f(st.get('rms'), u)}</td></tr>")
        h.append("</table>")
        self.on_readout("".join(h))

    # ---- zoom ----------------------------------------------------------------------
    def _axes_at(self, x, y):
        return [a for a in self.fig.axes if a.bbox.contains(x, y)]

    def zoom_at(self, x, y, steps, x_only=False, y_only=False):
        """Zoom around pixel (x, y). steps > 0 zooms in."""
        hit = self._axes_at(x, y)
        if not hit:
            return
        f = self.ZOOM ** (-steps)
        if not y_only:
            a = hit[0]
            xd = a.transData.inverted().transform((x, y))[0]
            x0, x1 = a.get_xlim()
            n0, n1 = xd - (xd - x0) * f, xd + (x1 - xd) * f
            if abs(n1 - n0) > 1e-12 * max(1.0, abs(xd)):
                a.set_xlim(n0, n1)
                self._x_user = tuple(a.get_xlim())
        if x_only:
            if not self._y_user:
                self._autoscale_y_all()        # time zoom: Y follows the window
        else:
            for a in hit:
                if getattr(a, "_fixed_ylim", None):
                    continue
                yd = a.transData.inverted().transform((x, y))[1]
                y0, y1 = a.get_ylim()
                n0, n1 = yd - (yd - y0) * f, yd + (y1 - yd) * f
                if abs(n1 - n0) > 1e-12 * max(1.0, abs(yd)):
                    a.set_ylim(n0, n1)
            self._y_user = True
        self._schedule_relayout()
        self.draw_idle()

    def zoom_center(self, steps):
        """Zoom in (steps > 0) or out around the middle of the plot."""
        axes = self._primary_axes()
        if not axes:
            return
        bb = axes[0].bbox
        self.zoom_at((bb.x0 + bb.x1) / 2, (bb.y0 + bb.y1) / 2, steps * 2)

    def set_datatips(self, on: bool):
        self.datatip_mode = on
        if on:
            self.setCursor(Qt.CrossCursor)
        else:
            self.unsetCursor()

    def clear_datatips(self):
        for a in self._tips:
            try:
                a.remove()
            except (ValueError, AttributeError, NotImplementedError):
                pass
        self._tips = []
        self.draw_idle()

    def _add_datatip(self, ev):
        """Snap to the nearest data point (within 30 px) and label it."""
        best = None
        for a in self.fig.axes:
            for ln in self._data_lines(a):
                xs, ys = ln.get_xdata(), ln.get_ydata()
                if len(xs) == 0:
                    continue
                pts = a.transData.transform(list(zip([float(x) for x in xs],
                                                     [float(y) for y in ys])))
                for k, (px, py) in enumerate(pts):
                    if math.isnan(py):
                        continue
                    dist = math.hypot(px - ev.x, py - ev.y)
                    if best is None or dist < best[0]:
                        best = (dist, a, ln, float(xs[k]), float(ys[k]))
        if best is None or best[0] > 30:
            return
        _d, a, ln, x, y = best
        label = ln.get_label()
        name = label if label and not label.startswith("_") else (a.get_ylabel() or "value")
        dot, = a.plot([x], [y], "o", ms=6, mfc="white", mec="black", zorder=12)
        note = a.annotate(f"t = {x:.6g} s\n{name}: {y:.6g}", xy=(x, y), xytext=(12, 12),
                          textcoords="offset points", fontsize=8, zorder=13,
                          bbox=dict(boxstyle="round,pad=0.3", fc="#fffbe6", ec="#555"),
                          arrowprops=dict(arrowstyle="-", color="#555"))
        dot.set_gid("datatip")                  # not data: ignored by autoscale helpers
        self._tips += [dot, note]
        self.draw_idle()

    def _schedule_relayout(self):
        """Re-fit margins shortly after zooming stops (tick labels change width)."""
        t = getattr(self, "_relayout_timer", None)
        if t is None:
            try:
                t = QTimer(self); t.setSingleShot(True)
                t.timeout.connect(lambda: (self._relayout(), self.draw_idle()))
                self._relayout_timer = t
            except TypeError:
                return
        t.start(300)

    def wheelEvent(self, event):
        """Handle the wheel ourselves: matplotlib ignores horizontal wheel events,
        and Qt turns Shift+wheel into a horizontal wheel on Windows/Linux."""
        d = event.angleDelta()
        delta = d.y() or d.x()
        if not delta:
            event.ignore(); return
        mods = event.modifiers()
        pos = event.position() if hasattr(event, "position") else event.pos()
        x, y = self.mouseEventCoords(pos)
        self.zoom_at(x, y, delta / 120.0,
                     x_only=bool(mods & Qt.ControlModifier),
                     y_only=bool(mods & Qt.ShiftModifier))
        event.accept()

    def _on_scroll(self, ev):          # used when the wheel arrives via matplotlib
        mods = QApplication.keyboardModifiers()
        steps = getattr(ev, "step", 0) or (1 if ev.button == "up" else -1)
        self.zoom_at(ev.x, ev.y, steps,
                     x_only=bool(mods & Qt.ControlModifier),
                     y_only=bool(mods & Qt.ShiftModifier))

    # ---- mouse / keyboard -----------------------------------------------------------
    def _on_press(self, ev):
        if ev.inaxes is None:
            return
        if ev.dblclick and ev.button == 1:     # like MATLAB: back to the original view
            self._drag = None
            self.fit(); return
        if self._toolbar_busy():
            return
        if ev.button == 1:
            i = self._cursor_near(ev)
            if i is not None:
                self._drag = ("cursor", i)
                self.active_cursor = i
                self._draw_cursors(); self.draw_idle()
                return
        if ev.button == 1 and self.datatip_mode:
            self._drag = None
            self._add_datatip(ev)
            return
        if ev.button == 3 and self.cursors_on and ev.xdata is not None:
            # right click: put the active cursor here, then switch active cursor
            self._move_cursor(self.active_cursor, ev.xdata)
            self.active_cursor = 1 - self.active_cursor
            self._draw_cursors(); self.draw_idle()
            return
        if ev.button in (1, 2):
            self._drag = ["pan", ev.x, ev.y,
                          [(a, a.get_xlim(), a.get_ylim(), a.bbox.contains(ev.x, ev.y))
                           for a in self.fig.axes], False, False]

    def _on_motion(self, ev):
        if self._drag is None:
            if self.cursors_on and not self._toolbar_busy():
                if self._cursor_near(ev) is not None:
                    self.setCursor(Qt.SizeHorCursor)
                else:
                    self.unsetCursor()
            return
        if self._drag[0] == "cursor":
            axes = self._primary_axes()
            if axes:
                t = axes[0].transData.inverted().transform((ev.x, ev.y))[0]
                self._move_cursor(self._drag[1], t)
            return
        _, x0, y0, state, moved, moved_y = self._drag
        dx, dy = ev.x - x0, ev.y - y0
        if not moved and abs(dx) < self.DRAG_PX and abs(dy) < self.DRAG_PX:
            return                                   # a click, not a drag
        self._drag[4] = True
        if abs(dy) >= self.DRAG_PX:
            self._drag[5] = True
        for i, (a, xl, yl, inside) in enumerate(state):
            w, h = a.bbox.width or 1, a.bbox.height or 1
            if i == 0:
                sx = (xl[1] - xl[0]) * dx / w
                a.set_xlim(xl[0] - sx, xl[1] - sx)
            if inside and self._drag[5] and not getattr(a, "_fixed_ylim", None):
                sy = (yl[1] - yl[0]) * dy / h
                a.set_ylim(yl[0] - sy, yl[1] - sy)
        self.draw_idle()

    def _on_release(self, ev):
        drag, self._drag = self._drag, None
        if drag and drag[0] == "pan" and drag[4]:
            axes = self.fig.axes
            if axes:
                self._x_user = tuple(axes[0].get_xlim())
            if drag[5]:
                self._y_user = True
            self._schedule_relayout()
            self.draw_idle()

    def _on_key(self, ev):
        if ev.key in ("+", "=", "ctrl++"):
            self.zoom_center(1); return
        if ev.key in ("-", "_", "ctrl+-"):
            self.zoom_center(-1); return
        if ev.key in ("r", "home"):
            self.fit(); return
        if ev.key == "escape" and self._tips:
            self.clear_datatips(); return
        if not self.cursors_on or ev.key not in ("left", "right", "1", "2", "c"):
            return
        if ev.key in ("1", "2"):
            self.active_cursor = int(ev.key) - 1
            self._draw_cursors(); self.draw_idle(); return
        if ev.key == "c":                      # put both cursors back in view
            self.cursor_t = [None, None]
            self._draw_cursors(); self._update_readout(); self.draw_idle(); return
        edges = self._edges()
        t = self.cursor_t[self.active_cursor]
        if not edges or t is None:
            return
        import bisect
        eps = 1e-12
        if ev.key == "right":
            k = bisect.bisect_right(edges, t + eps)
            if k < len(edges): self._move_cursor(self.active_cursor, edges[k])
        else:
            k = bisect.bisect_left(edges, t - eps) - 1
            if k >= 0: self._move_cursor(self.active_cursor, edges[k])


class NavToolbar(NavigationToolbar2QT):
    """Matplotlib toolbar whose Home = Fit and whose zoom/pan are remembered."""

    def home(self, *args):
        self.canvas.fit()

    def release_zoom(self, event):
        super().release_zoom(event)
        self.canvas.toolbar_changed_view()

    def release_pan(self, event):
        super().release_pan(event)
        self.canvas.toolbar_changed_view()

    def back(self, *args):
        super().back(*args)
        self.canvas.toolbar_changed_view()

    def forward(self, *args):
        super().forward(*args)
        self.canvas.toolbar_changed_view()


class PlotPanel(QWidget):
    """Plot toolbar (MATLAB-like) + interactive canvas + cursor read-out."""
    HELP = ("Mouse wheel: zoom (Ctrl = time only, Shift = Y only) · drag: pan · "
            "double-click: original view · hover a button for details")

    def __init__(self, canvas: InteractiveCanvas, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        v = QVBoxLayout(self); v.setContentsMargins(2, 2, 2, 2); v.setSpacing(2)
        # matplotlib's own toolbar does the box zoom / pan modes; it stays hidden
        self.nav = NavToolbar(canvas, self); self.nav.setVisible(False)
        tb = QToolBar(); tb.setObjectName("plot_toolbar")
        self._tb, self._hint = tb, None
        tb.setToolButtonStyle(Qt.ToolButtonTextBesideIcon); tb.setIconSize(QSize(20, 20))

        def act(text, badge, color, tip, fn=None, checkable=False):
            a = QAction(badge_icon(badge, color), text, self); a.setToolTip(f"{text}: {tip}")
            a.setCheckable(checkable)
            if fn is not None:
                (a.toggled if checkable else a.triggered).connect(fn)
            tb.addAction(a)
            return a
        act("Restore view", "⌂", C_FILE,
            "Back to the original view (also: double-click the plot, or R)", canvas.fit)
        act("Zoom in", "+", C_FILE, "Zoom in around the centre (also: mouse wheel, +)",
            lambda: canvas.zoom_center(1))
        act("Zoom out", "−", C_FILE, "Zoom out (also: mouse wheel, −)",
            lambda: canvas.zoom_center(-1))
        self.act_box = act("Zoom box", "▭", C_FILE, "Drag a rectangle to zoom into it",
                           self._box, checkable=True)
        self.act_pan = act("Pan", "✥", C_FILE, "Drag to move the view "
                           "(dragging also pans when no tool is on)", self._pan,
                           checkable=True)
        act("Back", "◀", C_EDIT, "Previous view", self.nav.back)
        act("Forward", "▶", C_EDIT, "Next view", self.nav.forward)
        tb.addSeparator()
        self.act_tip = act("Data tips", "⌖", C_VIEW, "Click a point to label its time "
                           "and value (like MATLAB data tips)", self._tips, checkable=True)
        act("Clear tips", "✕", C_VIEW, "Remove all data tips (also: Esc)",
            canvas.clear_datatips)
        self.act_cur = act("Cursors", "||", C_DEV, "Two measurement cursors with "
                           "difference read-out: drag the lines, right-click places the "
                           "active cursor, ←/→ jump to the next edge, 1/2 select a cursor",
                           self._toggle, checkable=True)
        act("Copy values", "CP", C_DEV, "Copy the cursor read-out to the clipboard",
            self._copy)
        tb.addSeparator()
        act("Save image", "PNG", C_EDIT, "Save the plot as an image or PDF",
            self.nav.save_figure)
        v.addWidget(tb)
        v.addWidget(canvas, 1)
        self.lbl = QLabel(); self.lbl.setTextFormat(Qt.RichText)
        self.lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.lbl.setVisible(False)
        v.addWidget(self.lbl)
        self._hint = hint_label(self.HELP)
        v.addWidget(self._hint)
        canvas.on_readout = self._readout

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if self._tb is not None:
            w = self.width()
            self._tb.setToolButtonStyle(Qt.ToolButtonTextBesideIcon if w >= 1060 else
                                        Qt.ToolButtonTextUnderIcon if w >= 620 else
                                        Qt.ToolButtonIconOnly)
        if self._hint is not None:
            self._hint.setVisible(self.height() >= 360)

    def _sync_modes(self):
        mode = str(getattr(self.nav, "mode", "") or "").lower()
        for a, on in ((self.act_box, "zoom" in mode), (self.act_pan, "pan" in mode)):
            a.blockSignals(True); a.setChecked(on); a.blockSignals(False)

    def _box(self, on):
        if on and self.act_tip.isChecked():
            self.act_tip.setChecked(False)
        if on != ("zoom" in str(getattr(self.nav, "mode", "") or "").lower()):
            self.nav.zoom()
        self._sync_modes()

    def _pan(self, on):
        if on and self.act_tip.isChecked():
            self.act_tip.setChecked(False)
        if on != ("pan" in str(getattr(self.nav, "mode", "") or "").lower()):
            self.nav.pan()
        self._sync_modes()

    def _tips(self, on):
        if on:                                 # data tips need the plain mouse mode
            if self.act_box.isChecked():
                self._box(False)
            if self.act_pan.isChecked():
                self._pan(False)
        self.canvas.set_datatips(on)

    def _toggle(self, on):
        self.canvas.set_cursors(on)
        if on:
            self.canvas.setFocus()

    def _readout(self, html):
        self.lbl.setText(html)
        self.lbl.setVisible(bool(html))

    def _copy(self):
        doc = self.lbl.text()
        import re as _re
        text = _re.sub(r"</t[dh]>", "\t", doc)
        text = _re.sub(r"</tr>", "\n", text)
        text = _re.sub(r"<[^>]+>|&nbsp;", "", text)
        QApplication.clipboard().setText(text.strip())


class PlotCanvas(InteractiveCanvas):
    def __init__(self):
        super().__init__()
        self.ax = self.fig.add_subplot(111)

    def plot(self, points, channel, repeat, seg_bounds, selected, markers=(),
             lead_waits=0):
        ax = self.ax
        ax.clear()
        self.begin_traces()
        passes = 1 if repeat == 1 else (2 if repeat == 0 else min(repeat, 3))
        t, ts, vs = 0.0, [], []
        for p in range(passes):
            prev = vs[-1] if vs else None
            for k, (v, dt) in enumerate(points):
                if p > 0 and k < lead_waits and prev is not None:
                    v = prev               # a wait keeps the output where it was
                ts.append(t); vs.append(v)
                t += dt
        if vs:
            ts.append(t); vs.append(vs[-1])
            ax.step(ts, vs, where="post", lw=1.6, color="#1f6fb2")
            self.add_trace(channel, ts, vs, UNITS.get(channel, ""))
        one = sum(dt for _, dt in points)
        for p in range(1, passes):
            ax.axvline(p * one, color="grey", ls="--", lw=0.8)
        if selected is not None and 0 <= selected < len(seg_bounds):
            a, b = seg_bounds[selected]
            ax.axvspan(a, b, color="orange", alpha=0.2)
        for p in range(passes):
            for mt, mlabel in markers:
                x = mt + p * one
                ax.axvline(x, color="#9467bd", ls=":", lw=1.2)
                ax.text(x, 0.02, f" {mlabel}", color="#9467bd", fontsize=7,
                        rotation=90, va="bottom",
                        transform=ax.get_xaxis_transform())
        if not vs:
            ax.text(0.5, 0.5, "No segments – add one on the left",
                    ha="center", va="center", transform=ax.transAxes, color="grey")
        ax.set_xlabel("Time [s]")
        ax.set_ylabel(f"{channel} [{UNITS.get(channel, '')}]")
        title = "Preview"
        if repeat == 0:
            title += " (infinite loop – 2 passes shown)"
        elif repeat > 1:
            title += f" ({repeat} passes, {passes} shown)"
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        self.finish_plot()


# --------------------------------------------------------------------------
# Segment parameter editors (shared by main window and child dialogs)
# --------------------------------------------------------------------------
def build_segment_form(form: QFormLayout, seg: dict, on_changed, parent):
    """Fill `form` with editors for `seg`; edits are written into `seg`
    and `on_changed()` is called after every change."""
    kind = seg["type"]
    if kind == "Table":
        _build_table_editor(form, seg, on_changed)
        return

    if kind == "Combine":
        cb = QComboBox(); cb.addItems(core.COMBINE_OPS)
        cb.setCurrentText(seg["op"])
        def op_changed(text):
            seg["op"] = text; on_changed()
        cb.currentTextChanged.connect(op_changed)
        form.addRow("Operation", cb)

    for key, (label, options) in core.SEGMENT_CHOICES.get(kind, {}).items():
        cbx = QComboBox(); cbx.addItems(options)
        cbx.setCurrentText(seg.get(key, options[0]))
        def choice_changed(text, k=key):
            seg[k] = text; on_changed()
        cbx.currentTextChanged.connect(choice_changed)
        form.addRow(label, cbx)

    for key, label, _d, is_int in core.SEGMENT_TYPES[kind]:
        if is_int:
            w = QSpinBox(); w.setRange(1, 10000)
        else:
            w = QDoubleSpinBox(); w.setDecimals(4)
            w.setRange(-100000, 100000)
            w.setKeyboardTracking(False)
            if key == "dt": w.setSingleStep(0.01); w.setRange(0.001, 100000)
            if key == "duty": w.setRange(0, 100)
            if key in ("duration", "period"): w.setMinimum(0.001)
            if key == "freq": w.setMinimum(0)
            if key in ("duty_start", "duty_end"): w.setRange(0, 100)
            if key in ("tau", "preview"): w.setMinimum(0.001)
        w.setValue(seg[key])
        def changed(v, k=key):
            seg[k] = v; on_changed()
        w.valueChanged.connect(changed)
        form.addRow(label, w)

    if kind in core.WAIT_TYPES:
        what = ("the selected digital input has the chosen level"
                if kind == "Wait for input" else "a TRIGger:IMMediate command arrives")
        note = QLabel(f"On the supply the sequence pauses here until {what}. The output "
                      f"keeps its last value. The wait time above is only used for the "
                      f"preview plot.")
        note.setWordWrap(True); note.setObjectName("hint")
        form.addRow(note)
    if kind == "Battery":
        note = QLabel("Approximate Li-ion style discharge shape (fast initial drop, "
                      "plateau, knee to cut-off). Adjust the voltages for your cell or pack.")
        note.setWordWrap(True); note.setObjectName("hint")
        form.addRow(note)

    if kind == "Combine":
        child_labels = {}
        for slot, name in (("a", "Signal A"), ("b", "Signal B")):
            box = QWidget(); h = QHBoxLayout(box); h.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(core.describe_segment(seg[slot])); lbl.setWordWrap(True)
            child_labels[slot] = lbl
            btn = QPushButton("Edit…"); btn.setFixedWidth(60)
            def edit(_=False, slot=slot, name=name):
                dlg = SegmentDialog(seg[slot], parent, f"Edit {name}")
                if dlg.exec_() == QDialog.Accepted:
                    seg[slot] = dlg.seg
                    child_labels[slot].setText(core.describe_segment(dlg.seg))
                    on_changed()
            btn.clicked.connect(edit)
            h.addWidget(lbl, 1); h.addWidget(btn)
            form.addRow(name, box)
        def swap():
            seg["a"], seg["b"] = seg["b"], seg["a"]
            for slot in ("a", "b"):
                child_labels[slot].setText(core.describe_segment(seg[slot]))
            on_changed()
        b = QPushButton("Swap A ↔ B"); b.clicked.connect(swap)
        form.addRow(b)
        note = QLabel("Duration = longer of A and B; the shorter one holds its "
                      "last value. Result is sampled every 'Sample time'.")
        note.setWordWrap(True); note.setObjectName("hint")
        form.addRow(note)


def _build_table_editor(form: QFormLayout, seg: dict, on_changed):
    tbl = QTableWidget(len(seg["points"]), 3)
    tbl.setHorizontalHeaderLabels(["Value", "Hold [s]", "Starts at [s]"])
    tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    tbl.setMinimumHeight(200)
    for r, (v, t) in enumerate(seg["points"]):
        tbl.setItem(r, 0, QTableWidgetItem(f"{v:g}"))
        tbl.setItem(r, 1, QTableWidgetItem(f"{t:g}"))

    def fill_times():
        tbl.blockSignals(True)
        acc = 0.0
        for r in range(tbl.rowCount()):
            it = QTableWidgetItem(f"{acc:.6g}")
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it.setForeground(QBrush(QColor(128, 128, 128)))
            tbl.setItem(r, 2, it)
            try:
                acc += float(tbl.item(r, 1).text())
            except (AttributeError, ValueError):
                pass
        tbl.blockSignals(False)
    fill_times()

    def read_back(*_):
        pts = []
        for r in range(tbl.rowCount()):
            try:
                pts.append([float(tbl.item(r, 0).text()),
                            float(tbl.item(r, 1).text())])
            except (AttributeError, ValueError):
                pass                       # skip incomplete / non-numeric rows
        seg["points"] = pts
        fill_times()
        on_changed()

    def add_row():
        r = tbl.currentRow() + 1 if tbl.currentRow() >= 0 else tbl.rowCount()
        last = [0, 1]
        if r > 0:
            try:
                last = [float(tbl.item(r - 1, 0).text()), float(tbl.item(r - 1, 1).text())]
            except (AttributeError, ValueError):
                pass
        tbl.blockSignals(True)
        tbl.insertRow(r)
        tbl.setItem(r, 0, QTableWidgetItem(f"{last[0]:g}"))
        tbl.setItem(r, 1, QTableWidgetItem(f"{last[1]:g}"))
        tbl.blockSignals(False)
        read_back()

    def del_rows():
        for r in sorted({i.row() for i in tbl.selectedIndexes()}, reverse=True):
            tbl.removeRow(r)
        read_back()

    def paste():
        text = QApplication.clipboard().text()
        rows = []
        for ln in text.splitlines():
            if not ln.strip():
                continue
            if "\t" in ln:                       # Excel / LibreOffice copy
                cells = ln.split("\t")
            elif ";" in ln:                      # European CSV
                cells = ln.split(";")
            elif "," in ln and not (re.search(r"\s", ln.strip()) and all(
                    re.fullmatch(r"[-+]?\d+(,\d+)?", tok) for tok in ln.split())):
                cells = ln.split(",")            # "1.5,2" or "1.5, 2"
            else:
                cells = ln.split()               # "1.5 2" or decimal comma "1,5 2"
            cells = [c.strip().replace(",", ".") for c in cells if c.strip()]
            if len(cells) >= 2 and all(re.fullmatch(r"[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?", c)
                                       for c in cells[:2]):
                rows.append(cells)
        if not rows:
            QMessageBox.information(tbl, "Paste", "No rows with two numbers (value, hold "
                                    "time) found on the clipboard.")
            return
        tbl.blockSignals(True)
        tbl.setRowCount(len(rows))
        for r, (v, t, *_) in enumerate(rows):
            tbl.setItem(r, 0, QTableWidgetItem(v))
            tbl.setItem(r, 1, QTableWidgetItem(t))
        tbl.blockSignals(False)
        read_back()

    tbl.itemChanged.connect(read_back)
    btns = QWidget(); h = QHBoxLayout(btns); h.setContentsMargins(0, 0, 0, 0)
    for text, fn in [("Add row", add_row), ("Delete rows", del_rows),
                     ("Paste (Excel/CSV)", paste)]:
        b = QPushButton(text); b.clicked.connect(fn); h.addWidget(b)
    form.addRow(tbl)
    form.addRow(btns)


class SegmentDialog(QDialog):
    """Edit a child signal of a Combine segment (any type, can be nested)."""

    def __init__(self, seg: dict, parent=None, title="Edit signal"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(560, 620)
        self.seg = copy.deepcopy(seg)
        v = QVBoxLayout(self)
        top = QFormLayout()
        self.cb = QComboBox(); self.cb.addItems(core.SEGMENT_TYPES)
        self.cb.setCurrentText(self.seg["type"])
        self.cb.currentTextChanged.connect(self._type_changed)
        top.addRow("Signal type", self.cb)
        v.addLayout(top)
        self.holder = QWidget(); self.form = QFormLayout(self.holder)
        v.addWidget(self.holder)
        self.canvas = PlotCanvas(); self.canvas.setMinimumHeight(220)
        v.addWidget(self.canvas, 1)
        self.lbl_err = QLabel()
        v.addWidget(self.lbl_err)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self._rebuild()

    def _type_changed(self, kind):
        self.seg = core.default_segment(kind)
        self._rebuild()

    def _rebuild(self):
        while self.form.rowCount():
            self.form.removeRow(0)
        build_segment_form(self.form, self.seg, self._preview, self)
        self._preview()

    def _preview(self):
        try:
            pts = core.segment_preview(self.seg)
            self.lbl_err.setText("")
        except (ValueError, ZeroDivisionError) as e:
            pts = []; self.lbl_err.setText(str(e))
        self.canvas.plot(pts, "SV", 1, [], None)
        self.canvas.ax.set_ylabel("Value"); self.canvas.ax.set_title("Signal preview")
        self.canvas.draw_idle()


class SampleImportDialog(QDialog):
    """Load timestamp/value samples and convert them to a Table segment."""

    def __init__(self, parent, cfg):
        super().__init__(parent)
        self.base_cfg = copy.deepcopy(cfg)
        channel = cfg.channel
        self.setWindowTitle("Import samples")
        self.resize(1100, 720)
        self.rows: list[list[str]] = []
        self.samples: list[tuple[float, float]] = []
        self.points: list[list[float]] = []
        self.path = ""

        main = QHBoxLayout(self)
        left = QVBoxLayout(); main.addLayout(left, 0)

        # --- file
        gf = QGroupBox("1. Sample file"); ff = QFormLayout(gf)
        hb = QHBoxLayout()
        self.ed_path = QLineEdit(); self.ed_path.setReadOnly(True)
        b = QPushButton("Browse…"); b.clicked.connect(self.browse)
        hb.addWidget(self.ed_path, 1); hb.addWidget(b)
        ff.addRow(hb)
        self.chk_header = QCheckBox("First row is a header")
        self.cb_tcol = QComboBox(); self.cb_vcol = QComboBox()
        ff.addRow(self.chk_header)
        ff.addRow("Time column", self.cb_tcol)
        ff.addRow("Value column", self.cb_vcol)
        self.tbl_raw = QTableWidget(); self.tbl_raw.setMaximumHeight(140)
        self.tbl_raw.setEditTriggers(QAbstractItemView.NoEditTriggers)
        ff.addRow(self.tbl_raw)
        left.addWidget(gf)

        # --- time
        gt = QGroupBox("2. Time"); ft = QFormLayout(gt)
        self.cb_unit = QComboBox(); self.cb_unit.addItems(core.TIME_UNITS)
        self.cb_unit.setCurrentText("ms")
        self.cb_tmode = QComboBox()
        self.cb_tmode.addItems(["Timestamp (time of each sample)",
                                "Duration (hold time of each sample)"])
        self.chk_zero = QCheckBox("Start at t = 0 (shift first timestamp)")
        self.chk_zero.setChecked(True)
        self.sp_last = self._dspin(0.001, 1e6, 3, 1.0)
        ft.addRow("Time unit", self.cb_unit)
        ft.addRow("Time column is", self.cb_tmode)
        ft.addRow(self.chk_zero)
        ft.addRow("Hold last value [s]", self.sp_last)
        left.addWidget(gt)

        # --- signal shape
        gm = QGroupBox("3. Signal shape between samples"); fm = QFormLayout(gm)
        self.rb_step = QRadioButton("Step – hold each value until the next sample")
        self.rb_cont = QRadioButton("Continuous – linear interpolation, resampled")
        self.rb_step.setChecked(True)
        grp = QButtonGroup(self); grp.addButton(self.rb_step); grp.addButton(self.rb_cont)
        fm.addRow(self.rb_step); fm.addRow(self.rb_cont)
        self.sp_dt = self._dspin(1, 1e7, 1, 100.0)
        b_fit = QPushButton("Fit to 2000 steps"); b_fit.clicked.connect(self.fit_steps)
        fm.addRow("Resample step [ms]", self._row(self.sp_dt, b_fit))
        self.sp_minhold = self._dspin(1, 1e7, 1, 1.0)
        fm.addRow("Minimum hold [ms]", self.sp_minhold)
        self.sp_scale = self._dspin(-1e6, 1e6, 4, 1.0)
        self.sp_offset = self._dspin(-1e6, 1e6, 3, 0.0)
        fm.addRow("Value × scale + offset", self._row(self.sp_scale, self.sp_offset))
        left.addWidget(gm)

        # --- output
        go = QGroupBox("4. Output"); fo = QFormLayout(go)
        self.cb_ch = QComboBox(); self.cb_ch.addItems(CHANNELS)
        self.cb_ch.setCurrentIndex(list(CHANNELS.values()).index(channel))
        self.cb_rep = QComboBox()
        self.cb_rep.addItems(["Play once", "Repeat N times", "Continuous loop (∞)"])
        self.sp_n = QSpinBox(); self.sp_n.setRange(2, 65535); self.sp_n.setValue(2)
        self.cb_target = QComboBox()
        self.cb_target.addItems(["Replace current project", "Append as segment"])
        fo.addRow("Controlled", self.cb_ch)
        fo.addRow("Playback", self._row(self.cb_rep, self.sp_n))
        fo.addRow("Insert", self.cb_target)
        left.addWidget(go)
        left.addStretch()

        # --- right: preview
        right = QVBoxLayout(); main.addLayout(right, 1)
        self.canvas = PlotCanvas()
        right.addWidget(PlotPanel(self.canvas), 1)
        self.lbl = QLabel("Choose a file with time and value columns."); self.lbl.setWordWrap(True)
        right.addWidget(self.lbl)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Import")
        self.bb.accepted.connect(self.accept); self.bb.rejected.connect(self.reject)
        right.addWidget(self.bb)

        for w in (self.chk_header, self.chk_zero, self.rb_step, self.rb_cont):
            w.toggled.connect(self.update_preview)
        for w in (self.cb_tcol, self.cb_vcol, self.cb_unit, self.cb_tmode,
                  self.cb_ch, self.cb_rep, self.cb_target):
            w.currentIndexChanged.connect(self.update_preview)
        for w in (self.sp_last, self.sp_dt, self.sp_minhold, self.sp_scale,
                  self.sp_offset):
            w.valueChanged.connect(self.update_preview)
        self.sp_n.valueChanged.connect(self.update_preview)
        self.update_preview()

    @staticmethod
    def _dspin(lo, hi, dec, val):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setValue(val); s.setKeyboardTracking(False)
        return s

    @staticmethod
    def _row(*ws):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in ws: h.addWidget(x)
        return w

    def browse(self):
        fn, _ = _open_dialog(
            self, "Open sample file", "",
            "Samples (*.csv *.txt *.tsv *.dat *.xlsx *.xlsm);;All files (*)")
        if fn:
            self.load(fn)

    def load(self, fn):
        try:
            self.rows = core.read_table_file(fn)
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Read failed", str(e)); return
        if not self.rows:
            QMessageBox.warning(self, "Read failed", "The file is empty."); return
        self.path = fn
        self.ed_path.setText(fn)
        hdr = core.detect_header(self.rows)
        ncol = max(len(r) for r in self.rows[:50])
        names = [(self.rows[0][i] if hdr and i < len(self.rows[0]) else f"Column {i + 1}")
                 for i in range(ncol)]
        for cb in (self.cb_tcol, self.cb_vcol):
            cb.blockSignals(True); cb.clear(); cb.addItems(names); cb.blockSignals(False)
        self.cb_vcol.setCurrentIndex(1 if ncol > 1 else 0)
        # guess the time unit from the header text
        guess = core.guess_time_unit(names[0])
        if guess:
            self.cb_unit.setCurrentText(guess)
        if any(r and ":" in r[0] for r in self.rows[1 if hdr else 0:6]):
            self.cb_unit.setCurrentText("hh:mm:ss / date-time")
        self.chk_header.blockSignals(True); self.chk_header.setChecked(hdr)
        self.chk_header.blockSignals(False)
        show = self.rows[:8]
        self.tbl_raw.setRowCount(len(show)); self.tbl_raw.setColumnCount(ncol)
        for r, row in enumerate(show):
            for c, val in enumerate(row):
                self.tbl_raw.setItem(r, c, QTableWidgetItem(val))
        self.update_preview()

    def options(self) -> core.SampleImportOptions:
        return core.SampleImportOptions(
            time_is_duration=self.cb_tmode.currentIndex() == 1,
            zero_start=self.chk_zero.isChecked(),
            continuous=self.rb_cont.isChecked(),
            resample_dt=self.sp_dt.value() / 1000.0,
            last_hold=self.sp_last.value(),
            min_hold=self.sp_minhold.value() / 1000.0,
            scale=self.sp_scale.value(), offset=self.sp_offset.value())

    def repeat(self) -> int:
        i = self.cb_rep.currentIndex()
        return 1 if i == 0 else (self.sp_n.value() if i == 1 else 0)

    def channel(self) -> str:
        return CHANNELS[self.cb_ch.currentText()]

    def fit_steps(self):
        if len(self.samples) < 2: return
        span = self.samples[-1][0] - self.samples[0][0]
        dt = max(0.001, span / 950)               # ~2 steps per point + margin
        self.sp_dt.setValue(math.ceil(dt * 1000))
        self.rb_cont.setChecked(True)

    def update_preview(self, *_):
        self.sp_dt.setEnabled(self.rb_cont.isChecked())
        self.sp_minhold.setEnabled(self.rb_step.isChecked())
        self.sp_n.setEnabled(self.cb_rep.currentIndex() == 1)
        clock = self.cb_unit.currentText() == "hh:mm:ss / date-time"
        if clock and not self.chk_zero.isChecked():
            self.chk_zero.blockSignals(True); self.chk_zero.setChecked(True)
            self.chk_zero.blockSignals(False)
        self.chk_zero.setEnabled(not clock)        # clock times always start at 0
        ok_btn = self.bb.button(QDialogButtonBox.Ok)
        self.points = []
        ax = self.canvas.ax
        if not self.rows:
            ok_btn.setEnabled(False); return
        if getattr(self, "_shown_path", None) != self.path:      # new file: fit view
            self._shown_path = self.path
            self.canvas.reset_view()
        try:
            self.samples, skipped = core.extract_samples(
                self.rows, self.cb_tcol.currentIndex(), self.cb_vcol.currentIndex(),
                self.cb_unit.currentText(), self.chk_header.isChecked())
            self.points, warns = core.samples_to_points(self.samples, self.options())
        except (ValueError, ZeroDivisionError) as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
            ok_btn.setEnabled(False); return
        ch = self.channel()
        self.canvas.plot([tuple(p) for p in self.points], ch, self.repeat(), [], None)
        o = self.options()
        if self.samples:
            t0 = 0 if not o.zero_start or o.time_is_duration else self.samples[0][0]
            if o.time_is_duration:
                ts, acc = [], 0.0
                for d, _v in self.samples:
                    ts.append(acc); acc += d
            else:
                ts = [t - t0 for t, _ in self.samples]
            sv = [v * o.scale + o.offset for _, v in self.samples]
            order = sorted(range(len(ts)), key=ts.__getitem__)
            ts = [ts[i] for i in order]; sv = [sv[i] for i in order]
            ax.plot(ts, sv, "o", ms=3, color="#ff7f0e", label="samples")
            ax.legend(loc="best", fontsize=8)
            self.canvas.add_trace("samples", ts, sv, UNITS.get(ch, ""), step=False)
            if self.canvas._x_user is not None:
                self.canvas._autoscale_y_all()
            self.canvas._update_readout()
            self.canvas.draw_idle()
        # compile with the editor's settings (device, decimals, compact ramps …)
        test = copy.deepcopy(self.base_cfg)
        test.channel, test.repeat = ch, self.repeat()
        seg = {"type": "Table", "points": self.points}
        test.segments = [seg] if self.cb_target.currentIndex() == 0 \
            else test.segments + [seg]
        comp = core.compile_sequence(test)
        n_steps = len(comp.steps)
        dur = sum(p[1] for p in self.points)
        msg = [f"{len(self.samples)} samples → {len(self.points)} points → "
               f"<b>{n_steps} steps</b> (max {core.MAX_STEPS}) · {dur:.3f} s per pass"]
        if skipped:
            msg.append(f"{skipped} row(s) without numeric time/value were skipped.")
        msg += warns
        too_many = [e for e in comp.errors if "max 2000" in e]
        other = [e for e in comp.errors if "max 2000" not in e]
        if too_many:
            msg.append("<b>Too many steps</b> – use Continuous with a larger resample "
                       "step (or 'Fit to 2000 steps'), a larger minimum hold, or turn on "
                       "Compact ramps in the main window.")
        msg += [f"<b>Error:</b> {e}" for e in other]
        self.lbl.setText("<br>".join(msg))
        ok_btn.setEnabled(bool(self.points) and not comp.errors)


class ExportSamplesDialog(QDialog):
    """Export a (simulated) sequence as time/value samples (CSV, TXT, Excel)."""

    def __init__(self, parent, provider, title: str, default_name: str,
                 can_passes: bool):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(620, 560)
        self.provider = provider          # passes -> SimResult
        self.default_name = default_name
        self._cache: dict[int, core.SimResult] = {}
        self.header, self.rows = [], []
        f = QFormLayout(self)
        self.cb_unit = QComboBox(); self.cb_unit.addItems(["µs", "ms", "s", "min"])
        self.cb_unit.setCurrentText("s")
        self.cb_style = QComboBox()
        self.cb_style.addItems(["Exact steps (2 rows at each change)",
                                "Change points only (1 row per change)",
                                "Fixed sample interval"])
        self.sp_dt = QDoubleSpinBox(); self.sp_dt.setRange(0.001, 1e7)
        self.sp_dt.setDecimals(3); self.sp_dt.setValue(10); self.sp_dt.setSuffix(" ms")
        self.sp_pass = QSpinBox(); self.sp_pass.setRange(1, 1000)
        self.sp_pass.setEnabled(can_passes)
        self.chk_changing = QCheckBox("Only channels that change")
        self.chk_changing.setChecked(True)
        self.cb_delim = QComboBox(); self.cb_delim.addItems(["Comma ,", "Semicolon ;", "Tab"])
        f.addRow("Time unit", self.cb_unit)
        f.addRow("Rows", self.cb_style)
        f.addRow("Sample interval", self.sp_dt)
        f.addRow("Passes (repeats)", self.sp_pass)
        f.addRow(self.chk_changing)
        f.addRow("CSV separator", self.cb_delim)
        self.lbl = QLabel(); self.lbl.setWordWrap(True)
        f.addRow(self.lbl)
        self.txt = QPlainTextEdit(); self.txt.setReadOnly(True)
        self.txt.setFont(QFont("Consolas", 9))
        f.addRow(self.txt)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save); bb.rejected.connect(self.reject)
        self.btn_save = bb.button(QDialogButtonBox.Save)
        f.addRow(bb)
        for w in (self.cb_unit, self.cb_style, self.cb_delim):
            w.currentIndexChanged.connect(self.refresh_preview)
        self.sp_dt.valueChanged.connect(self.refresh_preview)
        self.sp_pass.valueChanged.connect(self.refresh_preview)
        self.chk_changing.toggled.connect(self.refresh_preview)
        self.refresh_preview()

    def _delim(self):
        return {0: ",", 1: ";", 2: "\t"}[self.cb_delim.currentIndex()]

    def refresh_preview(self, *_):
        self.sp_dt.setEnabled(self.cb_style.currentIndex() == 2)
        n = self.sp_pass.value()
        try:
            if n not in self._cache:
                QApplication.setOverrideCursor(Qt.WaitCursor)
                try:
                    self._cache[n] = self.provider(n)
                finally:
                    QApplication.restoreOverrideCursor()
            res = self._cache[n]
            traces = dict(res.traces)
            if self.chk_changing.isChecked():
                ch = {k: v for k, v in traces.items() if len({x for _, x in v}) > 1}
                traces = ch or {k: traces[k] for k in list(traces)[:1]}
            style = ("steps", "changes", "fixed")[self.cb_style.currentIndex()]
            self.header, self.rows = core.traces_to_table(
                traces, res.end_time, style, self.sp_dt.value() / 1000.0,
                self.cb_unit.currentText())
        except ValueError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
            self.btn_save.setEnabled(False); return
        self.btn_save.setEnabled(bool(self.rows))
        self.lbl.setText(f"{len(self.rows)} rows × {len(self.header)} columns · "
                         f"{res.end_time:.6g} s · {res.stop_reason}")
        d = self._delim()
        lines = [d.join(self.header)] + [d.join(f"{x:g}" for x in r)
                                         for r in self.rows[:200]]
        if len(self.rows) > 200:
            lines.append(f"… {len(self.rows) - 200} more rows")
        self.txt.setPlainText("\n".join(lines))

    def save(self):
        fn, flt = _save_dialog(
            self, "Export samples", f"{self.default_name}_samples.csv",
            "CSV (*.csv);;Text (*.txt);;Excel (*.xlsx)")
        if not fn: return
        if "xlsx" in flt and not fn.lower().endswith(".xlsx"):
            fn += ".xlsx"
        try:
            core.write_table_file(fn, self.header, self.rows, self._delim())
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Export failed", str(e)); return
        self.accept()


class ImportCanvas(InteractiveCanvas):
    """Multi-channel plot of a simulated (imported) sequence."""
    COLORS = {"SV": "#1f6fb2", "SC": "#d62728", "SP": "#2ca02c",
              "SCN": "#9467bd", "SPN": "#8c564b"}

    @staticmethod
    def _xy(trace, end):
        xs = [t for t, _ in trace] + [end]
        ys = [v for _, v in trace] + [trace[-1][1]]
        return xs, ys

    def plot(self, res: core.SimResult, title: str):
        self.fig.clear()
        self.begin_traces()
        tr, end = res.traces, max(res.end_time, 1e-3)
        extra = [c for c in ("SP", "SCN", "SPN") if c in tr]
        digital = sorted(c for c in tr if c.startswith("O"))
        rows = 1 + (1 if extra else 0) + (1 if digital else 0)
        ratios = [3] + ([2] if extra else []) + ([1.2] if digital else [])
        axes = self.fig.subplots(rows, 1, sharex=True,
                                 gridspec_kw={"height_ratios": ratios})
        axes = [axes] if rows == 1 else list(axes)

        ax = axes[0]
        x, y = self._xy(tr["SV"], end)
        ax.step(x, y, where="post", color=self.COLORS["SV"], lw=1.6, label="SV")
        self.add_trace("SV", x, y, "V")
        ax.set_ylabel("SV [V]", color=self.COLORS["SV"])
        ax2 = ax.twinx(); ax2._is_twin = True
        x, y = self._xy(tr["SC"], end)
        self.add_trace("SC", x, y, "A")
        ax2.step(x, y, where="post", color=self.COLORS["SC"], lw=1.2, ls="--",
                 label="SC")
        ax2.set_ylabel("SC [A]", color=self.COLORS["SC"])
        ax.grid(True, alpha=0.3)
        ax.set_title(title, fontsize=10)

        i = 1
        if extra:
            a = axes[i]; i += 1
            for c in extra:
                x, y = self._xy(tr[c], end)
                a.step(x, y, where="post", color=self.COLORS[c], lw=1.3, label=c)
                self.add_trace(c, x, y, UNITS.get(c, ""))
            a.legend(loc="upper right", fontsize=8); a.grid(True, alpha=0.3)
            a.set_ylabel("Power / sink")
        if digital:
            a = axes[i]
            for k, c in enumerate(digital):
                x, y = self._xy(tr[c], end)
                a.step(x, [v * 0.8 + k for v in y], where="post", lw=1.2)
                self.add_trace(c, x, y)
            a.set_yticks([k + 0.4 for k in range(len(digital))])
            a.set_yticklabels(digital, fontsize=8)
            a.set_ylim(-0.2, len(digital)); a.grid(True, axis="x", alpha=0.3)
            a._fixed_ylim = (-0.2, len(digital))
        axes[-1].set_xlabel("Time [s]")
        self.finish_plot()


# ==========================================================================
# Settings memory (last folders, connection, window layout, recent files)
# ==========================================================================
_SETTINGS = None


def settings() -> QSettings:
    global _SETTINGS
    if _SETTINGS is None:
        _SETTINGS = QSettings("DeltaSeqBuilder", "SequenceBuilder")
    return _SETTINGS


def _last_dir() -> str:
    return settings().value("dirs/last", "", type=str) or ""


def _remember_dir(fn: str):
    if fn:
        settings().setValue("dirs/last", os.path.dirname(fn))


def _open_dialog(parent, caption, directory="", flt=""):
    fn, f = QFileDialog.getOpenFileName(parent, caption, directory or _last_dir(), flt)
    _remember_dir(fn)
    return fn, f


def _save_dialog(parent, caption, default="", flt=""):
    d = _last_dir()
    path = os.path.join(d, os.path.basename(default)) if d and default else default
    fn, f = QFileDialog.getSaveFileName(parent, caption, path, flt)
    _remember_dir(fn)
    return fn, f


def conn_params() -> dict:
    s = settings()
    return {"host": s.value("conn/host", "192.168.0.100", type=str),
            "port": int(s.value("conn/port", core.DEFAULT_PORT)),
            "timeout": float(s.value("conn/timeout", 2.0)),
            "delay": float(s.value("conn/delay", 0.0))}


def conn_queries() -> dict:
    s = settings()
    return {k: s.value(f"conn/q_{k}", q, type=str) for k, q in core.DEFAULT_QUERIES.items()}


def hv_threshold() -> float:
    return float(settings().value("safety/hv", 60.0))


def confirm_high_voltage(parent, max_v: float) -> bool:
    th = hv_threshold()
    if th <= 0 or max_v <= th:
        return True
    box = QMessageBox(QMessageBox.Warning, "High voltage",
                      f"<b>This sets up to {max_v:.6g} V</b> (above your "
                      f"{th:g} V confirmation level).<br><br>Check that covers are "
                      f"fitted, wiring is rated and nobody can touch live parts.<br>"
                      f"Continue?", QMessageBox.Yes | QMessageBox.No, parent)
    box.setDefaultButton(QMessageBox.No)
    return box.exec_() == QMessageBox.Yes


# Parts of the app that hold a connection right now (worker id -> name).
ACTIVE_CONNECTIONS: dict[int, str] = {}


def active_users() -> list[str]:
    return sorted(set(ACTIVE_CONNECTIONS.values()))


class GuiPsuConnection(core.PsuConnection):
    """Explains a refused connection when another part of the app is connected."""

    def open(self):
        try:
            return super().open()
        except core.PsuError as e:
            users = active_users()
            if users:
                raise core.PsuError(
                    f"{e}\n\n{', '.join(users)} is connected to the supply right now. "
                    f"Some supplies accept only one connection at a time – stop or "
                    f"disconnect it and try again.") from e
            raise


def make_conn() -> core.PsuConnection:
    return GuiPsuConnection(**conn_params())


class ConnectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Power supply connection")
        p, q = conn_params(), conn_queries()
        f = QFormLayout(self)
        self.ed_host = QLineEdit(p["host"])
        self.sp_port = QSpinBox(); self.sp_port.setRange(1, 65535); self.sp_port.setValue(p["port"])
        self.sp_to = QDoubleSpinBox(); self.sp_to.setRange(0.1, 60); self.sp_to.setValue(p["timeout"])
        self.sp_to.setSuffix(" s")
        self.sp_delay = QDoubleSpinBox(); self.sp_delay.setRange(0, 1000)
        self.sp_delay.setDecimals(0); self.sp_delay.setValue(p["delay"] * 1000)
        self.sp_delay.setSuffix(" ms")
        f.addRow("IP address / host", self.ed_host)
        f.addRow("TCP port (Delta: 8462)", self.sp_port)
        f.addRow("Reply timeout", self.sp_to)
        f.addRow("Delay between commands", self.sp_delay)
        self.sp_hv = QDoubleSpinBox(); self.sp_hv.setRange(0, 100000)
        self.sp_hv.setValue(hv_threshold()); self.sp_hv.setSuffix(" V")
        self.sp_hv.setSpecialValueText("never ask")
        self.sp_hv.setToolTip("Ask for an extra confirmation before uploading or "
                              "starting anything that sets a higher voltage")
        f.addRow("Confirm uploads above", self.sp_hv)
        self.ed_q = {}
        for k, label in (("V", "Measure voltage query"), ("I", "Measure current query"),
                         ("P", "Measure power query (empty = off)")):
            self.ed_q[k] = QLineEdit(q[k]); f.addRow(label, self.ed_q[k])
        gcmd = QGroupBox("Direct-control commands (change only if your firmware differs)")
        fc = QFormLayout(gcmd)
        self.ed_cmd = {}
        cur = control_cmds()
        for k, label in CONTROL_LABELS.items():
            self.ed_cmd[k] = QLineEdit(cur[k]); fc.addRow(label, self.ed_cmd[k])
        b_def = QPushButton("Reset commands to defaults")
        b_def.clicked.connect(lambda: [e.setText(core.DEFAULT_CONTROL_CMDS[k])
                                       for k, e in self.ed_cmd.items()])
        fc.addRow(b_def)
        f.addRow(gcmd)
        b = QPushButton("Test connection (*IDN?)"); b.clicked.connect(self.test)
        f.addRow(b)
        self.lbl = QLabel(); self.lbl.setWordWrap(True); f.addRow(self.lbl)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save); bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _store(self):
        s = settings()
        s.setValue("conn/host", self.ed_host.text().strip())
        s.setValue("conn/port", self.sp_port.value())
        s.setValue("conn/timeout", self.sp_to.value())
        s.setValue("conn/delay", self.sp_delay.value() / 1000.0)
        s.setValue("safety/hv", self.sp_hv.value())
        for k, e in self.ed_q.items():
            s.setValue(f"conn/q_{k}", e.text().strip())
        for k, e in self.ed_cmd.items():
            s.setValue(f"cmd/{k}", e.text().strip() or core.DEFAULT_CONTROL_CMDS[k])

    def test(self):
        self._store()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                idn = core.identify(con)
                m = core.measure(con, conn_queries())
            self.lbl.setText(f"<b>Connected:</b> {idn}<br>V = {m.get('V')}, "
                             f"I = {m.get('I')}, P = {m.get('P')}")
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
        finally:
            QApplication.restoreOverrideCursor()

    def save(self):
        self._store(); self.accept()


def run_with_progress(parent, title, func):
    """Run func(progress_cb) with a cancellable progress dialog."""
    dlg = QProgressDialog(title, "Cancel", 0, 100, parent)
    dlg.setWindowModality(Qt.WindowModal); dlg.setMinimumDuration(300)

    def progress(i, n):
        dlg.setMaximum(n); dlg.setValue(i)
        QApplication.processEvents()
        return not dlg.wasCanceled()
    try:
        return func(progress)
    finally:
        dlg.close()


class ReportInfoDialog(QDialog):
    def __init__(self, parent, title="Power supply test report"):
        super().__init__(parent)
        self.setWindowTitle("PDF test report")
        f = QFormLayout(self)
        self.ed_title = QLineEdit(title)
        self.ed_op = QLineEdit(settings().value("report/operator", "", type=str))
        self.ed_dut = QLineEdit(settings().value("report/dut", "", type=str))
        self.ed_notes = QPlainTextEdit(); self.ed_notes.setMaximumHeight(90)
        f.addRow("Title", self.ed_title); f.addRow("Operator", self.ed_op)
        f.addRow("Device under test", self.ed_dut); f.addRow("Notes", self.ed_notes)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        f.addRow(bb)

    def info(self) -> dict:
        settings().setValue("report/operator", self.ed_op.text())
        settings().setValue("report/dut", self.ed_dut.text())
        return {"title": self.ed_title.text() or "Test report",
                "Operator": self.ed_op.text(), "Device under test": self.ed_dut.text()}


def save_pdf_report(parent, info, planned, measured, results, notes):
    fn, _ = _save_dialog(parent, "Save PDF report",
                         time.strftime("report_%Y%m%d_%H%M%S.pdf"), "PDF (*.pdf)")
    if not fn:
        return
    if not fn.lower().endswith(".pdf"):
        fn += ".pdf"
    QApplication.setOverrideCursor(Qt.WaitCursor)
    try:
        core.make_report(fn, info, planned, measured, results, notes)
    except (OSError, ValueError) as e:
        QMessageBox.critical(parent, "Report", str(e)); return
    finally:
        QApplication.restoreOverrideCursor()
    QMessageBox.information(parent, "Report", f"Saved:\n{fn}")


class ReadBackDialog(QDialog):
    """Download a stored sequence from the supply."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Read sequence from power supply")
        self.resize(460, 420)
        self.text, self.raw = "", []
        v = QVBoxLayout(self)
        p = conn_params()
        v.addWidget(QLabel(f"Supply: <b>{p['host']}:{p['port']}</b> "
                           f"(change under Device → Connection settings)"))
        h = QHBoxLayout()
        b = QPushButton("List stored sequences"); b.clicked.connect(self.refresh)
        h.addWidget(b); h.addStretch(); v.addLayout(h)
        self.lst = QListWidget(); v.addWidget(self.lst, 1)
        self.lst.currentTextChanged.connect(lambda t: self.ed_name.setText(t))
        f = QFormLayout()
        self.ed_name = QLineEdit(); f.addRow("Sequence name", self.ed_name)
        self.sp_max = QSpinBox(); self.sp_max.setRange(1, core.MAX_STEPS)
        self.sp_max.setValue(core.MAX_STEPS)
        f.addRow("Scan up to step", self.sp_max)
        self.sp_empty = QSpinBox(); self.sp_empty.setRange(1, core.MAX_STEPS)
        self.sp_empty.setValue(50)
        f.addRow("Stop after empty steps (after END)", self.sp_empty)
        v.addLayout(f)
        self.lbl = QLabel(); self.lbl.setWordWrap(True); v.addWidget(self.lbl)
        bb = QDialogButtonBox(QDialogButtonBox.Cancel)
        self.btn = bb.addButton("Read", QDialogButtonBox.AcceptRole)
        bb.accepted.connect(self.read); bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def refresh(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                names = core.list_sequences(con)
            self.lst.clear(); self.lst.addItems(names)
            self.lbl.setText(f"{len(names)} sequence(s) stored." if names else
                             "No names returned – type the name below.")
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
        finally:
            QApplication.restoreOverrideCursor()

    def read(self):
        name = self.ed_name.text().strip()
        if not name:
            self.lbl.setText("Enter or pick a sequence name."); return
        log = []
        try:
            with make_conn() as con:
                self.text, self.raw = run_with_progress(
                    self, f"Reading '{name}'…",
                    lambda prog: core.read_sequence(
                        con, name, self.sp_max.value(), self.sp_empty.value(),
                        progress=prog, log=log.append))
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}"); return
        if self.text.count("\n") <= 1:
            self.lbl.setText("No steps were read. See Messages for the raw replies.")
        self.name = name
        self.raw = log + self.raw
        self.accept()


# ==========================================================================
# Live measurement logging
# ==========================================================================
class LiveWorker(QThread):
    idn = pyqtSignal(str)
    sample = pyqtSignal(float, object)
    status = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, params, queries, interval, start_cmds, stop_cmds):
        super().__init__()
        self.params, self.queries = params, queries
        self.interval = interval
        self.start_cmds, self.stop_cmds = start_cmds, stop_cmds
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            with GuiPsuConnection(**self.params) as con:
                ACTIVE_CONNECTIONS[id(self)] = "Live monitor"
                try:
                    self.idn.emit(core.identify(con))
                except core.PsuError:
                    pass
                for cmd in self.start_cmds:
                    con.write(cmd)
                t0 = time.monotonic()
                next_state = 0.0
                while not self._stop:
                    t_loop = time.monotonic()
                    t = t_loop - t0
                    self.sample.emit(t, core.measure(con, self.queries))
                    if t >= next_state:
                        try:
                            self.status.emit(con.query("PROG:SEL:STA?", timeout=0.5))
                        except core.PsuError:
                            pass
                        next_state = t + 1.0
                    rest = self.interval - (time.monotonic() - t_loop)
                    while rest > 0 and not self._stop:
                        time.sleep(min(rest, 0.05)); rest -= 0.05
                for cmd in self.stop_cmds:
                    con.write(cmd)
        except core.PsuError as e:
            self.failed.emit(str(e))
        finally:
            ACTIVE_CONNECTIONS.pop(id(self), None)


class LiveCanvas(InteractiveCanvas):
    def setup(self, planned: dict | None, band=None, band_on_current=False):
        """(Re)build the axes. Keeps the user's time window and cursor positions."""
        self.fig.clear(); self.begin_traces()
        self.ax = ax = self.fig.add_subplot(111)
        self.ax2 = ax2 = ax.twinx(); ax2._is_twin = True
        self.planned = planned or {}
        for name, a, col in (("SV", ax, "#1f6fb2"), ("SC", ax2, "#d62728")):
            tr = self.planned.get(name)
            if tr:
                xs = [t for t, _ in tr]; ys = [v for _, v in tr]
                a.step(xs, ys, where="post", color=col, lw=1.0, ls="--", alpha=0.6,
                       label=f"Planned {name}")
        if band:
            a = ax2 if band_on_current else ax
            a.fill_between([b[0] for b in band], [b[1] for b in band],
                           [b[2] for b in band], step="post", color="#9ecae1",
                           alpha=0.35, label="Tolerance")
        self.l_fail, = (ax2 if band_on_current else ax).plot(
            [], [], "x", color="#c62828", ms=5, label="Out of tolerance")
        self.l_v, = ax.plot([], [], color="#1f6fb2", lw=1.6, label="Measured V")
        self.l_i, = ax2.plot([], [], color="#d62728", lw=1.3, label="Measured I")
        ax.set_xlabel("Time since start [s]"); ax.set_ylabel("Voltage [V]", color="#1f6fb2")
        ax2.set_ylabel("Current [A]", color="#d62728")
        ax.grid(True, alpha=0.3)
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="upper right", fontsize=8)
        ax.set_title("Live measurement")
        self._y_user = False
        self._relayout()
        self._draw_cursors()
        self.update_data([], [], [], 0)

    def update_data(self, ts, vs, is_, follow, fails=((), ())):
        self.l_v.set_data(ts, vs); self.l_i.set_data(ts, is_)
        self.l_fail.set_data(list(fails[0]), list(fails[1]))
        self.traces = []
        for name, unit in (("SV", "V"), ("SC", "A")):
            tr = self.planned.get(name)
            if tr:
                self.add_trace(f"Planned {name}", [t for t, _ in tr],
                               [v for _, v in tr], unit)
        if ts:
            self.add_trace("Measured V", ts, vs, "V", step=False)
            self.add_trace("Measured I", ts, is_, "A", step=False)
        if follow > 0 and ts:
            self.ax.set_xlim(max(0.0, ts[-1] - follow), max(ts[-1], follow) + follow * 0.02)
        elif self._x_user is None:
            for a in (self.ax, self.ax2):
                a.relim(visible_only=True)
                a.set_autoscale_on(True)
                a.autoscale_view(scaley=False)
        if not self._y_user:
            self._autoscale_y_all()          # Y fits what is visible
        self._update_readout()
        self.draw_idle()


class LiveMonitorDialog(QWidget):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("Live monitor")
        self.resize(1000, 700)
        self.worker = None
        self.ts, self.vs, self.is_, self.ps = [], [], [], []
        self.dirty = False
        v = QVBoxLayout(self)
        p = conn_params()
        self.cb_plan = QComboBox()
        self.cb_plan.addItems(["Editor sequence", "Script / imported sequence", "None"])
        self.sp_int = QSpinBox(); self.sp_int.setRange(20, 60000); self.sp_int.setValue(200)
        self.sp_int.setSuffix(" ms")
        self.sp_follow = QDoubleSpinBox(); self.sp_follow.setRange(0, 1e6)
        self.sp_follow.setSpecialValueText("all"); self.sp_follow.setSuffix(" s")
        v.addLayout(flow(pair(f"Supply <b>{p['host']}:{p['port']}</b>"),
                         pair("Planned:", self.cb_plan), pair("Interval", self.sp_int),
                         pair("Follow last", self.sp_follow)))
        opt = FlowLayout()
        self.chk_upload = QCheckBox("Upload editor sequence first")
        self.chk_out = QCheckBox("Switch output ON")
        self.chk_run = QCheckBox("Start sequence:")
        self.ed_name = QLineEdit(main.cfg.name); self.ed_name.setMaximumWidth(140)
        self.chk_stop = QCheckBox("On Stop: stop sequence + output OFF")
        self.chk_stop.setChecked(True)
        for w in (self.chk_upload, self.chk_out, pair(self.chk_run, self.ed_name),
                  self.chk_stop):
            opt.addWidget(w)
        v.addLayout(opt)
        tol = FlowLayout()
        self.chk_tol = QCheckBox("Tolerance check on")
        self.cb_tolch = QComboBox(); self.cb_tolch.addItems(["Voltage", "Current"])
        self.sp_tabs = QDoubleSpinBox(); self.sp_tabs.setRange(0, 1e6); self.sp_tabs.setDecimals(4)
        self.sp_tabs.setValue(0.5); self.sp_tabs.setPrefix("± ")
        self.sp_tpct = QDoubleSpinBox(); self.sp_tpct.setRange(0, 100); self.sp_tpct.setValue(2)
        self.sp_tpct.setPrefix("± "); self.sp_tpct.setSuffix(" %")
        self.sp_settle = QDoubleSpinBox(); self.sp_settle.setRange(0, 1e4); self.sp_settle.setDecimals(3)
        self.sp_settle.setValue(0.2); self.sp_settle.setSuffix(" s")
        self.sp_toff = QDoubleSpinBox(); self.sp_toff.setRange(-1e4, 1e4); self.sp_toff.setDecimals(3)
        self.sp_toff.setSuffix(" s")
        self.sp_toff.setToolTip("Shift the planned curve in time to line it up with the "
                                "measurement (e.g. start delay)")
        tol.addWidget(pair(self.chk_tol, self.cb_tolch))
        tol.addWidget(pair(self.sp_tabs, self.sp_tpct, "(whichever larger)"))
        tol.addWidget(pair("Settle", self.sp_settle))
        tol.addWidget(pair("Planned offset", self.sp_toff))
        self.lbl_tol = QLabel(""); tol.addWidget(self.lbl_tol)
        v.addLayout(tol)
        for w in (self.chk_tol,):
            w.toggled.connect(lambda *_: self._setup_plot())
        self.cb_tolch.currentIndexChanged.connect(lambda *_: self._setup_plot())
        for w in (self.sp_tabs, self.sp_tpct, self.sp_settle, self.sp_toff):
            w.valueChanged.connect(lambda *_: self._setup_plot())
        self.idn_text = ""
        btns = FlowLayout()
        self.b_start = QPushButton("▶ Start logging"); self.b_start.clicked.connect(self.start)
        set_role(self.b_start, "go")
        self.b_stop = QPushButton("■ Stop"); self.b_stop.clicked.connect(self.stop)
        set_role(self.b_stop, "danger")
        self.b_stop.setEnabled(False)
        b_clear = QPushButton("Clear"); b_clear.clicked.connect(self.clear)
        b_save = QPushButton("Save log…"); b_save.clicked.connect(self.save)
        b_rep = QPushButton("PDF report…"); b_rep.clicked.connect(self.report)
        for b in (self.b_start, self.b_stop, b_clear, b_save, b_rep):
            btns.addWidget(b)
        self.lbl = QLabel("Not running."); btns.addWidget(self.lbl)
        v.addLayout(btns)
        self.canvas = LiveCanvas()
        v.addWidget(PlotPanel(self.canvas), 1)
        self.timer = QTimer(self); self.timer.timeout.connect(self._redraw)
        self.cb_plan.currentIndexChanged.connect(lambda *_: self._setup_plot())
        self._setup_plot()

    def _planned(self):
        i = self.cb_plan.currentIndex()
        try:
            if i == 0:
                cfg = self.main.cfg
                if core.compile_sequence(cfg).errors:
                    return None
                if cfg.repeat == 0:      # endless: plan enough passes for ~1 hour
                    comp = core.compile_sequence(cfg)
                    one = max(comp.duration_one_pass, 1e-3)
                    passes = max(3, min(math.ceil(3600.0 / one),
                                        max(3, 100_000 // max(len(comp.points), 1))))
                    return core.simulate_settings(cfg, passes).traces
                return core.simulate_settings(cfg, max(cfg.repeat, 1)).traces
            if i == 1 and self.main.imported:
                return core.simulate(self.main.imported, max_time=self.main.sp_simtime.value(),
                                     inputs=self.main._parse_inputs(), step_time=0.0).traces
        except (ValueError, ZeroDivisionError):
            return None
        return None

    def _tol_key(self):
        return ("SC", "I") if self.cb_tolch.currentIndex() == 1 else ("SV", "V")

    def _tol_result(self):
        if not self.chk_tol.isChecked() or not self.planned_traces:
            return None
        pk, _mk = self._tol_key()
        plan = self.planned_traces.get(pk)
        if not plan:
            return None
        meas = list(zip(self.ts, self.is_ if pk == "SC" else self.vs))
        return core.tolerance_check(plan, meas, self.sp_tabs.value(), self.sp_tpct.value(),
                                    self.sp_settle.value(), self.sp_toff.value(),
                                    end_time=self.planned_end)

    def _setup_plot(self):
        r = None
        self.planned_traces = self._planned() or {}
        self.planned_end = None
        if self.planned_traces:
            self.planned_end = max(t for tr in self.planned_traces.values() for t, _ in tr)
        if self.chk_tol.isChecked() and self.planned_traces:
            pk, _ = self._tol_key()
            if self.planned_traces.get(pk):
                r = core.tolerance_check(self.planned_traces[pk], [], self.sp_tabs.value(),
                                         self.sp_tpct.value(), 0, self.sp_toff.value(),
                                         end_time=self.planned_end)
        shifted = {k: [(t + self.sp_toff.value(), v) for t, v in tr]
                   for k, tr in self.planned_traces.items()}
        self.canvas.setup(shifted, r.band if r else None, self._tol_key()[0] == "SC")
        self.dirty = True; self._redraw()

    def start(self):
        if self.worker:
            return
        start, stop = [], []
        if self.chk_upload.isChecked():
            comp = core.compile_sequence(self.main.cfg)
            if comp.errors:
                QMessageBox.warning(self, "Live monitor", "The editor sequence has errors:\n"
                                    + "\n".join(comp.errors)); return
            start += [ln for ln in core.to_scpi_lines(self.main.cfg, comp)
                      if not ln.upper().startswith("PROG:SEL:STA")]
            self.ed_name.setText(self.main.cfg.name)
        if self.chk_out.isChecked():
            if QMessageBox.question(self, "Output ON",
                                    "Switch the power supply output ON now?") != QMessageBox.Yes:
                return
            start.append("OUTP 1")
        if self.chk_run.isChecked():
            start += core._split_cmds(control_cmds()["seq_source"])
            start += [f"PROG:SEL:NAM {self.ed_name.text().strip()}", "PROG:SEL:STA RUN"]
        if start:
            plan = self._planned() or {}
            vmax = max((v for _, v in plan.get("SV", [])), default=0.0)
            if self.chk_upload.isChecked():
                vmax = max(vmax, core.max_setpoint(core.compile_sequence(self.main.cfg).steps))
            if not confirm_high_voltage(self, vmax):
                return
        self.t_start_wall = time.strftime("%Y-%m-%d %H:%M:%S")
        if self.chk_stop.isChecked():
            stop = ["PROG:SEL:STA STOP", "OUTP 0"]
        self.clear()
        self._setup_plot()
        self.worker = LiveWorker(conn_params(), conn_queries(),
                                 self.sp_int.value() / 1000.0, start, stop)
        self.worker.sample.connect(self._on_sample)
        self.worker.idn.connect(lambda s: setattr(self, "idn_text", s))
        self.worker.status.connect(lambda s: setattr(self, "seq_state", s))
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self._on_finished)
        self.seq_state = "?"
        self.worker.start()
        self.timer.start(250)
        self.b_start.setEnabled(False); self.b_stop.setEnabled(True)
        self.lbl.setText("Connecting…")

    def stop(self):
        if self.worker:
            self.worker.stop()

    def _on_sample(self, t, vals):
        self.ts.append(t)
        self.vs.append(vals.get("V") if vals.get("V") is not None else math.nan)
        self.is_.append(vals.get("I") if vals.get("I") is not None else math.nan)
        self.ps.append(vals.get("P") if vals.get("P") is not None else math.nan)
        self.dirty = True

    def _on_failed(self, msg):
        QMessageBox.critical(self, "Live monitor", msg)

    def _on_finished(self):
        self.worker = None
        self.timer.stop(); self._redraw()
        self.b_start.setEnabled(True); self.b_stop.setEnabled(False)
        self.lbl.setText(f"Stopped · {len(self.ts)} samples")

    def _redraw(self):
        if not self.dirty:
            return
        self.dirty = False
        t_start = time.perf_counter()
        r = self._tol_result()
        fails = ((), ())
        if r:
            import bisect
            ys = self.is_ if self._tol_key()[0] == "SC" else self.vs
            fy = [ys[min(bisect.bisect_left(self.ts, t), len(ys) - 1)] for t in r.fail_times]
            fails = (r.fail_times, fy)
            self.lbl_tol.setText(f"<b>{'PASS' if r.passed else 'FAIL'}"
                                 f"</b> · {r.n_fail}/{r.n_checked} outside · max |dev| "
                                 f"{r.max_dev:.4g}")
        elif self.chk_tol.isChecked():
            self.lbl_tol.setText("no planned curve to check against")
        if r and self.ts and self.planned_end is not None and \
                self.ts[-1] > self.planned_end + self.sp_toff.value():
            self.lbl_tol.setText(self.lbl_tol.text() + " · points after the planned "
                                 "end are not judged")
        else:
            self.lbl_tol.setText("")
        self.canvas.update_data(self.ts, self.vs, self.is_, self.sp_follow.value(), fails)
        if self.ts:
            self.lbl.setText(f"t = {self.ts[-1]:.1f} s · {len(self.ts)} samples · "
                             f"V = {self.vs[-1]:.4g} · I = {self.is_[-1]:.4g} · "
                             f"sequencer: {getattr(self, 'seq_state', '?')}")
        # long logs: redraw less often so the window stays responsive
        if self.timer.isActive():
            cost_ms = (time.perf_counter() - t_start) * 1000
            self.timer.setInterval(int(min(5000, max(250, cost_ms * 4))))

    def report(self):
        if not self.ts:
            QMessageBox.information(self, "Report", "Nothing logged yet."); return
        dlg = ReportInfoDialog(self, "Power supply test report")
        if dlg.exec_() != QDialog.Accepted:
            return
        info = dlg.info()
        info.update({"Power supply": self.idn_text or "–",
                     "Started": getattr(self, "t_start_wall", "–"),
                     "Duration": f"{self.ts[-1]:.3f} s, {len(self.ts)} samples, "
                                 f"interval {self.sp_int.value()} ms",
                     "Planned": self.cb_plan.currentText()})
        off = self.sp_toff.value()
        planned = {}
        for pk, key in (("SV", "V"), ("SC", "I")):
            if self.planned_traces.get(pk):
                tr = [(t + off, v) for t, v in self.planned_traces[pk]]
                if self.planned_end is not None:
                    tr.append((self.planned_end + off, tr[-1][1]))
                planned[key] = tr
        measured = {"V": list(zip(self.ts, self.vs)), "I": list(zip(self.ts, self.is_))}
        if any(not math.isnan(p) for p in self.ps):
            measured["P"] = list(zip(self.ts, self.ps))
        results = {}
        r = self._tol_result()
        if r:
            results[self._tol_key()[1]] = r
            info["Tolerance"] = (f"{self.cb_tolch.currentText()}: ± max({self.sp_tabs.value():g}, "
                                 f"{self.sp_tpct.value():g} %), settle {self.sp_settle.value():g} s, "
                                 f"planned offset {off:g} s")
        save_pdf_report(self, info, planned, measured, results,
                        dlg.ed_notes.toPlainText().strip())

    def clear(self):
        self.ts, self.vs, self.is_, self.ps = [], [], [], []
        self.dirty = True; self._redraw()

    def save(self):
        if not self.ts:
            QMessageBox.information(self, "Save log", "Nothing logged yet."); return
        fn, flt = _save_dialog(self, "Save measurement log",
                               time.strftime("log_%Y%m%d_%H%M%S.csv"),
                               "CSV (*.csv);;Excel (*.xlsx)")
        if not fn: return
        if "xlsx" in flt and not fn.lower().endswith(".xlsx"):
            fn += ".xlsx"
        header = ["Time [s]", "Voltage [V]", "Current [A]", "Power [W]"]
        rows = [[round(t, 4), v, i, p] for t, v, i, p in
                zip(self.ts, self.vs, self.is_, self.ps)]
        try:
            core.write_table_file(fn, header, rows)
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Save failed", str(e))

    def closeEvent(self, ev):
        if self.worker:
            self.worker.stop(); self.worker.wait(3000)
        super().closeEvent(ev)


# ==========================================================================
# Compare view
# ==========================================================================
COMPARE_COLORS = ["#1f6fb2", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e",
                  "#17becf", "#8c564b", "#e377c2"]


class CompareCanvas(InteractiveCanvas):
    def plot(self, sources: list[dict], diff: bool, tol: dict | None = None):
        self.tol_result = None
        self.fig.clear(); self.begin_traces()
        shown = [s for s in sources if s["checked"] and s["signal"] in s["traces"]]
        rows = 2 if diff and len(shown) >= 2 else 1
        axes = self.fig.subplots(rows, 1, sharex=True,
                                 gridspec_kw={"height_ratios": [3, 1.3][:rows]})
        axes = [axes] if rows == 1 else list(axes)
        ax = axes[0]
        for s in shown:
            tr = s["traces"][s["signal"]]
            xs = [t + s["offset"] for t, _ in tr]; ys = [v * s["scale"] for _, v in tr]
            label = f"{s['label']}: {s['signal']}"
            if not ys:
                continue
            if s["kind"] == "sequence":
                xs2, ys2 = xs + [s["end"] + s["offset"]], ys + [ys[-1]]
                ax.step(xs2, ys2, where="post", color=s["color"], lw=1.5, label=label)
                self.add_trace(label, xs2, ys2, core.CHANNEL_UNITS.get(s["signal"], ""))
            else:
                ax.plot(xs, ys, color=s["color"], lw=1.3, marker=".", ms=3, label=label)
                self.add_trace(label, xs, ys, step=False)
        if tol and len(shown) >= 2:
            a, b = shown[0], shown[1]
            ta = [(t, v * a["scale"]) for t, v in a["traces"][a["signal"]]]
            tb = [(t, v * b["scale"]) for t, v in b["traces"][b["signal"]]]
            r = core.tolerance_check(ta, tb, tol["abs"], tol["pct"], tol["settle"],
                                     a["offset"], b["offset"], end_time=a["end"])
            self.tol_result = r
            if r.band:
                ax.fill_between([q[0] for q in r.band], [q[1] for q in r.band],
                                [q[2] for q in r.band], step="post", color="#9ecae1",
                                alpha=0.35, label="Tolerance around A", zorder=0)
            if r.fail_times:
                import bisect
                bx = [t + b["offset"] for t, _ in tb]; by = [v for _, v in tb]
                fy = [by[min(bisect.bisect_left(bx, t), len(by) - 1)] for t in r.fail_times]
                ax.plot(r.fail_times, fy, "x", color="#c62828", ms=5,
                        label="B out of tolerance")
        if shown:
            ax.legend(loc="best", fontsize=8)
        else:
            ax.text(0.5, 0.5, "Add files or the editor / imported sequence on the left",
                    transform=ax.transAxes, ha="center", va="center", color="grey")
        ax.grid(True, alpha=0.3); ax.set_title("Compare")
        if rows == 2:
            a, b = shown[0], shown[1]
            dt = core.difference_trace(
                [(t, v * a["scale"]) for t, v in a["traces"][a["signal"]]],
                [(t, v * b["scale"]) for t, v in b["traces"][b["signal"]]],
                a["offset"], b["offset"], a["kind"] == "sequence", b["kind"] == "sequence")
            xs = [t for t, _ in dt]; ys = [v for _, v in dt]
            axes[1].step(xs, ys, where="post", color="#444", lw=1.2)
            axes[1].set_ylabel("A − B")
            axes[1].axhline(0, color="grey", lw=0.8)
            axes[1].set_ylabel("A − B"); axes[1].grid(True, alpha=0.3)
            self.add_trace("A − B", xs, ys)
            if ys:
                axes[1].set_title(f"A − B: max |Δ| = {max(abs(y) for y in ys):.4g}",
                                  fontsize=9)
        axes[-1].set_xlabel("Time [s]")
        self.finish_plot()


class ComparePanel(QWidget):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.sources: list[dict] = []
        h = QHBoxLayout(self)
        left = QVBoxLayout()
        self.lst = QListWidget()
        self.lst.itemChanged.connect(self._item_changed)
        self.lst.currentRowChanged.connect(self._select)
        left.addWidget(QLabel("Signals (tick to show; first two ticked = A and B)"))
        left.addWidget(self.lst, 1)
        for text, fn in (("Add file…", self.add_file), ("Add editor sequence", self.add_editor),
                         ("Add script / imported", self.add_imported),
                         ("Remove", self.remove)):
            b = QPushButton(text); b.clicked.connect(fn); left.addWidget(b)
        g = QGroupBox("Selected"); f = QFormLayout(g)
        self.cb_sig = QComboBox(); self.cb_sig.currentTextChanged.connect(self._edit)
        self.sp_off = QDoubleSpinBox(); self.sp_off.setRange(-1e6, 1e6); self.sp_off.setDecimals(4)
        self.sp_off.setSuffix(" s"); self.sp_off.valueChanged.connect(self._edit)
        self.sp_off.setKeyboardTracking(False)
        self.sp_scale = QDoubleSpinBox(); self.sp_scale.setRange(-1e6, 1e6)
        self.sp_scale.setDecimals(4); self.sp_scale.setValue(1.0)
        self.sp_scale.valueChanged.connect(self._edit); self.sp_scale.setKeyboardTracking(False)
        f.addRow("Signal", self.cb_sig); f.addRow("Time offset", self.sp_off)
        f.addRow("Scale", self.sp_scale)
        left.addWidget(g)
        self.chk_diff = QCheckBox("Show difference A − B")
        self.chk_diff.toggled.connect(self.replot)
        left.addWidget(self.chk_diff)
        gt = QGroupBox("Tolerance: B against A"); ft = QFormLayout(gt)
        self.chk_tol = QCheckBox("Check"); self.chk_tol.toggled.connect(self.replot)
        self.sp_tabs = QDoubleSpinBox(); self.sp_tabs.setRange(0, 1e6); self.sp_tabs.setDecimals(4)
        self.sp_tabs.setValue(0.5); self.sp_tabs.setPrefix("± ")
        self.sp_tpct = QDoubleSpinBox(); self.sp_tpct.setRange(0, 100); self.sp_tpct.setValue(2)
        self.sp_tpct.setPrefix("± "); self.sp_tpct.setSuffix(" %")
        self.sp_settle = QDoubleSpinBox(); self.sp_settle.setRange(0, 1e4); self.sp_settle.setDecimals(3)
        self.sp_settle.setValue(0.2); self.sp_settle.setSuffix(" s")
        for w in (self.sp_tabs, self.sp_tpct, self.sp_settle):
            w.setKeyboardTracking(False); w.valueChanged.connect(self.replot)
        ft.addRow(self.chk_tol)
        ft.addRow("Absolute", self.sp_tabs); ft.addRow("Relative", self.sp_tpct)
        ft.addRow("Settling time", self.sp_settle)
        self.lbl_tol = QLabel(""); self.lbl_tol.setWordWrap(True); ft.addRow(self.lbl_tol)
        b = QPushButton("PDF report…"); b.clicked.connect(self.report); ft.addRow(b)
        left.addWidget(gt)
        w = QWidget(); w.setLayout(left); w.setMaximumWidth(290)
        h.addWidget(w)
        self.canvas = CompareCanvas()
        h.addWidget(PlotPanel(self.canvas), 1)
        self._busy = False
        self.replot()

    def _add(self, label, traces, end, kind):
        if not traces:
            QMessageBox.warning(self, "Compare", "No signals found."); return
        sig = "SV" if "SV" in traces else next(iter(traces))
        if kind == "sequence":     # prefer the channel that changes
            changing = [k for k, v in traces.items() if len({x for _, x in v}) > 1]
            if changing and sig not in changing:
                sig = changing[0]
        src = {"label": label, "traces": traces, "end": end, "kind": kind,
               "signal": sig, "offset": 0.0, "scale": 1.0, "checked": True,
               "color": COMPARE_COLORS[len(self.sources) % len(COMPARE_COLORS)]}
        self.sources.append(src)
        self._busy = True
        it = QListWidgetItem(label); it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Checked); it.setForeground(QBrush(QColor(src["color"])))
        self.lst.addItem(it)
        self._busy = False
        self.lst.setCurrentRow(len(self.sources) - 1)
        self.canvas.reset_view()
        self.replot()

    def add_file(self):
        fn, _ = _open_dialog(self, "Add file to compare", "",
                             "All supported (*.txt *.seq *.json *.csv *.tsv *.dat *.xlsx);;"
                             "All files (*)")
        if not fn: return
        self.add_path(fn)

    def add_path(self, fn):
        unit = None
        low = fn.lower()
        is_seq = low.endswith(".json")
        if low.endswith((".txt", ".seq")):
            try:
                with open(fn, encoding="utf-8", errors="replace") as fh:
                    is_seq = bool(core.parse_sequence_text(fh.read()).steps)
            except OSError:
                pass
        if not is_seq:
            try:
                first = core.read_table_file(fn)[0][0]
            except (OSError, ValueError, IndexError):
                first = ""
            guess = core.guess_time_unit(first) or "s"
            units = list(core.TIME_UNITS)
            unit, ok = QInputDialog.getItem(self, "Time unit",
                                            f"Time unit of the first column ('{first}'):",
                                            units, units.index(guess), False)
            if not ok: return
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            tr, end, kind = core.load_traces(fn, unit, self.main.sp_simtime.value(),
                                             self.main._parse_inputs())
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Compare", str(e)); return
        finally:
            QApplication.restoreOverrideCursor()
        self._add(os.path.basename(fn), tr, end, kind)

    def add_editor(self):
        cfg = self.main.cfg
        if core.compile_sequence(cfg).errors:
            QMessageBox.warning(self, "Compare", "The editor sequence has errors."); return
        r = core.simulate_settings(cfg, 2 if cfg.repeat == 0 else max(cfg.repeat, 1))
        self._add(f"Editor: {cfg.name}", r.traces, r.end_time, "sequence")

    def add_imported(self):
        m = self.main
        if not m.imported:
            QMessageBox.information(self, "Compare", "Open or apply a sequence script first.")
            return
        r = core.simulate(m.imported, max_time=m.sp_simtime.value(),
                          inputs=m._parse_inputs(), step_time=0.0)
        self._add(f"Script: {m.imported.name}", r.traces, r.end_time, "sequence")

    def remove(self):
        r = self.lst.currentRow()
        if r < 0: return
        del self.sources[r]
        self.lst.takeItem(r)
        self.replot()

    def _item_changed(self, it):
        if self._busy: return
        r = self.lst.row(it)
        if 0 <= r < len(self.sources):
            self.sources[r]["checked"] = it.checkState() == Qt.Checked
            self.replot()

    def _select(self, r):
        if not 0 <= r < len(self.sources): return
        s = self.sources[r]
        self._busy = True
        self.cb_sig.clear(); self.cb_sig.addItems(list(s["traces"]))
        self.cb_sig.setCurrentText(s["signal"])
        self.sp_off.setValue(s["offset"]); self.sp_scale.setValue(s["scale"])
        self._busy = False

    def _edit(self, *_):
        if self._busy: return
        r = self.lst.currentRow()
        if not 0 <= r < len(self.sources): return
        s = self.sources[r]
        s["signal"] = self.cb_sig.currentText() or s["signal"]
        s["offset"] = self.sp_off.value(); s["scale"] = self.sp_scale.value()
        self.replot()

    def _tol(self):
        if not self.chk_tol.isChecked():
            return None
        return {"abs": self.sp_tabs.value(), "pct": self.sp_tpct.value(),
                "settle": self.sp_settle.value()}

    def replot(self, *_):
        self.canvas.plot(self.sources, self.chk_diff.isChecked(), self._tol())
        r = self.canvas.tol_result
        if r:
            self.lbl_tol.setText(f"<b>{'PASS' if r.passed else 'FAIL'}"
                                 f"</b> – {r.n_fail} of {r.n_checked} points outside, "
                                 f"max |dev| {r.max_dev:.4g}, RMS {r.rms_dev:.4g}")
        elif self.chk_tol.isChecked():
            self.lbl_tol.setText("Tick at least two signals (A = first, B = second).")
        else:
            self.lbl_tol.setText("")

    def report(self):
        shown = [s for s in self.sources if s["checked"] and s["signal"] in s["traces"]]
        if len(shown) < 2:
            QMessageBox.information(self, "Report", "Tick two signals: A (planned) and "
                                    "B (measured)."); return
        dlg = ReportInfoDialog(self, "Comparison report")
        if dlg.exec_() != QDialog.Accepted:
            return
        a, b = shown[0], shown[1]
        key = b["signal"]
        planned = {key: [(t + a["offset"], v * a["scale"]) for t, v in a["traces"][a["signal"]]]
                   + [(a["end"] + a["offset"],
                       a["traces"][a["signal"]][-1][1] * a["scale"])]}
        measured = {key: [(t + b["offset"], v * b["scale"]) for t, v in b["traces"][b["signal"]]]}
        info = dlg.info()
        info.update({"A (planned)": f"{a['label']}: {a['signal']}",
                     "B (measured)": f"{b['label']}: {b['signal']}"})
        results = {}
        self.replot()
        if self.canvas.tol_result:
            results[key] = self.canvas.tol_result
            info["Tolerance"] = (f"± max({self.sp_tabs.value():g}, {self.sp_tpct.value():g} %), "
                                 f"settle {self.sp_settle.value():g} s")
        save_pdf_report(self, info, planned, measured, results,
                        dlg.ed_notes.toPlainText().strip())


# ==========================================================================
# Direct (manual) control of the supply
# ==========================================================================
CONTROL_LABELS = {
    "set_v": "Set voltage ({v} = value)", "set_i": "Set current ({v} = value)",
    "get_v": "Read set voltage", "get_i": "Read set current",
    "out_on": "Output ON", "out_off": "Output OFF", "get_out": "Read output state",
    "remote": "Take remote control (; separates)",
    "seq_source": "Hand control to sequencer",
    "get_source": "Read control sources",
}


def control_cmds() -> dict:
    s = settings()
    return {k: s.value(f"cmd/{k}", v, type=str) for k, v in core.DEFAULT_CONTROL_CMDS.items()}


class ControlWorker(QThread):
    """Keeps one connection open: sends queued commands and polls readings."""
    status = pyqtSignal(object)
    idn = pyqtSignal(str)
    failed = pyqtSignal(str)
    done = pyqtSignal(str)

    def __init__(self, params, queries, cmds, interval, take_remote):
        super().__init__()
        import threading
        self.params, self.queries, self.cmds = params, queries, cmds
        self.interval, self.take_remote = interval, take_remote
        self._jobs: list = []
        self._lock = threading.Lock()
        self._stop = False

    def post(self, func, message):
        with self._lock:
            self._jobs.append((func, message))

    def stop(self):
        self._stop = True

    def run(self):
        try:
            with GuiPsuConnection(**self.params) as con:
                ACTIVE_CONNECTIONS[id(self)] = "Direct control"
                try:
                    self.idn.emit(core.identify(con))
                except core.PsuError:
                    self.idn.emit("(no reply to *IDN?)")
                if self.take_remote:
                    core.take_remote_control(con, self.cmds)
                    self.done.emit("Remote control requested (CV/CC via Ethernet).")
                next_poll = 0.0
                while not self._stop:
                    with self._lock:
                        jobs, self._jobs = self._jobs, []
                    for func, message in jobs:
                        try:
                            func(con)
                            self.done.emit(message)
                        except ValueError as e:
                            self.done.emit(f"Not sent: {e}")
                    now = time.monotonic()
                    if jobs or now >= next_poll:
                        self.status.emit(core.read_status(con, self.queries, self.cmds))
                        next_poll = now + self.interval
                    time.sleep(0.03)
        except core.PsuError as e:
            self.failed.emit(str(e))
        finally:
            ACTIVE_CONNECTIONS.pop(id(self), None)


class DirectControlDialog(QWidget):
    """Set voltage / current and switch the output by hand, with live readings."""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.worker = None
        self.last = {}
        self.setWindowTitle("Direct control")
        self.resize(560, 560)
        v = QVBoxLayout(self)

        # --- connection
        top = QHBoxLayout()
        self.lbl_conn = QLabel()
        self.b_connect = QPushButton("Connect"); self.b_connect.clicked.connect(self.connect_psu)
        set_role(self.b_connect, "primary")
        self.b_disc = QPushButton("Disconnect"); self.b_disc.clicked.connect(self.disconnect_psu)
        self.b_disc.setEnabled(False)
        top.addWidget(self.lbl_conn, 1); top.addWidget(self.b_connect); top.addWidget(self.b_disc)
        v.addLayout(top)
        self.lbl_idn = QLabel("Not connected."); self.lbl_idn.setWordWrap(True)
        v.addWidget(self.lbl_idn)

        # --- readings
        gr = QGroupBox("Readings"); grl = QHBoxLayout(gr)
        big = QFont(); big.setPointSize(18); big.setBold(True)
        self.val = {}
        for key, title in (("V", "Voltage"), ("I", "Current"), ("P", "Power")):
            box = QVBoxLayout()
            t = QLabel(title); t.setAlignment(Qt.AlignCenter)
            lab = QLabel("–"); lab.setFont(big); lab.setAlignment(Qt.AlignCenter)
            lab.setObjectName("reading")
            lab.setMinimumWidth(130)
            box.addWidget(t); box.addWidget(lab); grl.addLayout(box)
            self.val[key] = lab
        v.addWidget(gr)
        self.lbl_set = QLabel("Programmed: –"); v.addWidget(self.lbl_set)

        # --- set values
        gs = QGroupBox("Set values"); fs = QFormLayout(gs)
        self.sp_v = QDoubleSpinBox(); self.sp_v.setDecimals(3); self.sp_v.setSuffix(" V")
        self.sp_i = QDoubleSpinBox(); self.sp_i.setDecimals(3); self.sp_i.setSuffix(" A")
        for sp in (self.sp_v, self.sp_i):
            sp.setKeyboardTracking(False); sp.setMinimumWidth(130)
        b_v = QPushButton("Set voltage"); b_v.clicked.connect(lambda: self.apply(True, False))
        b_i = QPushButton("Set current"); b_i.clicked.connect(lambda: self.apply(False, True))
        fs.addRow("Voltage", self._row(self.sp_v, b_v))
        fs.addRow("Current limit", self._row(self.sp_i, b_i))
        self.b_both = QPushButton("Set both  (Enter)")
        set_role(self.b_both, "primary")
        self.b_both.clicked.connect(lambda: self.apply(True, True))
        self.b_both.setDefault(True)
        fs.addRow(self.b_both)
        self.lbl_lim = QLabel(); self.lbl_lim.setObjectName("hint")
        fs.addRow(self.lbl_lim)
        v.addWidget(gs)

        # --- output
        go = QGroupBox("Output"); gol = QHBoxLayout(go)
        self.lbl_out = QLabel(); self.lbl_out.setObjectName("statePill")
        self.lbl_out.setAlignment(Qt.AlignCenter)
        set_state(self.lbl_out, "idle", "Output: –")
        self.b_on = QPushButton("Output ON"); self.b_on.clicked.connect(lambda: self.output(True))
        set_role(self.b_on, "go")
        self.b_off = QPushButton("Output OFF"); self.b_off.clicked.connect(lambda: self.output(False))
        set_role(self.b_off, "danger")
        self.b_off.setAutoDefault(False); self.b_on.setAutoDefault(False)
        gol.addWidget(self.lbl_out, 1); gol.addWidget(self.b_on); gol.addWidget(self.b_off)
        v.addWidget(go)

        # --- options
        opt = QHBoxLayout()
        self.chk_remote = QCheckBox("Take remote control when connecting")
        self.chk_remote.setChecked(settings().value("direct/remote", True, type=bool))
        self.chk_remote.setToolTip("Sends the 'take remote control' commands (default "
                                   "SYST:REM:CV REM; SYST:REM:CC REM) so the voltage and "
                                   "current are set via Ethernet instead of the front panel.")
        self.sp_poll = QSpinBox(); self.sp_poll.setRange(100, 10000); self.sp_poll.setValue(500)
        self.sp_poll.setSuffix(" ms")
        opt.addWidget(self.chk_remote); opt.addStretch()
        opt.addWidget(QLabel("Update every")); opt.addWidget(self.sp_poll)
        v.addLayout(opt)
        b_seq = QPushButton("Hand control back to sequencer")
        b_seq.setAutoDefault(False)
        b_seq.setToolTip("Lets a running sequence drive voltage/current again")
        b_seq.clicked.connect(self.to_sequencer)
        opt2 = QHBoxLayout(); opt2.addWidget(b_seq); opt2.addStretch(); v.addLayout(opt2)
        self.lbl_msg = QLabel("Closing this window does not switch the output off. "
                              "Taking remote control moves voltage/current control "
                              "from the sequencer to Ethernet.")
        self.lbl_msg.setWordWrap(True); self.lbl_msg.setObjectName("hint")
        v.addWidget(self.lbl_msg)
        v.addStretch()
        for b in (b_v, b_i):
            b.setAutoDefault(False)
        self.b_connect.setAutoDefault(False); self.b_disc.setAutoDefault(False)
        for sp in (self.sp_v, self.sp_i):            # Enter in a value box = Set both
            sp.lineEdit().returnPressed.connect(lambda: self.apply(True, True))
        self._set_enabled(False)
        self.refresh_limits()

    @staticmethod
    def _row(*ws):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in ws: h.addWidget(x)
        return w

    def refresh_limits(self):
        c = self.main.cfg
        self.sp_v.setRange(0, c.vmax); self.sp_i.setRange(0, c.cmax)
        p = conn_params()
        self.lbl_conn.setText(f"Supply <b>{p['host']}:{p['port']}</b>")
        self.lbl_lim.setText(f"Limits from the selected device ({c.device}): "
                             f"{c.vmax:g} V, {c.cmax:g} A, {c.pmax:g} W")

    def _set_enabled(self, on):
        for w in (self.sp_v, self.sp_i, self.b_both, self.b_on, self.b_off):
            w.setEnabled(on)
        for b in self.findChildren(QPushButton):
            if b.text() in ("Set voltage", "Set current"):
                b.setEnabled(on)
        self.b_connect.setEnabled(not on and self.worker is None)
        self.b_disc.setEnabled(self.worker is not None)

    # ---- connection
    def connect_psu(self):
        if self.worker:
            return
        self.refresh_limits()
        settings().setValue("direct/remote", self.chk_remote.isChecked())
        self.worker = ControlWorker(conn_params(), conn_queries(), control_cmds(),
                                    self.sp_poll.value() / 1000.0,
                                    self.chk_remote.isChecked())
        self.worker.status.connect(self._on_status)
        self.worker.idn.connect(lambda s: self.lbl_idn.setText(f"Connected: {s}"))
        self.worker.done.connect(lambda m: self.lbl_msg.setText(m))
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self._on_finished)
        self._first_status = True
        self.lbl_idn.setText("Connecting…")
        self.worker.start()
        self.b_connect.setEnabled(False); self.b_disc.setEnabled(True)

    def disconnect_psu(self):
        if self.worker:
            self.worker.stop()

    def _on_failed(self, msg):
        QMessageBox.critical(self, "Direct control", msg)

    def _on_finished(self):
        self.worker = None
        self.lbl_idn.setText("Not connected.")
        self._set_enabled(False)

    def _on_status(self, st):
        self.last = st
        self._set_enabled(True)
        units = {"V": "V", "I": "A", "P": "W"}
        for k, lab in self.val.items():
            x = st.get(k)
            lab.setText("–" if x is None else f"{x:.4g} {units[k]}")
        sv, si = st.get("set_V"), st.get("set_I")
        seq = st.get("sequencer")
        self.lbl_set.setText(
            f"Programmed: {'–' if sv is None else f'{sv:g} V'}, "
            f"{'–' if si is None else f'{si:g} A'}"
            + (f" · sequencer: {seq}" if seq else ""))
        out = st.get("output")
        set_state(self.lbl_out, "busy" if out else "idle",
                  "⚡ Output ON" if out else "Output OFF" if out is False else "Output: ?")
        if self._first_status:            # start from what the supply has now
            self._first_status = False
            if seq and "RUN" in str(seq).upper() and self.chk_remote.isChecked():
                self.lbl_msg.setText("Note: a sequence is running. Remote control was "
                                     "taken, so it no longer drives the output – use "
                                     "'Hand control back to sequencer'.")
            if sv is not None:
                self.sp_v.setValue(min(sv, self.sp_v.maximum()))
            if si is not None:
                self.sp_i.setValue(min(si, self.sp_i.maximum()))

    # ---- actions
    def _sequencer_running(self) -> bool:
        return "RUN" in str(self.last.get("sequencer") or "").upper()

    def apply(self, volt: bool, curr: bool):
        if not self.worker:
            return
        c = self.main.cfg
        vv = self.sp_v.value() if volt else None
        ii = self.sp_i.value() if curr else None
        if vv is not None and vv > c.vmax or ii is not None and ii > c.cmax:
            QMessageBox.warning(self, "Direct control", "Value above the device limit.")
            return
        if vv is not None and ii is not None and vv * ii > c.pmax * 1.0001:
            self.lbl_msg.setText(f"Note: {vv:g} V × {ii:g} A = {vv * ii:g} W is above "
                                 f"{c.pmax:g} W – the supply will limit power.")
        if vv is not None and not confirm_high_voltage(self, vv):
            return
        if self._sequencer_running() and QMessageBox.question(
                self, "Direct control", "A sequence is running and may overwrite manual "
                "values. Send anyway?") != QMessageBox.Yes:
            return
        cmds = control_cmds()
        what = " and ".join(x for x in (f"{vv:g} V" if vv is not None else "",
                                        f"{ii:g} A" if ii is not None else "") if x)
        self.worker.post(lambda con: core.set_setpoints(con, vv, ii, cmds), f"Set {what}.")

    def to_sequencer(self):
        if not self.worker:
            QMessageBox.information(self, "Direct control", "Connect first."); return
        cmds = control_cmds()
        self.worker.post(lambda con: [con.write(x) for x in core._split_cmds(cmds["seq_source"])],
                         "Control handed to the sequencer.")

    def output(self, on: bool):
        if not self.worker:
            return
        if on:
            sv = self.last.get("set_V")
            if sv is not None and not confirm_high_voltage(self, sv):
                return
            text = (f"Switch the output ON?\n\nProgrammed: "
                    f"{'?' if sv is None else f'{sv:g} V'}, "
                    f"{'?' if self.last.get('set_I') is None else str(self.last.get('set_I')) + ' A'}")
            if QMessageBox.question(self, "Output ON", text) != QMessageBox.Yes:
                return
        cmds = control_cmds()
        self.worker.post(lambda con: core.set_output(con, on, cmds),
                         "Output switched ON." if on else "Output switched OFF.")

    def showEvent(self, ev):
        self.refresh_limits()
        super().showEvent(ev)

    def closeEvent(self, ev):
        if self.worker:
            self.worker.stop(); self.worker.wait(3000)
        super().closeEvent(ev)

    def stop(self):
        if self.worker:
            self.worker.stop(); self.worker.wait(3000)


class DiagnoseDialog(QDialog):
    """Ask the supply why a sequence does not drive the output."""

    def __init__(self, main, name):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("Diagnose sequence")
        self.resize(820, 480)
        v = QVBoxLayout(self)
        p = conn_params()
        top = QHBoxLayout()
        top.addWidget(QLabel(f"Supply <b>{p['host']}:{p['port']}</b> · Sequence name"))
        self.ed_name = QLineEdit(name); self.ed_name.setMaximumWidth(180)
        top.addWidget(self.ed_name)
        b = QPushButton("Check"); b.clicked.connect(self.check); b.setDefault(True)
        top.addWidget(b); top.addStretch()
        v.addLayout(top)
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["Check", "Value", "Result", "What to do"])
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.Stretch)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setWordWrap(True)
        v.addWidget(self.tbl, 1)
        row = QHBoxLayout()
        for text, fn in (("Hand control to sequencer", self.to_sequencer),
                         ("Output ON", self.output_on),
                         ("Run sequence", self.run_seq),
                         ("Stop sequence", self.stop_seq)):
            b = QPushButton(text); b.clicked.connect(fn); b.setAutoDefault(False)
            row.addWidget(b)
        row.addStretch()
        v.addLayout(row)
        self.lbl = QLabel("Click Check to ask the supply."); self.lbl.setWordWrap(True)
        v.addWidget(self.lbl)

    def _name(self):
        return self.ed_name.text().strip()

    def _with_conn(self, func):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                return func(con)
        except core.PsuError as e:
            self.lbl.setText(f"<b>Error:</b> {e}")
            return None
        finally:
            QApplication.restoreOverrideCursor()

    def check(self):
        items = self._with_conn(lambda con: core.diagnose(con, self._name(), control_cmds(),
                                                          conn_queries()))
        if items is None:
            return
        self.tbl.setRowCount(len(items))
        bold = QFont(); bold.setBold(True)
        for r, it in enumerate(items):
            res = {True: "OK", False: "PROBLEM", None: "–"}[it["ok"]]
            for col, text in enumerate((it["check"], str(it["value"]), res, it["hint"])):
                cell = QTableWidgetItem(text)
                if col == 2 and it["ok"] is False:
                    cell.setFont(bold)
                self.tbl.setItem(r, col, cell)
        self.tbl.resizeRowsToContents()
        bad = [it["check"] for it in items if it["ok"] is False]
        self.lbl.setText("No problems found." if not bad else
                         "<b>Problems:</b> " + ", ".join(bad) + ". Fix them from the top "
                         "down, then click Check again.")

    def to_sequencer(self):
        cmds = control_cmds()
        if self._with_conn(lambda con: [con.write(x) for x in
                                        core._split_cmds(cmds["seq_source"])]) is not None:
            self.check()

    def output_on(self):
        if QMessageBox.question(self, "Output ON", "Switch the output ON now?") \
                != QMessageBox.Yes:
            return
        if self._with_conn(lambda con: core.set_output(con, True, control_cmds())) is not None:
            self.check()

    def run_seq(self):
        res = self._with_conn(lambda con: core.run_sequence(con, self._name(),
                                                            control_cmds()))
        if res is not None:
            self.check()

    def stop_seq(self):
        self._with_conn(lambda con: con.write("PROG:SEL:STA STOP"))
        self.check()


def report_run_result(parent, name, res) -> None:
    """Tell the user whether a started sequence is really running."""
    if res["running"] and not res["errors"]:
        parent.statusBar().showMessage(f"Sequence '{name}' is running.", 6000) \
            if hasattr(parent, "statusBar") else None
        return
    msg = (f"Sequence '{name}' state after RUN: {res['state'] or '(no reply)'}")
    if res["errors"]:
        msg += "\n\nThe supply reported:\n" + "\n".join(res["errors"])
    msg += ("\n\nOpen Device → Diagnose sequence to see what is missing "
            "(output, control source, power limit, errors).")
    QMessageBox.warning(parent, "Sequence not running", msg)


# ==========================================================================
# Connection panel (left dock): IP / port, connect, status and details
# ==========================================================================
class PingWorker(QThread):
    """Checks the connection once (connect + *IDN?) without freezing the window."""
    result = pyqtSignal(bool, str, float)

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        t0 = time.perf_counter()
        try:
            with GuiPsuConnection(**self.params) as con:
                idn = core.identify(con)
            self.result.emit(True, idn, (time.perf_counter() - t0) * 1000)
        except core.PsuError as e:
            self.result.emit(False, str(e), (time.perf_counter() - t0) * 1000)


class ConnectionPanel(QWidget):
    CHECK_EVERY_MS = 5000

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.worker = None
        self.want_connected = False
        self.connected = False
        self.model_match = None
        v = QVBoxLayout(self)

        g = QGroupBox("Power supply"); f = QFormLayout(g)
        p = conn_params()
        self.ed_host = QLineEdit(p["host"])
        self.ed_host.setPlaceholderText("e.g. 192.168.0.100")
        self.sp_port = QSpinBox(); self.sp_port.setRange(1, 65535); self.sp_port.setValue(p["port"])
        self.sp_port.setToolTip("Delta Elektronika supplies use port 8462")
        f.addRow("IP address", self.ed_host)
        f.addRow("Port", self.sp_port)
        row = QHBoxLayout()
        self.b_connect = QPushButton("Connect"); self.b_connect.clicked.connect(self.connect_psu)
        set_role(self.b_connect, "primary")
        self.b_disc = QPushButton("Disconnect"); self.b_disc.clicked.connect(self.disconnect_psu)
        self.b_disc.setEnabled(False)
        row.addWidget(self.b_connect); row.addWidget(self.b_disc)
        f.addRow(row)
        v.addWidget(g)

        gs = QGroupBox("Status"); fs = QVBoxLayout(gs)
        self.lbl_state = QLabel(); self.lbl_state.setObjectName("statePill")
        self.lbl_state.setAlignment(Qt.AlignCenter)
        set_state(self.lbl_state, "idle", "○  Not connected")
        self.lbl_detail = QLabel("Enter the IP address and port, then click Connect.")
        self.lbl_detail.setWordWrap(True)
        self.lbl_detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.b_use_model = QPushButton(); self.b_use_model.setVisible(False)
        self.b_use_model.clicked.connect(self.use_detected_model)
        self.chk_keep = QCheckBox("Check the connection every 5 s")
        self.chk_keep.setChecked(settings().value("conn/keep_checking", True, type=bool))
        self.chk_keep.toggled.connect(self._keep_toggled)
        fs.addWidget(self.lbl_state); fs.addWidget(self.lbl_detail)
        fs.addWidget(self.b_use_model); fs.addWidget(self.chk_keep)
        v.addWidget(gs)

        ga = QGroupBox("Quick actions"); ga_l = QVBoxLayout(ga)
        grid = [("Direct control", main.direct_control), ("Live monitor", main.live_monitor),
                ("Run sequences…", main.run_list), ("Stop sequence", main.stop_on_psu),
                ("Output OFF", main.output_off), ("Diagnose…", main.diagnose),
                ("Read back…", main.read_back), ("More settings…", main.connection_settings)]
        for i in range(0, len(grid), 2):
            r = QHBoxLayout()
            for text, fn in grid[i:i + 2]:
                b = QPushButton(text); b.clicked.connect(fn); r.addWidget(b)
                if text in ("Stop sequence", "Output OFF"):
                    set_role(b, "danger")
                elif text == "Run sequences…":
                    set_role(b, "go")
            ga_l.addLayout(r)
        v.addWidget(ga)
        v.addStretch()

        self.timer = QTimer(self); self.timer.timeout.connect(self._timer_check)
        self.ed_host.editingFinished.connect(self._fields_changed)
        self.sp_port.valueChanged.connect(self._fields_changed)

    # ---- settings sync
    def reload(self):
        p = conn_params()
        self.ed_host.blockSignals(True); self.sp_port.blockSignals(True)
        self.ed_host.setText(p["host"]); self.sp_port.setValue(p["port"])
        self.ed_host.blockSignals(False); self.sp_port.blockSignals(False)

    def _store(self):
        settings().setValue("conn/host", self.ed_host.text().strip())
        settings().setValue("conn/port", self.sp_port.value())

    def _fields_changed(self, *_):
        old = conn_params()
        if old["host"] == self.ed_host.text().strip() and old["port"] == self.sp_port.value():
            return
        self._store()
        self.main._update_supply_label()
        if self.want_connected:
            self.check_now()

    # ---- connect / check
    def connect_psu(self):
        if not self.ed_host.text().strip():
            set_state(self.lbl_state, "bad", "✕  No IP address")
            self.lbl_detail.setText("Type the supply's IP address first."); return
        self._store()
        self.want_connected = True
        self.b_connect.setEnabled(False); self.b_disc.setEnabled(True)
        set_state(self.lbl_state, "busy", "…  Connecting")
        self.lbl_detail.setText(f"Trying {self.ed_host.text().strip()}:{self.sp_port.value()} …")
        self.check_now()
        if self.chk_keep.isChecked():
            self.timer.start(self.CHECK_EVERY_MS)

    def disconnect_psu(self):
        self.want_connected = False
        self.timer.stop()
        self.connected = False
        self.b_connect.setEnabled(True); self.b_disc.setEnabled(False)
        set_state(self.lbl_state, "idle", "○  Disconnected")
        self.lbl_detail.setText("The app does not keep a connection open; each action "
                                "connects on its own. Click Connect to check again.")
        self.b_use_model.setVisible(False)
        self.main._update_supply_label()

    def _keep_toggled(self, on):
        settings().setValue("conn/keep_checking", on)
        if on and self.want_connected:
            self.timer.start(self.CHECK_EVERY_MS)
        else:
            self.timer.stop()

    def _timer_check(self):
        users = active_users()
        if users:                               # don't open an extra connection
            set_state(self.lbl_state, "ok" if self.connected else "busy",
                      "✓  Connected – in use" if self.connected else "…  In use")
            self.lbl_detail.setText(
                f"<b>{', '.join(users)}</b> is talking to the supply, so the automatic "
                f"check is paused (some supplies accept only one connection).<br>"
                f"<b>Address:</b> {conn_params()['host']}:{conn_params()['port']}")
            return
        self.check_now()

    def check_now(self):
        if self.worker is not None:            # previous check still running
            return
        self.worker = PingWorker(conn_params())
        self.worker.result.connect(self._on_result)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()

    def _on_finished(self):
        self.worker = None

    def _on_result(self, ok, text, ms):
        if not self.want_connected:
            return
        p = conn_params()
        stamp = time.strftime("%H:%M:%S")
        self.connected = ok
        if ok:
            info = core.parse_idn(text)
            set_state(self.lbl_state, "ok", "✓  Connected")
            lines = [f"<b>Address:</b> {p['host']}:{p['port']}",
                     f"<b>Model:</b> {info['model'] or '?'}"]
            if info["serial"]:
                lines.append(f"<b>Serial:</b> {info['serial']}")
            if info["firmware"]:
                lines.append(f"<b>Firmware:</b> {info['firmware']}")
            lines.append(f"<b>Response:</b> {ms:.0f} ms · checked {stamp}")
            self.lbl_detail.setText("<br>".join(lines))
            match = core.match_device(info["model"])
            self.model_match = match
            if match and match != self.main.cfg.device:
                self.b_use_model.setText(f"Use limits of {match}")
                self.b_use_model.setVisible(True)
            else:
                self.b_use_model.setVisible(False)
        else:
            set_state(self.lbl_state, "bad", "✕  Connection failed")
            self.lbl_detail.setText(
                f"<b>Address:</b> {p['host']}:{p['port']}<br><b>Reason:</b> {text}<br>"
                f"<b>Checked:</b> {stamp}<br><br>Check: the IP address and port (Delta "
                f"uses 8462), the network cable, that this PC is in the same network, "
                f"and that no firewall blocks the port.")
            self.b_use_model.setVisible(False)
        self.main._update_supply_label()

    def use_detected_model(self):
        if self.model_match:
            self.main.cb_device.setCurrentText(self.model_match)
            self.b_use_model.setVisible(False)

    def stop(self):
        self.timer.stop()
        if self.worker is not None:
            self.worker.wait(3000)


# ==========================================================================
# Run sequences: run one or more sequence files one after another
# ==========================================================================
class RunListWorker(QThread):
    event = pyqtSignal(str, int, str)

    def __init__(self, items, opts):
        super().__init__()
        self.items, self.opts = items, opts
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        o = self.opts
        try:
            with GuiPsuConnection(**conn_params()) as con:
                ACTIVE_CONNECTIONS[id(self)] = "Run sequences"
                try:
                    if o["output_on"]:
                        core.set_output(con, True, control_cmds())
                        self.event.emit("info", -1, "Output switched ON.")
                    core.execute_run_list(
                        con, self.items, upload=o["upload"], verify=o["verify"],
                        cmds=control_cmds(), pause=o["pause"], loop=o["loop"],
                        stop_on_error=o["stop_on_error"], should_stop=lambda: self._stop,
                        on_event=lambda k, i, m: self.event.emit(k, i, m))
                finally:
                    if o["output_off"]:
                        try:
                            core.set_output(con, False, control_cmds())
                            self.event.emit("info", -1, "Output switched OFF.")
                        except core.PsuError:
                            pass
        except (core.PsuError, ValueError, OSError) as e:
            self.event.emit("failed", -1, str(e))
        finally:
            ACTIVE_CONNECTIONS.pop(id(self), None)


class RunListPanel(QWidget):
    COLS = ["File", "Name on supply", "Steps", "Duration", "Repeat", "Max time [s]",
            "Notes", "Status"]

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.items: list[core.RunItem] = []
        self.worker = None
        self.running_rows: list[int] = []
        v = QVBoxLayout(self)

        bar = FlowLayout()
        for text, fn, tip in (
                ("Add .txt files…", self.add_files, "Add one or more sequence files"),
                ("Add editor sequence", self.add_editor, "Add the sequence from the Signal window"),
                ("Add script", self.add_script, "Add the sequence from the Script editor"),
                ("Remove", self.remove, "Remove the selected rows"),
                ("↑", lambda: self.move(-1), "Move up"),
                ("↓", lambda: self.move(1), "Move down"),
                ("Clear", self.clear_list, "Remove all rows")):
            b = QPushButton(text); b.clicked.connect(fn); b.setToolTip(tip); bar.addWidget(b)
        for text, fn in (("Open list…", self.open_list), ("Save list…", self.save_list)):
            b = QPushButton(text); b.clicked.connect(fn); bar.addWidget(b)
        v.addLayout(bar)

        self.tbl = QTableWidget(0, len(self.COLS))
        self.tbl.setHorizontalHeaderLabels(self.COLS)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.ExtendedSelection)
        hh = self.tbl.horizontalHeader()
        for col in range(len(self.COLS)):
            hh.setSectionResizeMode(col, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(6, QHeaderView.Stretch)
        self.tbl.itemChanged.connect(self._item_changed)
        self.tbl.setToolTip("Select one row to run a single sequence, or several "
                            "(Ctrl/Shift+click) to run them in this order.")
        v.addWidget(self.tbl, 1)

        g = QGroupBox("Options"); gl = QHBoxLayout(g)
        col1 = QVBoxLayout(); col2 = QVBoxLayout()
        s = settings()
        self.chk_upload = QCheckBox("Upload each file before running")
        self.chk_upload.setChecked(s.value("runlist/upload", True, type=bool))
        self.chk_verify = QCheckBox("Verify the upload")
        self.chk_verify.setChecked(s.value("runlist/verify", False, type=bool))
        self.chk_on = QCheckBox("Switch output ON at the start")
        self.chk_off = QCheckBox("Output OFF when finished or stopped")
        self.chk_off.setChecked(s.value("runlist/off", True, type=bool))
        self.chk_loop = QCheckBox("Loop the list (until Stop)")
        self.chk_stoperr = QCheckBox("Stop the list at the first error")
        self.chk_stoperr.setChecked(s.value("runlist/stoperr", True, type=bool))
        self.sp_pause = QDoubleSpinBox(); self.sp_pause.setRange(0, 3600); self.sp_pause.setSuffix(" s")
        for w in (self.chk_upload, self.chk_verify, self.chk_on):
            col1.addWidget(w)
        for w in (self.chk_off, self.chk_loop, self.chk_stoperr):
            col2.addWidget(w)
        prow = QHBoxLayout(); prow.addWidget(QLabel("Pause between files")); prow.addWidget(self.sp_pause)
        col1.addLayout(prow)
        gl.addLayout(col1); gl.addLayout(col2); gl.addStretch()
        v.addWidget(g)

        run = QHBoxLayout()
        self.b_sel = QPushButton("▶ Run selected"); self.b_sel.clicked.connect(self.run_selected)
        set_role(self.b_sel, "go")
        self.b_all = QPushButton("▶ Run all"); self.b_all.clicked.connect(self.run_all)
        set_role(self.b_all, "go")
        self.b_stop = QPushButton("■ Stop"); self.b_stop.clicked.connect(self.stop)
        set_role(self.b_stop, "danger")
        self.b_stop.setEnabled(False)
        for b in (self.b_sel, self.b_all, self.b_stop):
            run.addWidget(b)
        run.addStretch()
        v.addLayout(run)
        self.lbl = QLabel("Add sequence files, select one or more rows, then Run.")
        self.lbl.setWordWrap(True)
        v.addWidget(self.lbl)

    # ---------------------------------------------------------------- list
    def _fmt_dur(self, it):
        if it.duration is None:
            return "endless / unknown"
        return f"{it.duration:.3g} s" if it.duration < 120 else f"{it.duration / 60:.3g} min"

    def _add_item(self, it: core.RunItem):
        self.items.append(it)
        r = self.tbl.rowCount()
        self.tbl.blockSignals(True)
        self.tbl.insertRow(r)
        self._fill_row(r)
        self.tbl.blockSignals(False)

    def _fill_row(self, r):
        it = self.items[r]
        ro = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        vals = [it.label, it.name, str(len(it.seq.steps)), self._fmt_dur(it), None, None,
                "; ".join(it.notes), "–"]
        for col, val in enumerate(vals):
            if val is None:
                continue
            cell = QTableWidgetItem(val)
            if col != 1:
                cell.setFlags(ro)
            if col == 0 and it.path:
                cell.setToolTip(it.path)
            self.tbl.setItem(r, col, cell)
        rep = QSpinBox(); rep.setRange(1, 10000); rep.setValue(int(it.repeat)); rep.setSuffix(" ×")
        rep.valueChanged.connect(lambda val, item=it: setattr(item, "repeat", val))
        mt = QDoubleSpinBox(); mt.setRange(0, 1e7); mt.setDecimals(1); mt.setValue(it.max_time)
        mt.setSpecialValueText("until it stops")
        mt.valueChanged.connect(lambda val, item=it: setattr(item, "max_time", val))
        self.tbl.setCellWidget(r, 4, rep)
        self.tbl.setCellWidget(r, 5, mt)

    def _rebuild(self):
        self.tbl.blockSignals(True)
        self.tbl.setRowCount(0)
        for r in range(len(self.items)):
            self.tbl.insertRow(r); self._fill_row(r)
        self.tbl.blockSignals(False)

    def _item_changed(self, cell):
        if cell.column() != 1:
            return
        r = cell.row()
        name = cell.text().strip()
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,15}", name):
            self.items[r].name = name
        else:
            QMessageBox.warning(self, "Name", "The name must start with a letter and have "
                                "at most 16 letters, digits or _.")
            self.tbl.blockSignals(True); cell.setText(self.items[r].name)
            self.tbl.blockSignals(False)

    def add_files(self):
        fns, _ = QFileDialog.getOpenFileNames(self, "Add sequence files", _last_dir(),
                                              "Sequence text (*.txt *.seq);;All files (*)")
        if fns:
            _remember_dir(fns[0])
        self.add_paths(fns)

    def add_paths(self, fns):
        bad = []
        for fn in fns:
            try:
                self._add_item(core.load_run_item(fn, self.main.cfg.device))
            except (OSError, ValueError) as e:
                bad.append(f"{os.path.basename(fn)}: {e}")
        if bad:
            QMessageBox.warning(self, "Add files", "Not added:\n" + "\n".join(bad))
        self._summary()

    def _item_from_text(self, label, name, text):
        seq = core.parse_sequence_text(text)
        it = core.RunItem(label=label, name=core._safe_name(name), seq=seq)
        core.estimate_run_item(it, self.main.cfg.device)
        return it

    def add_editor(self):
        m = self.main
        comp = core.compile_sequence(m.cfg)
        if comp.errors:
            QMessageBox.warning(self, "Run sequences", "The editor sequence has errors:\n"
                                + "\n".join(comp.errors)); return
        self._add_item(self._item_from_text(f"Editor: {m.cfg.name}", m.cfg.name,
                                            core.to_text(m.cfg, comp, "steps")))
        self._summary()

    def add_script(self):
        m = self.main
        text = m.txt_import.toPlainText()
        if not text.strip():
            QMessageBox.information(self, "Run sequences", "The Script editor is empty."); return
        seq = core.parse_sequence_text(text)
        if not seq.steps:
            QMessageBox.warning(self, "Run sequences", "No steps found in the script."); return
        label = os.path.basename(m.imported_file) if m.imported_file else "script"
        self._add_item(self._item_from_text(f"Script: {label}", seq.name, text))
        self._summary()

    def _selected_rows(self):
        return sorted({i.row() for i in self.tbl.selectionModel().selectedRows()})

    def remove(self):
        if self.worker: return
        for r in reversed(self._selected_rows()):
            del self.items[r]
        self._rebuild(); self._summary()

    def move(self, d):
        if self.worker: return
        rows = self._selected_rows()
        if len(rows) != 1: return
        r, n = rows[0], rows[0] + d
        if not 0 <= n < len(self.items): return
        self.items[r], self.items[n] = self.items[n], self.items[r]
        self._rebuild(); self.tbl.selectRow(n)

    def clear_list(self):
        if self.worker: return
        self.items = []; self._rebuild(); self._summary()

    def _summary(self):
        known = [it.duration * it.repeat for it in self.items if it.duration is not None]
        endless = sum(1 for it in self.items if it.duration is None)
        self.lbl.setText(f"{len(self.items)} sequence(s) in the list · known total "
                         f"{sum(known):.3g} s" + (f" · {endless} endless" if endless else "")
                         + ". Select rows and click Run selected, or Run all.")

    def save_list(self):
        if not self.items:
            return
        fn, _ = _save_dialog(self, "Save run list", "run_list.json", "Run list (*.json)")
        if not fn: return
        data = []
        for it in self.items:
            entry = {"label": it.label, "name": it.name, "repeat": it.repeat,
                     "max_time": it.max_time}
            if it.path:
                entry["path"] = it.path
            else:
                entry["steps"] = core.parsed_to_text(it.seq, it.name, "steps")
            data.append(entry)
        try:
            with open(fn, "w", encoding="utf-8") as fh:
                json.dump({"run_list": data}, fh, indent=2)
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e))

    def open_list(self):
        if self.worker: return
        fn, _ = _open_dialog(self, "Open run list", "", "Run list (*.json)")
        if not fn: return
        try:
            with open(fn, encoding="utf-8") as fh:
                data = json.load(fh)["run_list"]
        except (OSError, ValueError, KeyError, TypeError) as e:
            QMessageBox.critical(self, "Open failed", f"Not a run list: {e}"); return
        self.items = []; bad = []
        for e in data:
            try:
                if e.get("path"):
                    it = core.load_run_item(e["path"], self.main.cfg.device)
                else:
                    it = self._item_from_text(e.get("label", "sequence"), e.get("name", "SEQ"),
                                              e["steps"])
                it.name = core._safe_name(e.get("name", it.name), it.name)
                it.repeat = int(e.get("repeat", 1)); it.max_time = float(e.get("max_time", 0))
                it.label = e.get("label", it.label)
                self.items.append(it)
            except (OSError, ValueError, KeyError, TypeError) as err:
                bad.append(f"{e.get('label') or e.get('path')}: {err}")
        self._rebuild(); self._summary()
        if bad:
            QMessageBox.warning(self, "Open run list", "Some entries were skipped:\n" +
                                "\n".join(bad))

    # ---------------------------------------------------------------- run
    def run_selected(self):
        rows = self._selected_rows()
        if not rows:
            QMessageBox.information(self, "Run sequences",
                                    "Select one row (single) or several rows (Ctrl/Shift+"
                                    "click) first, or use Run all."); return
        self._start(rows)

    def run_all(self):
        if not self.items:
            QMessageBox.information(self, "Run sequences", "The list is empty."); return
        self._start(list(range(len(self.items))))

    def _start(self, rows):
        if self.worker:
            return
        items = [self.items[r] for r in rows]
        endless = [it.label for it in items if it.duration is None and it.max_time <= 0]
        if endless and (len(items) > 1 or self.chk_loop.isChecked()):
            if QMessageBox.question(
                    self, "Run sequences",
                    "These never stop by themselves, so the list would not continue after "
                    "them:\n  " + "\n  ".join(endless) +
                    "\n\nSet a Max time for them. Run anyway (you can press Stop)?") \
                    != QMessageBox.Yes:
                return
        vmax = max((core.max_setpoint(list(it.seq.steps.values())) for it in items),
                   default=0.0)
        if not confirm_high_voltage(self, vmax):
            return
        if self.chk_on.isChecked() and QMessageBox.question(
                self, "Output ON", "Switch the output ON at the start?") != QMessageBox.Yes:
            return
        s = settings()
        s.setValue("runlist/upload", self.chk_upload.isChecked())
        s.setValue("runlist/verify", self.chk_verify.isChecked())
        s.setValue("runlist/off", self.chk_off.isChecked())
        s.setValue("runlist/stoperr", self.chk_stoperr.isChecked())
        opts = {"upload": self.chk_upload.isChecked(), "verify": self.chk_verify.isChecked(),
                "output_on": self.chk_on.isChecked(), "output_off": self.chk_off.isChecked(),
                "loop": self.chk_loop.isChecked(), "pause": self.sp_pause.value(),
                "stop_on_error": self.chk_stoperr.isChecked()}
        self.running_rows = rows
        self._count = {"done": 0, "failed": 0, "timeout": 0}
        self._timed_out = set()
        for r in rows:
            self._set_status(r, "waiting")
        self.worker = RunListWorker(items, opts)
        self.worker.event.connect(self._on_event)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()
        self.b_sel.setEnabled(False); self.b_all.setEnabled(False); self.b_stop.setEnabled(True)
        self.lbl.setText(f"Running {len(items)} sequence(s)…")

    def stop(self):
        if self.worker:
            self.worker.stop()
            self.lbl.setText("Stopping…")

    def _set_status(self, r, text):
        cell = self.tbl.item(r, 7)
        if cell is not None:
            cell.setText(text)

    def _on_event(self, kind, i, msg):
        if kind == "info":
            self.lbl.setText(msg); return
        if i < 0 or i >= len(self.running_rows):
            if kind == "failed":
                self.lbl.setText(f"<b>Error:</b> {msg}")
            elif kind == "list_done":
                c = self._count
                parts = [f"{c['done']} done"]
                if c["timeout"]:
                    parts.append(f"{c['timeout']} stopped at max time")
                if c["failed"]:
                    parts.append(f"{c['failed']} FAILED")
                self.lbl.setText("Finished: " + ", ".join(parts) + ".")
            return
        r = self.running_rows[i]
        it = self.items[r] if r < len(self.items) else None
        if kind == "timeout":
            self._timed_out.add(r); self._count["timeout"] += 1
        elif kind == "done" and r not in self._timed_out:
            self._count["done"] += 1
        elif kind == "failed":
            self._count["failed"] += 1
        done_text = "done (stopped at max time)" if r in self._timed_out else "done"
        text = {"upload": "uploading…", "start": msg, "state": msg, "done": done_text,
                "timeout": msg, "failed": f"FAILED: {msg}", "stopped": "stopped"}.get(kind, msg)
        if kind == "start":
            self._timed_out.discard(r)
        self._set_status(r, text)
        if kind in ("start", "state"):
            self.lbl.setText(f"Running {i + 1} of {len(self.running_rows)}: "
                             f"{it.name if it else ''} – {msg}")
        elif kind == "failed":
            self.lbl.setText(f"<b>Error</b> in {it.label if it else '?'}: {msg} "
                             f"(Device → Diagnose sequence helps).")

    def _on_finished(self):
        self.worker = None
        self.b_sel.setEnabled(True); self.b_all.setEnabled(True); self.b_stop.setEnabled(False)
        if not self.lbl.text().startswith(("Finished", "<b>Error")):
            self.lbl.setText(self.lbl.text() + " – stopped.")

    def closeEvent(self, ev):
        if self.worker:
            self.worker.stop(); self.worker.wait(5000)
        super().closeEvent(ev)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Delta Elektronika Sequence Builder")
        self.setMinimumSize(800, 560)
        self._fit_to_screen()
        self.cfg = core.SequenceSettings(segments=[core.default_segment("Ramp")])
        self.current_file: str | None = None
        self._loading = False
        self._history: list[str] = []
        self._hidx = -1
        self._restoring = False
        self._build_ui()
        dev = settings().value("ui/device", "", type=str)
        if dev in core.DEVICE_PROFILES:
            self.cfg.device = dev
            for k, v in core.DEVICE_PROFILES[dev].items():
                setattr(self.cfg, k, v)
        self._load_settings_into_ui()
        self.settings_changed()
        self._mark_saved()
        self._restore_ui_state()
        self._adapt_to_size()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        self.setAcceptDrops(True)
        acts = {}
        for key, text, slot, sc, tip in [
            ("new", "New", self.new_project, "Ctrl+N", "New empty project"),
            ("open", "Open project…", self.open_project, "Ctrl+O", "Open a .json project"),
            ("save", "Save project", self.save_project, "Ctrl+S", None),
            ("saveas", "Save project as…", self.save_project_as, "Ctrl+Shift+S", None),
            ("opentxt", "Open sequence .txt…", self.import_txt, "Ctrl+I",
             "Open, plot and edit an existing sequence file"),
            ("samples", "Import samples…", self.import_samples, "Ctrl+M",
             "Import time/value samples from CSV, TXT or Excel"),
            ("export", "Export sequence .txt…", self.export_txt, "Ctrl+E",
             "Save the editor's sequence as a .txt file"),
            ("expsamples", "Export samples…", self.export_editor_samples,
             "Ctrl+Shift+E", "Save the editor's signal as time/value samples"),
            ("upload", "Upload to PSU…", self.upload_psu, None, None),
            ("undo", "Undo", self.undo, "Ctrl+Z", None),
            ("redo", "Redo", self.redo, "Ctrl+Y", None),
            ("exit", "Exit", self.close, "Ctrl+Q", None),
            ("conn", "Connection settings…", self.connection_settings, None,
             "IP address, port and measurement queries"),
            ("test", "Test connection", self.test_connection, None, None),
            ("upload_script", "Upload script sequence…", self.upload_script, None,
             "Upload the sequence from the 'Sequence script' tab"),
            ("readback", "Read sequence from PSU…", self.read_back, None,
             "Download a stored sequence, plot and edit it"),
            ("live", "Live monitor…", self.live_monitor, "Ctrl+L",
             "Log measured voltage/current and compare with the planned profile"),
            ("run", "Run sequence on PSU", self.run_on_psu, None, None),
            ("stopseq", "Stop sequence on PSU", self.stop_on_psu, None, None),
            ("outoff", "Output OFF", self.output_off, None, "Switch the supply output off"),
            ("runlist", "Run sequences (single or multiple)…", self.run_list, "Ctrl+R",
             "Pick one or more sequence .txt files and run them one after another"),
            ("diagnose", "Diagnose sequence…", self.diagnose, None,
             "Ask the supply why a sequence does not drive the output"),
            ("direct", "Direct control…", self.direct_control, "Ctrl+D",
             "Set voltage and current by hand, switch the output, see live readings"),
        ]:
            a = QAction(text, self); a.triggered.connect(slot)
            if sc: a.setShortcut(sc)
            if tip: a.setToolTip(tip); a.setStatusTip(tip)
            acts[key] = a
        self.acts = acts
        mb = self.menuBar()
        m = mb.addMenu("&File")
        for k in ("new", "open", "save", "saveas", None, "opentxt", "samples", None,
                  "export", "expsamples", None, "recent", None, "exit"):
            if k is None:
                m.addSeparator()
            elif k == "recent":
                self.menu_recent = m.addMenu("Recent files")
            else:
                m.addAction(acts[k])
        m = mb.addMenu("&Edit")
        m.addAction(acts["undo"]); m.addAction(acts["redo"])
        m = mb.addMenu("&Device")
        for k in ("conn", "test", None, "direct", "live", None, "upload", "upload_script",
                  "readback", None, "runlist", "run", "stopseq", "outoff", None, "diagnose"):
            m.addSeparator() if k is None else m.addAction(acts[k])
        self.menu_tpl = mb.addMenu("&Templates")
        self._rebuild_templates()
        self._rebuild_recent()
        for k, badge, col, short in (
                ("new", "+", C_FILE, "New"),
                ("open", "OPN", C_FILE, "Open"),
                ("save", "SAV", C_FILE, "Save"),
                ("undo", "↶", C_EDIT, "Undo"),
                ("redo", "↷", C_EDIT, "Redo"),
                ("opentxt", "TXT", C_VIEW, "Open .txt"),
                ("samples", "CSV", C_VIEW, "Import samples"),
                ("export", "TXT", C_FILE, "Export .txt"),
                ("upload", "▲", C_DEV, "Upload"),
                ("readback", "▼", C_DEV, "Read back"),
                ("direct", "V/A", C_DEV, "Direct control"),
                ("live", "∿", C_DEV, "Live monitor"),
                ("runlist", "▶", C_RUN, "Run"),
                ("stopseq", "■", C_STOP, "Stop"),
                ("outoff", "OFF", C_STOP, "Output OFF")):
            acts[k].setIcon(badge_icon(badge, col))
            acts[k].setIconText(short)
        self._tb_labels = {"opentxt": ("Open .txt", ".txt"), "samples": ("Import samples", "Samples"),
                           "export": ("Export .txt", "Export"), "readback": ("Read back", "Read"),
                           "direct": ("Direct control", "Direct"), "live": ("Live monitor", "Live"),
                           "outoff": ("Output OFF", "Out OFF")}
        tb = QToolBar("Main"); tb.setObjectName("main_toolbar"); self.addToolBar(tb)
        tb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        tb.setIconSize(QSize(26, 26))
        tb.setMovable(False)

        self.main_tb = tb
        self._tb_headings = []

        def heading(text):
            lab = QLabel(text); lab.setObjectName("barHeading")
            lab.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
            self._tb_headings.append(tb.addWidget(lab))
        for k in ("FILE", "new", "open", "save", None, "undo", "redo", None,
                  "SEQUENCE FILES", "opentxt", "samples", "export", None,
                  "SUPPLY", "upload", "readback", "direct", "live", None,
                  "RUN", "runlist", "stopseq", "outoff"):
            if k is None:
                tb.addSeparator()
            elif k.isupper():
                heading(k)
            else:
                tb.addAction(acts[k])
        spacer = QWidget(); spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)
        self.conn_pill = QLabel("● Supply: not checked"); self.conn_pill.setObjectName("connPill")
        self.conn_pill.setToolTip("Connection to the power supply – see the Connection window")
        set_state(self.conn_pill, "idle")
        tb.addWidget(self.conn_pill)

        # ---- left: two tabs – "Signal" (what is played) and "Settings"
        self.ed_name = QLineEdit(); self.ed_name.setMaxLength(16)
        self.ed_name.setToolTip("Name on the supply: starts with a letter, at most 16 "
                                "letters, digits or _")
        self.cb_channel = QComboBox(); self.cb_channel.addItems(CHANNELS)
        self.cb_channel.setToolTip("Which setting the signal drives")
        self.sp_vlim = self._dspin(0, 2000, 3); self.sp_clim = self._dspin(0, 2000, 3)
        self.sp_vlim.setSuffix(" V"); self.sp_clim.setSuffix(" A")
        self.sp_vmax = self._dspin(0, 2000, 3); self.sp_cmax = self._dspin(0, 2000, 3)
        self.sp_vmax.setSuffix(" V"); self.sp_cmax.setSuffix(" A")
        self.cb_device = QComboBox()
        self.cb_device.addItems(list(core.DEVICE_PROFILES) + [core.CUSTOM_DEVICE])
        self.cb_device.setToolTip("Selects the model limits used to check the sequence")
        self.cb_device.currentIndexChanged.connect(self.device_changed)
        self.sp_pmax = self._dspin(0, 100000, 1); self.sp_pmax.setSuffix(" W")
        self.sp_repeat = QSpinBox(); self.sp_repeat.setRange(0, 65535)
        self.sp_repeat.setSpecialValueText("∞ (forever)")
        self.sp_repeat.setSuffix(" ×")
        self.chk_final = QCheckBox("Set at end:")
        self.sp_final = self._dspin(-100000, 100000, 3)
        self.sp_dec = QSpinBox(); self.sp_dec.setRange(0, 4)
        self.chk_merge = QCheckBox("Merge equal consecutive values")
        self.chk_nv = QCheckBox("Store non-volatile (PROG:SAV)")
        self.chk_clear = QCheckBox("Delete old sequence before upload")
        self.chk_run = QCheckBox("Run after upload")
        self.chk_compact = QCheckBox("Compact ramps (INC loops – far fewer steps)")
        self.chk_compact.setToolTip(
            "Straight ramps are written as small loops (INC + jump, variable #B)\n"
            "instead of one SV=/W= pair per point. A 1000-point ramp needs ~7 steps.\n"
            "Every value stays within half a digit of the normal output.")
        self.sp_maxstep = self._dspin(0, 1e6, 3); self.sp_maxstep.setSpecialValueText("off")
        self.sp_maxstep.setToolTip("Largest allowed change between two consecutive set values")
        self.sp_maxrate = self._dspin(0, 1e9, 3); self.sp_maxrate.setSpecialValueText("off")
        self.sp_maxrate.setToolTip("Largest allowed |change| divided by the hold time "
                                   "before it (units per second)")
        self.chk_safe_err = QCheckBox("Block export/upload when a check fails")
        self.sp_plim = self._dspin(0, 100000, 1); self.sp_plim.setSuffix(" W")
        self.sp_plim.setSpecialValueText("model maximum")
        self.cb_wpow = QComboBox()
        self.cb_wpow.addItems(["Automatic (SM15K: yes, SM3300: no)", "Always", "Never"])

        hint = hint_label

        # ----- "Signal" tab
        sig = QWidget(); sl = QVBoxLayout(sig)
        gtop = QGroupBox("Sequence"); ft = QFormLayout(gtop)
        ft.addRow("Name", self.ed_name)
        ft.addRow("Controls", self.cb_channel)
        ft.addRow("Repeat", self.sp_repeat)
        sl.addWidget(gtop)

        gs = QGroupBox("Segments – played from top to bottom"); sv = QVBoxLayout(gs)
        hb = QHBoxLayout()
        self.cb_type = QComboBox(); self.cb_type.addItems(core.SEGMENT_TYPES)
        b_add = QPushButton("+ Add segment"); b_add.clicked.connect(self.add_segment)
        set_role(b_add, "primary")
        self.cb_type.setToolTip("Kind of signal piece to add")
        for i in range(self.cb_type.count()):
            self.cb_type.setItemIcon(i, segment_icon(self.cb_type.itemText(i)))
        b_add.setToolTip("Add a segment of the chosen type at the end")
        hb.addWidget(QLabel("Type")); hb.addWidget(self.cb_type, 1); hb.addWidget(b_add)
        sv.addLayout(hb)
        self.lst = QListWidget()
        self.lst.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst.currentRowChanged.connect(self.segment_selected)
        self.lst.setMinimumHeight(140)
        self.lst.setIconSize(QSize(20, 20))
        sv.addWidget(self.lst, 1)
        hb2 = QHBoxLayout()
        for text, slot, tip in [
                ("Duplicate", self.dup_segment, "Copy the selected segment"),
                ("Delete", self.del_segment, "Remove the selected segment"),
                ("↑ Up", lambda: self.move_segment(-1), "Move the segment earlier"),
                ("↓ Down", lambda: self.move_segment(1), "Move the segment later")]:
            b = QPushButton(text); b.clicked.connect(slot); b.setToolTip(tip)
            hb2.addWidget(b)
        sv.addLayout(hb2)
        hb4 = QHBoxLayout()
        b = QPushButton("Combine 2 selected (+ − ×)…")
        b.setToolTip("Ctrl+click two segments, then combine them into one signal")
        b.clicked.connect(self.combine_selected); hb4.addWidget(b)
        b = QPushButton("Split"); b.setToolTip("Turn a Combine segment back into A and B")
        b.clicked.connect(self.split_segment); hb4.addWidget(b)
        sv.addLayout(hb4)
        sl.addWidget(gs, 1)

        self.grp_params = QGroupBox("Selected segment")
        self.form_params = QFormLayout(self.grp_params)
        sl.addWidget(self.grp_params)

        # ----- "Settings" tab
        stw = QWidget(); stl = QVBoxLayout(stw)
        g1 = QGroupBox("Power supply model"); f1 = QFormLayout(g1)
        f1.addRow("Device", self.cb_device)
        f1.addRow("Max voltage / current", self._row(self.sp_vmax, self.sp_cmax))
        f1.addRow("Max power", self.sp_pmax)
        f1.addRow(hint("Pick your model to fill in its limits; choose Custom to type them."))
        stl.addWidget(g1)

        g2 = QGroupBox("Fixed values during the sequence"); f2 = QFormLayout(g2)
        f2.addRow("Voltage limit", self.sp_vlim)
        f2.addRow("Current limit", self.sp_clim)
        f2.addRow("Power limit (SP)", self.sp_plim)
        f2.addRow("Write power limit", self.cb_wpow)
        f2.addRow(hint("The setting that the signal does not control is held at this "
                       "value (e.g. the current limit while the voltage follows the "
                       "signal). SM15K supplies start a sequence with power 0 W, so "
                       "the power limit is written too – otherwise nothing comes out."))
        stl.addWidget(g2)

        g3 = QGroupBox("Sequence file"); f3 = QFormLayout(g3)
        hf = QHBoxLayout(); hf.addWidget(self.chk_final); hf.addWidget(self.sp_final)
        f3.addRow(hf)
        f3.addRow("Decimals", self.sp_dec)
        for w in (self.chk_merge, self.chk_compact, self.chk_nv, self.chk_clear,
                  self.chk_run):
            f3.addRow(w)
        stl.addWidget(g3)

        gsafe = QGroupBox("Safety checks"); fs = QFormLayout(gsafe)
        fs.addRow("Max step size", self.sp_maxstep)
        fs.addRow("Max rate [/s]", self.sp_maxrate)
        fs.addRow(self.chk_safe_err)
        fs.addRow(hint("Power (V × I) is always checked against the device rating. "
                       "High-voltage confirmation: Device → Connection settings."))
        stl.addWidget(gsafe)
        stl.addStretch()

        # ----- signals
        self.ed_name.textChanged.connect(self.settings_changed)
        self.cb_channel.currentIndexChanged.connect(self.settings_changed)
        for w in (self.sp_vlim, self.sp_clim, self.sp_vmax, self.sp_cmax,
                  self.sp_pmax, self.sp_final, self.sp_maxstep, self.sp_maxrate,
                  self.sp_plim):
            w.valueChanged.connect(self.settings_changed)
        self.cb_wpow.currentIndexChanged.connect(self.settings_changed)
        for w in (self.sp_repeat, self.sp_dec):
            w.valueChanged.connect(self.settings_changed)
        for w in (self.chk_final, self.chk_merge, self.chk_nv, self.chk_clear,
                  self.chk_run, self.chk_compact, self.chk_safe_err):
            w.toggled.connect(self.settings_changed)

        def scrolled(page):
            sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(page)
            sc.setFrameShape(QScrollArea.NoFrame)
            return sc
        self._signal_page, self._settings_page = scrolled(sig), scrolled(stw)

        # ---- centre: plots (Preview / Opened sequence / Compare)
        self.plot_tabs = QTabWidget()
        pw = QWidget(); pv = QVBoxLayout(pw)
        self.canvas = PlotCanvas()
        pv.addWidget(PlotPanel(self.canvas))
        self.plot_tabs.addTab(pw, badge_icon("∿", C_FILE), "Editor preview")
        self.plot_tabs.setTabToolTip(0, "The signal you are building in the Signal window")
        self.plot_tabs.setIconSize(QSize(18, 18))

        iw = QWidget(); iv = QVBoxLayout(iw)
        self.imp_canvas = ImportCanvas()
        iv.addWidget(PlotPanel(self.imp_canvas), 1)
        hi = FlowLayout()
        self.sp_simtime = self._dspin(0.1, 1e6, 1); self.sp_simtime.setValue(600)
        hi.addWidget(pair("Sim. limit [s]", self.sp_simtime))
        self.ed_inputs = QLineEdit(); self.ed_inputs.setPlaceholderText("e.g. IA1=1, IB2=0")
        self.ed_inputs.setMinimumWidth(160)
        hi.addWidget(pair("Inputs", self.ed_inputs))
        b = QPushButton("Re-simulate"); b.clicked.connect(self.run_import_sim)
        set_role(b, "primary")
        hi.addWidget(b)
        b = QPushButton("Convert to editable…"); b.clicked.connect(self.convert_import)
        hi.addWidget(b)
        b = QPushButton("Save as .txt…"); b.clicked.connect(self.save_script_as)
        hi.addWidget(b)
        b = QPushButton("Export samples…"); b.clicked.connect(self.export_imported_samples)
        hi.addWidget(b)
        b = QPushButton("Add to run list"); b.clicked.connect(self.add_opened_to_run_list)
        b.setToolTip("Add this sequence to the Run sequences list")
        hi.addWidget(b)
        iv.addLayout(hi)
        self.lbl_import = QLabel("Use 'Open sequence .txt…' to load an existing file.")
        self.lbl_import.setWordWrap(True)
        iv.addWidget(self.lbl_import)
        self.plot_tabs.addTab(iw, badge_icon("TXT", C_VIEW), "Opened sequence")
        self.plot_tabs.setTabToolTip(1, "A sequence .txt file you opened or read back "
                                        "from the supply, simulated")
        self.compare = ComparePanel(self)
        self.plot_tabs.addTab(self.compare, badge_icon("A|B", "#00838f"), "Compare")
        self.plot_tabs.setTabToolTip(2, "Overlay sequences and measured/sample files, "
                                        "show the difference and tolerance")
        self.imported: core.ParsedSequence | None = None
        self.imported_file = ""
        self.sim: core.SimResult | None = None

        ow = QWidget(); ov = QVBoxLayout(ow)
        hb3 = QHBoxLayout()
        hb3.addWidget(QLabel("File format:"))
        self.cb_fmt = QComboBox()
        self.cb_fmt.addItems(["SCPI upload commands", "Step list"])
        self.cb_fmt.currentIndexChanged.connect(self.refresh)
        hb3.addWidget(self.cb_fmt); hb3.addStretch()
        self.lbl_status = QLabel(); hb3.addWidget(self.lbl_status)
        ov.addLayout(hb3)
        self.tabs = QTabWidget()
        self.txt_out = QPlainTextEdit(); self.txt_out.setReadOnly(True)
        self.txt_out.setFont(QFont("Consolas", 10))
        self.txt_msg = QPlainTextEdit(); self.txt_msg.setReadOnly(True)
        self.tabs.addTab(self.txt_out, "Sequence file")
        self.tabs.addTab(self.txt_msg, "Messages")
        sw = QWidget(); sv2 = QVBoxLayout(sw); sv2.setContentsMargins(0, 0, 0, 0)
        hs = QHBoxLayout()
        b = QPushButton("Apply && simulate  (Ctrl+Enter)"); set_role(b, "primary")
        b.clicked.connect(self.apply_script); hs.addWidget(b)
        b = QPushButton("Save as .txt…"); b.clicked.connect(self.save_script_as)
        hs.addWidget(b)
        b = QPushButton("Load editor's sequence"); b.setToolTip(
            "Copy the generated sequence here so you can hand-edit it")
        b.clicked.connect(self.load_generated_into_script); hs.addWidget(b)
        hs.addStretch()
        self.lbl_script = QLabel(""); hs.addWidget(self.lbl_script)
        sv2.addLayout(hs)
        self.txt_import = QPlainTextEdit()
        self.txt_import.setFont(QFont("Consolas", 10))
        self.txt_import.setPlaceholderText(
            "Open a sequence .txt file, or click \"Load editor's sequence\", then "
            "edit the steps here (e.g. 'PROG:SEL:STE 5 SV=12' or '5 SV=12').")
        self.txt_import.textChanged.connect(
            lambda: self.lbl_script.setText("Modified – click Apply"))
        sv2.addWidget(self.txt_import)
        a = QAction(self); a.setShortcut("Ctrl+Return"); a.triggered.connect(self.apply_script)
        self.txt_import.addAction(a)
        a.setShortcutContext(Qt.WidgetShortcut)
        self.tabs.addTab(sw, "Script editor")
        ov.addWidget(self.tabs)
        self.setCentralWidget(self.plot_tabs)
        self.sb_supply = QLabel()
        self.statusBar().addPermanentWidget(self.sb_supply)
        self._build_docks(ow)
        self._update_supply_label()

    # ------------------------------------------------------------- docking
    def _build_docks(self, output_widget):
        """ControlDesk-style: every panel is a dock window that can be moved,
        stacked as tabs, floated or closed; the Windows bar opens them again."""
        self.setDockOptions(QMainWindow.AnimatedDocks | QMainWindow.AllowTabbedDocks |
                            QMainWindow.AllowNestedDocks)
        self.setTabPosition(Qt.AllDockWidgetAreas, QTabWidget.North)
        # side panels run the full height; the output panel sits under the plots
        self.setCorner(Qt.BottomLeftCorner, Qt.LeftDockWidgetArea)
        self.setCorner(Qt.BottomRightCorner, Qt.RightDockWidgetArea)
        self.conn_panel = ConnectionPanel(self)
        self._direct = DirectControlDialog(self)
        self._live = LiveMonitorDialog(self)
        self.run_panel = RunListPanel(self)

        intros = {
            "dock_connection": "Type the supply's IP address and port and click Connect. "
                               "Green = the supply answers.",
            "dock_signal": "Build the signal: add segments (played top to bottom) and "
                           "click one to edit its values. The plot shows the result.",
            "dock_settings": "Model limits, values held constant during the sequence, "
                             "file options and safety checks.",
            "dock_output": "The generated sequence file, warnings/errors, and a script "
                           "editor for changing steps by hand.",
            "dock_direct": "Set voltage and current by hand and switch the output on/off.",
            "dock_live": "Measured voltage and current over time, compared with the "
                         "planned signal.",
            "dock_runlist": "Pick one or more sequence .txt files and run them on the "
                            "supply one after another.",
        }

        def mk(title, widget, name):
            d = QDockWidget(title, self)
            d.setObjectName(name)
            d.setWidget(dock_body(widget, intros[name],
                                  scroll=name in ("dock_connection", "dock_direct")))
            d.setMinimumWidth(260)
            d.setTitleBarWidget(DockTitle(d))
            d.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable |
                          QDockWidget.DockWidgetClosable)
            return d
        self.dock_conn = mk("Connection", self.conn_panel, "dock_connection")
        self.dock_signal = mk("Signal", self._signal_page, "dock_signal")
        self.dock_settings = mk("Settings", self._settings_page, "dock_settings")
        self.dock_output = mk("Output – sequence file · messages · script", output_widget,
                              "dock_output")
        self.dock_direct = mk("Direct control", self._direct, "dock_direct")
        self.dock_live = mk("Live monitor", self._live, "dock_live")
        self.dock_runlist = mk("Run sequences", self.run_panel, "dock_runlist")
        self.docks = [self.dock_conn, self.dock_signal, self.dock_settings,
                      self.dock_output, self.dock_direct, self.dock_live, self.dock_runlist]

        scr = QApplication.primaryScreen()
        avail_h = scr.availableGeometry().height() if scr else 1000
        compact = avail_h < 900          # laptop screens: no room for two left panels
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_conn)
        if compact:
            # Connection becomes a tab next to Signal/Settings; the toolbar pill
            # still shows the connection state at all times
            self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_signal)
            self.tabifyDockWidget(self.dock_conn, self.dock_signal)
        else:
            self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_signal)
        self.tabifyDockWidget(self.dock_signal, self.dock_settings)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_output)
        self.addDockWidget(Qt.RightDockWidgetArea, self.dock_direct)
        self.tabifyDockWidget(self.dock_direct, self.dock_live)
        self.tabifyDockWidget(self.dock_live, self.dock_runlist)
        self.dock_signal.raise_()
        self.dock_direct.hide(); self.dock_live.hide(); self.dock_runlist.hide()
        if not compact:
            self.resizeDocks([self.dock_conn, self.dock_signal], [330, 520], Qt.Vertical)
        self.resizeDocks([self.dock_conn], [380 if not compact else 340], Qt.Horizontal)
        self.resizeDocks([self.dock_output], [260 if not compact else 190], Qt.Vertical)
        self.resizeDocks([self.dock_direct], [520 if not compact else 400], Qt.Horizontal)
        self._default_layout = self.saveState()

        # ---- "Windows" bar on the left edge + Windows menu
        bar = QToolBar("Windows"); bar.setObjectName("windows_toolbar")
        bar.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        bar.setIconSize(QSize(26, 26))
        bar.setMovable(False)
        self.addToolBar(Qt.LeftToolBarArea, bar)
        menu = self.menuBar().addMenu("&Windows")

        self.windows_bar = bar
        self._bar_headings = []

        def bar_heading(text):
            lab = QLabel(text); lab.setObjectName("barHeading")
            lab.setAlignment(Qt.AlignCenter)
            self._bar_headings.append(bar.addWidget(lab))
        bar_heading("WINDOWS")
        entries = [
            ("Connection", badge_icon("IP", "#0277bd"), self.dock_conn),
            ("Signal", badge_icon("∿", "#1565c0"), self.dock_signal),
            ("Settings", badge_icon("⚙", "#546e7a"), self.dock_settings),
            ("Output", badge_icon("TXT", "#6a1b9a"), self.dock_output),
            ("Direct\ncontrol", badge_icon("V/A", C_DEV), self.dock_direct),
            ("Live\nmonitor", badge_icon("LIVE", "#00838f"), self.dock_live),
            ("Run\nsequences", badge_icon("▶", C_RUN), self.dock_runlist),
        ]
        for text, icon, dock in entries:
            a = QAction(icon, text, self)
            a.setToolTip(f"Open the {dock.windowTitle()} window")
            a.triggered.connect(lambda _=False, d=dock: self.open_dock(d))
            bar.addAction(a)
            m = dock.toggleViewAction()
            m.setText(dock.windowTitle()); menu.addAction(m)
            m.triggered.connect(lambda on: on and self._tidy_dock_groups())
        bar.addSeparator(); menu.addSeparator()
        bar_heading("PLOTS")
        for text, icon, idx in (("Editor\npreview", badge_icon("∿", C_FILE), 0),
                                ("Opened\nsequence", badge_icon("TXT", C_VIEW), 1),
                                ("Compare", badge_icon("A|B", "#00838f"), 2)):
            a = QAction(icon, text, self)
            a.setToolTip(f"Show the {text.replace(chr(10), ' ')} plot")
            a.triggered.connect(lambda _=False, i=idx: self.plot_tabs.setCurrentIndex(i))
            bar.addAction(a)
            m = QAction(text.replace("\n", " ") + " plot", self)
            m.triggered.connect(lambda _=False, i=idx: self.plot_tabs.setCurrentIndex(i))
            menu.addAction(m)
        menu.addSeparator()
        a = QAction("Reset layout", self); a.triggered.connect(self.reset_layout)
        menu.addAction(a)

    def open_dock(self, dock):
        """Show a window (also if it was closed, floating or behind another tab).
        A window of a group opens as a tab next to its visible partner."""
        for group in ((self.dock_direct, self.dock_live, self.dock_runlist),
                      (self.dock_signal, self.dock_settings)):
            if dock in group and dock.isHidden() and not dock.isFloating():
                partner = next((d for d in group if d is not dock and not d.isHidden()
                                and not d.isFloating()), None)
                if partner is not None:
                    self.tabifyDockWidget(partner, dock)
                break
        dock.show()
        dock.raise_()
        w = dock.widget()
        getattr(w, "content", w).setFocus()

    def reset_layout(self):
        for d in self.docks:
            if d.isFloating():
                d.setFloating(False)
        self.restoreState(self._default_layout)
        if not self.isMaximized():
            self._fit_to_screen()
        for d in (self.dock_conn, self.dock_signal, self.dock_settings, self.dock_output):
            d.show()
        self.dock_signal.raise_()

    @staticmethod
    def _dspin(lo, hi, dec):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setKeyboardTracking(False)
        return s

    @staticmethod
    def _row(*widgets):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in widgets: h.addWidget(x)
        return w

    # ------------------------------------------------------- settings <-> UI
    def _load_settings_into_ui(self):
        self._loading = True
        c = self.cfg
        self.ed_name.setText(c.name)
        self.cb_channel.setCurrentIndex(list(CHANNELS.values()).index(c.channel))
        self.sp_vlim.setValue(c.limit_voltage); self.sp_clim.setValue(c.limit_current)
        self.cb_device.setCurrentText(c.device if c.device in core.DEVICE_PROFILES
                                      else core.CUSTOM_DEVICE)
        self.sp_vmax.setValue(c.vmax); self.sp_cmax.setValue(c.cmax)
        self.sp_pmax.setValue(c.pmax)
        self._apply_device_enable()
        self.sp_repeat.setValue(c.repeat)
        self.chk_final.setChecked(c.final_value_enabled); self.sp_final.setValue(c.final_value)
        self.sp_dec.setValue(c.decimals); self.chk_merge.setChecked(c.merge_equal)
        self.chk_nv.setChecked(c.nonvolatile); self.chk_clear.setChecked(c.clear_before_upload)
        self.chk_run.setChecked(c.run_after_upload)
        self.chk_compact.setChecked(c.compact_ramps)
        self.sp_maxstep.setValue(c.max_step); self.sp_maxrate.setValue(c.max_rate)
        self.chk_safe_err.setChecked(c.safety_errors)
        self.sp_plim.setValue(c.power_limit)
        self.cb_wpow.setCurrentIndex({"auto": 0, "yes": 1, "no": 2}.get(c.write_power, 0))
        self._loading = False
        self._rebuild_list(0)

    def _apply_device_enable(self):
        custom = self.cb_device.currentText() == core.CUSTOM_DEVICE
        for w in (self.sp_vmax, self.sp_cmax, self.sp_pmax):
            w.setEnabled(custom)

    def device_changed(self, *_):
        if self._loading:
            return
        prof = core.DEVICE_PROFILES.get(self.cb_device.currentText())
        if prof:
            self._loading = True
            self.sp_vmax.setValue(prof["vmax"]); self.sp_cmax.setValue(prof["cmax"])
            self.sp_pmax.setValue(prof["pmax"])
            self._loading = False
        self._apply_device_enable()
        settings().setValue("ui/device", self.cb_device.currentText())
        self.settings_changed()
        self._update_supply_label()
        if getattr(self, "_direct", None) is not None:
            self._direct.refresh_limits()

    def settings_changed(self, *_):
        if self._loading:
            return
        c = self.cfg
        c.name = self.ed_name.text().strip()
        c.channel = CHANNELS[self.cb_channel.currentText()]
        c.limit_voltage = self.sp_vlim.value(); c.limit_current = self.sp_clim.value()
        c.vmax = self.sp_vmax.value(); c.cmax = self.sp_cmax.value()
        c.pmax = self.sp_pmax.value()
        c.device = self.cb_device.currentText()
        c.repeat = self.sp_repeat.value()
        c.final_value_enabled = self.chk_final.isChecked()
        c.final_value = self.sp_final.value()
        c.decimals = self.sp_dec.value(); c.merge_equal = self.chk_merge.isChecked()
        c.nonvolatile = self.chk_nv.isChecked()
        c.clear_before_upload = self.chk_clear.isChecked()
        c.run_after_upload = self.chk_run.isChecked()
        c.compact_ramps = self.chk_compact.isChecked()
        c.max_step = self.sp_maxstep.value(); c.max_rate = self.sp_maxrate.value()
        c.safety_errors = self.chk_safe_err.isChecked()
        c.power_limit = self.sp_plim.value()
        c.write_power = ("auto", "yes", "no")[self.cb_wpow.currentIndex()]
        self.sp_plim.setEnabled(core.writes_power(c) and c.channel not in ("SP", "SPN"))
        self.sp_vlim.setEnabled(c.channel != "SV")
        self.sp_clim.setEnabled(c.channel != "SC")
        self.refresh()

    # ------------------------------------------------------------- segments
    def _rebuild_list(self, select=None):
        self.lst.blockSignals(True)
        self.lst.clear()
        for i, s in enumerate(self.cfg.segments, 1):
            it = QListWidgetItem(segment_icon(s["type"]),
                                 f"{i}.  {core.describe_segment(s)}")
            it.setToolTip(f"Segment {i}: {s['type']} – click to edit its values")
            self.lst.addItem(it)
        self.lst.blockSignals(False)
        if select is not None and self.cfg.segments:
            self.lst.setCurrentRow(max(0, min(select, len(self.cfg.segments) - 1)))
        else:
            self.segment_selected(self.lst.currentRow())

    def add_segment(self):
        seg = core.default_segment(self.cb_type.currentText())
        # continue from the previous segment's last value
        if self.cfg.segments:
            try:
                pts = core.segment_preview(self.cfg.segments[-1])
            except (ValueError, ZeroDivisionError, KeyError):
                pts = []
            last = pts[-1][0] if pts else 0.0
            for key in ("value", "start", "low", "offset"):
                if key in seg:
                    seg[key] = round(last, 3); break
        self.cfg.segments.append(seg)
        self._rebuild_list(len(self.cfg.segments) - 1)

    def dup_segment(self):
        r = self.lst.currentRow()
        if r < 0: return
        self.cfg.segments.insert(r + 1, copy.deepcopy(self.cfg.segments[r]))
        self._rebuild_list(r + 1)

    def del_segment(self):
        r = self.lst.currentRow()
        if r < 0: return
        del self.cfg.segments[r]
        self._rebuild_list(r)
        self.refresh()

    def combine_selected(self):
        rows = sorted({i.row() for i in self.lst.selectedIndexes()})
        if len(rows) != 2:
            QMessageBox.information(
                self, "Combine",
                "Select exactly two segments (Ctrl+click), then click Combine.\n\n"
                "Tip: you can also add a 'Combine' segment and edit A and B directly.")
            return
        op, ok = QInputDialog.getItem(self, "Combine", "Operation (A ∘ B):",
                                      list(core.COMBINE_OPS), 2, False)
        if not ok: return
        a, b = (copy.deepcopy(self.cfg.segments[r]) for r in rows)
        dts = [x["dt"] for x in (a, b) if "dt" in x]
        seg = {"type": "Combine", "op": op, "dt": min(dts) if dts else 0.05,
               "a": a, "b": b}
        self.cfg.segments[rows[0]] = seg
        del self.cfg.segments[rows[1]]
        self._rebuild_list(rows[0])

    def split_segment(self):
        r = self.lst.currentRow()
        if r < 0 or self.cfg.segments[r]["type"] != "Combine":
            QMessageBox.information(self, "Split", "Select a Combine segment first.")
            return
        seg = self.cfg.segments[r]
        self.cfg.segments[r:r + 1] = [seg["a"], seg["b"]]
        self._rebuild_list(r)

    def move_segment(self, d):
        r = self.lst.currentRow(); n = r + d
        if r < 0 or not 0 <= n < len(self.cfg.segments): return
        s = self.cfg.segments
        s[r], s[n] = s[n], s[r]
        self._rebuild_list(n)

    def segment_selected(self, row):
        while self.form_params.rowCount():
            self.form_params.removeRow(0)
        if row < 0 or row >= len(self.cfg.segments):
            self.grp_params.setTitle("Segment parameters")
            self.refresh(); return
        seg = self.cfg.segments[row]
        self.grp_params.setTitle(f"Segment {row + 1}: {seg['type']}")
        build_segment_form(self.form_params, seg,
                           lambda r=row: self._seg_edited(r), self)
        self.refresh()

    def _seg_edited(self, row):
        item = self.lst.item(row)
        if item:
            item.setText(f"{row + 1}. {core.describe_segment(self.cfg.segments[row])}")
        self.refresh()

    # --------------------------------------------------------------- output
    def _fmt_key(self):
        return "scpi" if self.cb_fmt.currentIndex() == 0 else "steps"

    def refresh(self):
        if self._loading or not hasattr(self, "canvas"):
            return
        comp = core.compile_sequence(self.cfg)
        self.comp = comp
        # segment time bounds for highlighting
        bounds, t = [], 0.0
        for s in self.cfg.segments:
            try:
                d = core.segment_compiled_duration(s)
            except (ValueError, ZeroDivisionError, KeyError):
                d = 0
            bounds.append((t, t + d)); t += d
        self.canvas.plot(comp.points, self.cfg.channel, self.cfg.repeat,
                         bounds, self.lst.currentRow(), comp.markers, comp.lead_waits)
        self.txt_out.setPlainText(core.to_text(self.cfg, comp, self._fmt_key()))
        msgs = [f"ERROR: {e}" for e in comp.errors] + [f"Warning: {w}" for w in comp.warnings]
        self.txt_msg.setPlainText("\n".join(msgs) or "No problems.")
        state = "Errors" if comp.errors else ("Warnings" if comp.warnings else "OK")
        self.lbl_status.setText(
            f"<b>{state}</b> · {len(comp.steps)} of {core.MAX_STEPS} steps · "
            f"{comp.duration_one_pass:.3f} s per pass")
        self.tabs.setTabText(1, f"Messages ({len(msgs)})" if msgs else "Messages")
        self._push_history()
        self._update_title()

    # ------------------------------------------------------------ undo / redo
    def _push_history(self):
        if self._restoring:
            return
        snap = self.cfg.to_json()
        if self._hidx >= 0 and self._history[self._hidx] == snap:
            return
        del self._history[self._hidx + 1:]
        self._history.append(snap)
        if len(self._history) > 300:
            self._history.pop(0)
        self._hidx = len(self._history) - 1
        self._update_undo_actions()

    def _update_undo_actions(self):
        if hasattr(self, "acts"):
            self.acts["undo"].setEnabled(self._hidx > 0)
            self.acts["redo"].setEnabled(self._hidx < len(self._history) - 1)

    def _restore(self, idx):
        row = self.lst.currentRow()
        self._restoring = True
        try:
            self._hidx = idx
            self.cfg = core.SequenceSettings.from_json(self._history[idx])
            self._load_settings_into_ui()
            self.settings_changed()
            if self.cfg.segments:
                self.lst.setCurrentRow(max(0, min(row, len(self.cfg.segments) - 1)))
        finally:
            self._restoring = False
        self._update_undo_actions()

    def undo(self):
        if self._hidx > 0:
            self._restore(self._hidx - 1)

    def redo(self):
        if self._hidx < len(self._history) - 1:
            self._restore(self._hidx + 1)

    # ---------------------------------------------------------- file actions
    def _fresh_settings(self, **kw) -> core.SequenceSettings:
        """New settings that keep the device the user selected."""
        cfg = core.SequenceSettings(**kw)
        dev = self.cfg.device if hasattr(self, "cfg") else ""
        if dev in core.DEVICE_PROFILES:
            cfg.device = dev
            for k, v in core.DEVICE_PROFILES[dev].items():
                if k != "sink":
                    setattr(cfg, k, v)
        elif hasattr(self, "cfg"):
            cfg.device = core.CUSTOM_DEVICE
            cfg.vmax, cfg.cmax, cfg.pmax = self.cfg.vmax, self.cfg.cmax, self.cfg.pmax
        return cfg

    def new_project(self):
        if not self._maybe_save():
            return
        self.cfg = self._fresh_settings(segments=[])
        self.current_file = None
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self._mark_saved()

    def open_project(self, fn=None):
        if not self._maybe_save():
            return
        if not fn:
            fn, _ = _open_dialog(self, "Open project", "",
                                                "Sequence project (*.json)")
        if not fn: return
        try:
            with open(fn, encoding="utf-8") as fh:
                cfg = core.SequenceSettings.from_json(fh.read())
        except (OSError, ValueError, TypeError) as e:
            QMessageBox.critical(self, "Open failed", f"{os.path.basename(fn)}:\n{e}")
            return
        self.cfg = cfg
        self.current_file = fn
        self._add_recent(fn)
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self._mark_saved()

    def save_project(self) -> bool:
        if not self.current_file:
            return self.save_project_as()
        try:
            with open(self.current_file, encoding="utf-8", mode="w") as fh:
                fh.write(self.cfg.to_json())
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e))
            return False
        self._add_recent(self.current_file)
        self._mark_saved()
        self.statusBar().showMessage(f"Saved {self.current_file}", 4000)
        return True

    def save_project_as(self) -> bool:
        fn, _ = _save_dialog(self, "Save project", f"{self.cfg.name}.json",
                             "Sequence project (*.json)")
        if not fn:
            return False
        if not fn.lower().endswith(".json"):
            fn += ".json"
        self.current_file = fn
        return self.save_project()

    # ---- unsaved-changes tracking
    def _mark_saved(self):
        self._saved_snapshot = self.cfg.to_json()
        self._update_title()

    def _is_modified(self) -> bool:
        return bool(self.cfg.segments) and \
            self.cfg.to_json() != getattr(self, "_saved_snapshot", None)

    def _update_title(self):
        name = os.path.basename(self.current_file) if self.current_file else "untitled"
        mark = " *" if self._is_modified() else ""
        self.setWindowTitle(f"{name}{mark} – Delta Elektronika Sequence Builder")

    def _maybe_save(self) -> bool:
        """Ask before throwing away unsaved changes. True = go ahead."""
        if not hasattr(self, "cfg") or not self._is_modified():
            return True
        r = QMessageBox.question(
            self, "Unsaved changes", "The current sequence has unsaved changes. Save them?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel, QMessageBox.Save)
        if r == QMessageBox.Save:
            return self.save_project()
        return r == QMessageBox.Discard

    # ------------------------------------------------------- import .txt
    def import_txt(self, fn=None):
        if not fn:
            fn, _ = _open_dialog(
                self, "Open sequence file", "", "Sequence text (*.txt *.seq);;All files (*)")
        if not fn: return
        try:
            with open(fn, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError as e:
            QMessageBox.critical(self, "Open failed", str(e)); return
        self.imported = core.parse_sequence_text(text)
        self.imported_file = fn
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(text)
        self.txt_import.blockSignals(False)
        self.lbl_script.setText(os.path.basename(fn))
        self._add_recent(fn)
        self.imp_canvas.reset_view()
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()

    def import_samples(self, fn=None):
        dlg = SampleImportDialog(self, self.cfg)
        if fn:
            dlg.load(fn)
        if dlg.exec_() != QDialog.Accepted or not dlg.points:
            return
        if dlg.cb_target.currentIndex() == 0 and not self._maybe_save():
            return
        seg = {"type": "Table", "points": dlg.points}
        self._add_recent(dlg.path)
        if dlg.cb_target.currentIndex() == 0:
            name = "".join(c for c in os.path.splitext(os.path.basename(dlg.path))[0]
                           if c.isalnum() or c == "_")[:16]
            if not name or not name[0].isalpha():
                name = "SAMPLES"
            self.cfg.segments = [seg]
            self.cfg.name = name
            self.current_file = None
        else:
            self.cfg.segments.append(seg)
        self.cfg.channel = dlg.channel()
        self.cfg.repeat = dlg.repeat()
        self.canvas.reset_view()
        self._load_settings_into_ui()
        self.settings_changed()
        self.lst.setCurrentRow(len(self.cfg.segments) - 1)
        self.plot_tabs.setCurrentIndex(0)

    def _parse_inputs(self) -> dict:
        out = {}
        for part in self.ed_inputs.text().replace(";", ",").split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                try: out[k.strip().upper()] = int(float(v))
                except ValueError: pass
        return out

    def run_import_sim(self):
        if not self.imported:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.sim = core.simulate(self.imported, max_time=self.sp_simtime.value(),
                                     inputs=self._parse_inputs())
        finally:
            QApplication.restoreOverrideCursor()
        r, p = self.sim, self.imported
        name = self.imported_file.replace("\\", "/").split("/")[-1]
        self.imp_canvas.plot(r, f"{name}  –  sequence '{p.name}'")
        self.lbl_import.setText(
            f"<b>{len(p.steps)} steps</b>, labels: "
            f"{', '.join(f'{k}={v}' for k, v in p.labels.items()) or 'none'} · "
            f"simulated {r.end_time:.3f} s, {r.executed} steps executed · "
            f"{r.stop_reason}")
        msgs = [f"ERROR: {e}" for e in r.errors] + [f"Warning: {w}" for w in r.warnings]
        body = "\n".join(f"{n:>5}  {c}" for n, c in p.steps.items())
        self.txt_msg.setPlainText(
            ("\n".join(msgs) or "Imported file: no problems.")
            + "\n\n--- Parsed steps ---\n" + body)
        self.tabs.setCurrentIndex(1)

    def convert_import(self):
        if not self.sim:
            QMessageBox.information(self, "Convert", "Open a sequence file first."); return
        r, p = self.sim, self.imported
        analog = [c for c in ("SV", "SC", "SP", "SCN", "SPN") if c in r.traces
                  and (c in ("SV", "SC") or len({v for _, v in r.traces[c]}) > 1)]
        changes = {c: len(r.traces[c]) for c in analog}
        best = max(analog, key=changes.get)
        ch, ok = QInputDialog.getItem(self, "Convert to editable",
                                      "Channel to turn into the editable signal:",
                                      analog, analog.index(best), False)
        if not ok: return
        if not r.stop_reason.startswith("END"):
            if QMessageBox.question(
                    self, "Convert",
                    f"The simulation did not reach END:\n{r.stop_reason}\n\n"
                    f"Loops are unrolled up to the simulated time "
                    f"({r.end_time:.1f} s). Continue?") != QMessageBox.Yes:
                return
        pts = core.trace_to_points(r.traces[ch], r.end_time)
        if not self._maybe_save():
            return
        name = "".join(c for c in p.name if c.isalnum() or c == "_")[:16]
        if not name or not name[0].isalpha():
            name = "IMPORTED"
        cfg = self._fresh_settings(name=name, channel=ch, repeat=1,
                                   final_value_enabled=False,
                                   segments=[{"type": "Table", "points": pts}])
        if ch != "SV" and r.traces["SV"]:
            cfg.limit_voltage = max(v for _, v in r.traces["SV"])
        if ch != "SC" and r.traces["SC"]:
            cfg.limit_current = max(v for _, v in r.traces["SC"])
        self.cfg = cfg; self.current_file = None
        self.canvas.reset_view()
        self._load_settings_into_ui(); self.settings_changed()
        self.plot_tabs.setCurrentIndex(0)
        if len(pts) * 2 > core.MAX_STEPS:
            QMessageBox.warning(self, "Convert",
                                "The unrolled signal needs more than 2000 steps. "
                                "Use the Repeat setting or shorten the table.")

    # ------------------------------------------------------- script editing
    def apply_script(self):
        text = self.txt_import.toPlainText()
        if not text.strip():
            return
        self.imported = core.parse_sequence_text(text)
        if not self.imported_file:
            self.imported_file = "edited script"
        self.lbl_script.setText("Applied")
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()
        self.tabs.setCurrentIndex(2)          # stay in the script editor

    def load_generated_into_script(self):
        text = core.to_text(self.cfg, self.comp, self._fmt_key())
        if self.txt_import.toPlainText().strip() and QMessageBox.question(
                self, "Sequence script",
                "Replace the text in the script editor with the editor's "
                "sequence?") != QMessageBox.Yes:
            return
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(text)
        self.txt_import.blockSignals(False)
        self.imported_file = f"{self.cfg.name} (from editor)"
        self.imported = core.parse_sequence_text(text)
        self.imp_canvas.reset_view()
        self.tabs.setCurrentIndex(2)
        self.lbl_script.setText("Loaded from editor")
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()

    def save_script_as(self):
        if not self.txt_import.toPlainText().strip():
            QMessageBox.information(self, "Save script",
                                    "Open a sequence file or load the editor's "
                                    "sequence first."); return
        self.apply_script()
        seq = self.imported
        choice, ok = QInputDialog.getItem(
            self, "Save sequence as",
            "How should the file be written?",
            ["Exactly as in the editor (unchanged text)",
             "SCPI upload commands (renumbered, clean)",
             "Step list (renumbered, clean)"], 0, False)
        if not ok: return
        name = seq.name
        if not choice.startswith("Exactly"):
            name, ok = QInputDialog.getText(self, "Save sequence as",
                                            "Sequence name (max 16 chars):", text=seq.name)
            if not ok: return
            name = name.strip()[:16] or seq.name
            if not name[0].isalpha():
                QMessageBox.warning(self, "Name", "The name must start with a letter.")
                return
        fn, _ = _save_dialog(self, "Save sequence as",
                                            f"{name}.txt", "Text (*.txt)")
        if not fn: return
        if choice.startswith("Exactly"):
            text = self.txt_import.toPlainText()
        else:
            text = core.parsed_to_text(
                seq, name, "steps" if choice.startswith("Step") else "scpi",
                clear_before_upload=self.cfg.clear_before_upload)
        try:
            with open(fn, "w", encoding="ascii", errors="replace", newline="\n") as fh:
                fh.write(text if text.endswith("\n") else text + "\n")
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e)); return
        self.statusBar().showMessage(f"Saved {fn}", 4000)

    # ------------------------------------------------------- sample export
    def export_editor_samples(self):
        if self.comp.errors:
            return self._check_ok()
        cfg = copy.deepcopy(self.cfg)
        dlg = ExportSamplesDialog(self, lambda n: core.simulate_settings(cfg, n),
                                  "Export samples – editor signal", cfg.name,
                                  can_passes=cfg.repeat != 1)
        if dlg.exec_() == QDialog.Accepted:
            self.statusBar().showMessage("Samples exported.", 4000)

    def export_imported_samples(self):
        if not self.imported:
            QMessageBox.information(self, "Export samples",
                                    "Open a sequence .txt file first."); return
        seq, lim, inp = self.imported, self.sp_simtime.value(), self._parse_inputs()
        dlg = ExportSamplesDialog(
            self, lambda n: core.simulate(seq, max_time=lim, inputs=inp, step_time=0.0),
            "Export samples – imported sequence", seq.name, can_passes=False)
        if dlg.exec_() == QDialog.Accepted:
            self.statusBar().showMessage("Samples exported.", 4000)

    # ------------------------------------------------------- drag & drop
    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        urls = [u.toLocalFile() for u in ev.mimeData().urls() if u.isLocalFile()]
        if not urls:
            return
        self.open_any(urls[0])

    def open_any(self, fn):
        if not os.path.exists(fn):
            QMessageBox.warning(self, "Open", f"File not found:\n{fn}")
            return
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".json":
            self.open_project(fn)
        elif ext in (".csv", ".tsv", ".dat", ".xlsx", ".xlsm"):
            self.import_samples(fn)
        else:
            try:
                with open(fn, encoding="utf-8", errors="replace") as fh:
                    looks_seq = bool(core.parse_sequence_text(fh.read()).steps)
            except OSError:
                looks_seq = False
            self.import_txt(fn) if looks_seq else self.import_samples(fn)

    def _check_ok(self) -> bool:
        if self.comp.errors:
            QMessageBox.warning(self, "Sequence has errors",
                                "\n".join(self.comp.errors))
            return False
        return True

    def export_txt(self):
        if not self._check_ok(): return
        fn, _ = _save_dialog(self, "Export sequence",
                                            f"{self.cfg.name}.txt", "Text (*.txt)")
        if not fn: return
        try:
            with open(fn, "w", encoding="ascii", errors="replace", newline="\n") as fh:
                fh.write(core.to_text(self.cfg, self.comp, self._fmt_key()))
        except OSError as e:
            QMessageBox.critical(self, "Export failed", str(e)); return
        self.statusBar().showMessage(f"Exported {fn}", 4000)

    # ------------------------------------------------------- device actions
    def connection_settings(self):
        ConnectionDialog(self).exec_()
        if getattr(self, "conn_panel", None) is not None:
            self.conn_panel.reload()
        self._update_supply_label()
        if getattr(self, "_direct", None) is not None:
            self._direct.refresh_limits()

    def _update_supply_label(self):
        p = conn_params()
        dev = getattr(getattr(self, "cfg", None), "device", "")
        panel = getattr(self, "conn_panel", None)
        state = ""
        if panel is not None:
            state = ("connected" if panel.connected else "not connected") \
                if panel.want_connected else "not checked"
        self.sb_supply.setText(f"Supply {p['host']}:{p['port']} ({state})  ·  {dev}  ")
        pill = getattr(self, "conn_pill", None)
        if pill is not None:
            kind = {"connected": "ok", "not connected": "bad"}.get(state, "idle")
            word = {"ok": "connected", "bad": "NOT connected"}.get(kind, "not checked")
            set_state(pill, kind, f"●  {p['host']}:{p['port']}  {word}")

    def test_connection(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            with make_conn() as con:
                idn = core.identify(con)
            QMessageBox.information(self, "Connection", f"Connected:\n{idn}")
        except core.PsuError as e:
            QMessageBox.critical(self, "Connection", str(e))
        finally:
            QApplication.restoreOverrideCursor()

    def _upload(self, lines: list[str], name: str, steps: list[str], run_after=False):
        p = conn_params()
        if not confirm_high_voltage(self, core.max_setpoint(steps, "SV")):
            return
        box = QMessageBox(QMessageBox.Question, "Upload",
                          f"Upload sequence '{name}' ({len(steps)} steps) to "
                          f"{p['host']}:{p['port']}?", QMessageBox.Yes | QMessageBox.No, self)
        chk = QCheckBox("Verify afterwards (read every step back)")
        chk.setChecked(settings().value("ui/verify", True, type=bool))
        box.setCheckBox(chk)
        if box.exec_() != QMessageBox.Yes:
            return
        settings().setValue("ui/verify", chk.isChecked())
        log = []
        try:
            with make_conn() as con:
                up_errs = run_with_progress(
                    self, "Uploading…",
                    lambda prog: core.upload_sequence(con, lines, prog, log.append))
                if up_errs:
                    QMessageBox.warning(self, "Upload", "The supply rejected part of the "
                                        "upload:\n\n" + "\n".join(up_errs) +
                                        "\n\nFix the step(s) and upload again.")
                    return
                diffs = core.verify_upload(con, name, steps, log.append) \
                    if chk.isChecked() else None
        except core.PsuError as e:
            QMessageBox.critical(self, "Upload failed", str(e)); return
        if run_after and not diffs:
            try:
                with make_conn() as con:
                    res = core.run_sequence(con, name, control_cmds())
            except core.PsuError as e:
                QMessageBox.critical(self, "Run failed", str(e)); return
            report_run_result(self, name, res)
            if res["running"] and not res["errors"]:
                QMessageBox.information(self, "Upload", f"Uploaded and started '{name}'." +
                                        (" Verified OK." if diffs is not None else ""))
            return
        if diffs:
            self.txt_msg.setPlainText("Upload verification differences:\n" + "\n".join(diffs))
            self.tabs.setCurrentIndex(1)
            QMessageBox.warning(self, "Upload", f"Uploaded, but {len(diffs)} step(s) differ "
                                "– see Messages.")
        else:
            QMessageBox.information(self, "Upload", "Upload finished." +
                                    (" Verified OK." if diffs is not None else ""))

    def upload_psu(self):
        if not self._check_ok(): return
        lines = [ln for ln in core.to_scpi_lines(self.cfg, self.comp)
                 if ln.upper() != "PROG:SEL:STA RUN"]
        self._upload(lines, self.cfg.name, self.comp.steps,
                     run_after=self.cfg.run_after_upload)

    def upload_script(self):
        if not self.txt_import.toPlainText().strip():
            QMessageBox.information(self, "Upload", "The script editor is empty."); return
        self.apply_script()
        seq = core.renumber_steps(self.imported)
        name, ok = QInputDialog.getText(self, "Upload script", "Sequence name on the supply:",
                                        text=seq.name[:16])
        if not ok or not name.strip(): return
        name = name.strip()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,15}", name):
            QMessageBox.warning(self, "Upload script",
                                "The name must start with a letter and have at most 16 "
                                "letters, digits or _.")
            return
        text = core.parsed_to_text(seq, name, "scpi",
                                   clear_before_upload=self.cfg.clear_before_upload)
        self._upload(text.splitlines(), name, list(seq.steps.values()))

    def read_back(self):
        dlg = ReadBackDialog(self)
        if dlg.exec_() != QDialog.Accepted:
            return
        self.txt_import.blockSignals(True)
        self.txt_import.setPlainText(dlg.text)
        self.txt_import.blockSignals(False)
        self.imported = core.parse_sequence_text(dlg.text)
        self.imported.name = dlg.name
        self.imported_file = f"PSU: {dlg.name}"
        self.lbl_script.setText("read from PSU")
        self.imp_canvas.reset_view()
        self.plot_tabs.setCurrentIndex(1)
        self.run_import_sim()
        self.txt_msg.appendPlainText("\n--- Raw replies from the supply ---\n"
                                     + "\n".join(dlg.raw[:400]))

    def direct_control(self):
        self.open_dock(self.dock_direct)

    def live_monitor(self):
        self.open_dock(self.dock_live)

    def _quick(self, cmds, done):
        try:
            with make_conn() as con:
                for c in cmds:
                    con.write(c)
            self.statusBar().showMessage(done, 4000)
        except core.PsuError as e:
            QMessageBox.critical(self, "Power supply", str(e))

    def run_on_psu(self):
        name, ok = QInputDialog.getText(self, "Run sequence", "Sequence name:",
                                        text=self.cfg.name)
        if not ok or not name.strip():
            return
        name = name.strip()
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            with make_conn() as con:
                res = core.run_sequence(con, name, control_cmds())
        except core.PsuError as e:
            QMessageBox.critical(self, "Power supply", str(e)); return
        finally:
            QApplication.restoreOverrideCursor()
        report_run_result(self, name, res)

    def run_list(self):
        self.open_dock(self.dock_runlist)

    def add_opened_to_run_list(self):
        if self.imported_file and os.path.isfile(self.imported_file) and \
                self.lbl_script.text() not in ("Modified – click Apply",):
            self.run_panel.add_paths([self.imported_file])
        else:
            self.run_panel.add_script()
        self.open_dock(self.dock_runlist)

    def diagnose(self):
        DiagnoseDialog(self, self.cfg.name).exec_()

    def stop_on_psu(self):
        self._quick(["PROG:SEL:STA STOP"], "Sequence stopped.")

    def output_off(self):
        self._quick(["OUTP 0"], "Output switched OFF.")

    # ------------------------------------------------------- templates
    def _user_templates(self) -> dict:
        try:
            return json.loads(settings().value("templates_json", "{}", type=str))
        except ValueError:
            return {}

    def _rebuild_templates(self):
        m = self.menu_tpl
        m.clear()
        hdr = m.addAction("Project"); hdr.setEnabled(False)
        user = self._user_templates()
        if user:
            for name in sorted(user):
                a = m.addAction("   " + name)
                a.triggered.connect(lambda _=False, n=name:
                                    self.insert_template(self._user_templates()[n], n))
        else:
            a = m.addAction("   (none saved yet)"); a.setEnabled(False)
        m.addSeparator()
        a = m.addAction("Save selected segments as template…")
        a.triggered.connect(self.save_template)
        if user:
            d = m.addMenu("Delete template")
            for name in sorted(user):
                d.addAction(name).triggered.connect(
                    lambda _=False, n=name: self.delete_template(n))

    def insert_template(self, tpl: dict, name: str):
        segs = copy.deepcopy(tpl["segments"])
        ch = tpl.get("channel", self.cfg.channel)
        replace = True
        if self.cfg.segments:
            box = QMessageBox(QMessageBox.Question, "Insert template",
                              f"Insert template '{name}'?", parent=self)
            b_app = box.addButton("Append to current", QMessageBox.AcceptRole)
            b_rep = box.addButton("Replace current", QMessageBox.DestructiveRole)
            box.addButton(QMessageBox.Cancel)
            box.exec_()
            if box.clickedButton() not in (b_app, b_rep):
                return
            replace = box.clickedButton() is b_rep
        if replace:
            self.cfg.segments = segs
            self.cfg.channel = ch
            self.canvas.reset_view()
        else:
            self.cfg.segments.extend(segs)
            if ch != self.cfg.channel:
                QMessageBox.information(
                    self, "Template", f"This template was made for {ch}; the sequence "
                    f"controls {self.cfg.channel}. Values were kept as they are.")
        self._load_settings_into_ui()
        self.settings_changed()
        self.lst.setCurrentRow(len(self.cfg.segments) - 1)
        self.plot_tabs.setCurrentIndex(0)

    def save_template(self):
        rows = sorted({i.row() for i in self.lst.selectedIndexes()})
        segs = [self.cfg.segments[r] for r in rows] if rows else list(self.cfg.segments)
        if not segs:
            QMessageBox.information(self, "Template", "There are no segments to save.")
            return
        name, ok = QInputDialog.getText(
            self, "Save template",
            f"Name for this template ({len(segs)} segment(s)"
            f"{'' if rows else ', all segments'}):")
        if not ok or not name.strip():
            return
        user = self._user_templates()
        name = name.strip()
        if name in user and QMessageBox.question(
                self, "Template", f"Replace the existing template '{name}'?") \
                != QMessageBox.Yes:
            return
        user[name] = {"channel": self.cfg.channel, "segments": copy.deepcopy(segs)}
        settings().setValue("templates_json", json.dumps(user))
        self._rebuild_templates()
        self.statusBar().showMessage(f"Template '{name}' saved.", 4000)

    def delete_template(self, name):
        if QMessageBox.question(self, "Template", f"Delete template '{name}'?") \
                != QMessageBox.Yes:
            return
        user = self._user_templates()
        user.pop(name, None)
        settings().setValue("templates_json", json.dumps(user))
        self._rebuild_templates()

    # ------------------------------------------------------- recent / layout
    def _recent(self) -> list[str]:
        try:
            return json.loads(settings().value("recent_json", "[]", type=str))
        except ValueError:
            return []

    def _add_recent(self, fn):
        if not fn:
            return
        fn = os.path.abspath(fn)
        lst = [fn] + [x for x in self._recent() if x != fn]
        settings().setValue("recent_json", json.dumps(lst[:10]))
        self._rebuild_recent()

    def _rebuild_recent(self):
        if not hasattr(self, "menu_recent"):
            return
        self.menu_recent.clear()
        lst = self._recent()
        for fn in lst:
            a = self.menu_recent.addAction(os.path.basename(fn))
            a.setToolTip(fn); a.setStatusTip(fn)
            a.triggered.connect(lambda _=False, f=fn: self.open_any(f))
        if lst:
            self.menu_recent.addSeparator()
            a = self.menu_recent.addAction("Clear list")
            a.triggered.connect(lambda: (settings().setValue("recent_json", "[]"),
                                         self._rebuild_recent()))
        else:
            self.menu_recent.addAction("(empty)").setEnabled(False)

    def _fit_to_screen(self):
        """Start at a size that fits the screen (laptop, desktop or projector)."""
        scr = QApplication.primaryScreen()
        self._start_maximized = False
        if not scr:
            self.resize(1300, 800); return
        a = scr.availableGeometry()
        w, h = int(a.width() * 0.92), int(a.height() * 0.90)
        self.resize(max(800, min(w, 1700)), max(560, min(h, 1050)))
        self.move(a.x() + (a.width() - self.width()) // 2,
                  a.y() + (a.height() - self.height()) // 2)
        self._start_maximized = a.width() < 1400 or a.height() < 820

    def _keep_on_screen(self):
        """A window saved on a bigger/other monitor must not hang off the screen."""
        scr = QApplication.screenAt(self.geometry().center()) or QApplication.primaryScreen()
        if not scr or self.isMaximized():
            return
        a = scr.availableGeometry()
        fr = self.frameGeometry()
        if fr.width() > a.width() or fr.height() > a.height():
            self._fit_to_screen()
            self._start_maximized = True
            return
        if not a.contains(fr):
            x = min(max(fr.x(), a.x()), a.right() - fr.width())
            y = min(max(fr.y(), a.y()), a.bottom() - fr.height())
            self.move(x, y)

    def _tidy_dock_groups(self):
        """Windows that belong together are stacked as tabs, never squeezed on
        top of each other (Direct control / Live monitor / Run sequences, and
        Signal / Settings)."""
        for group in ((self.dock_direct, self.dock_live, self.dock_runlist),
                      (self.dock_signal, self.dock_settings)):
            shown = [d for d in group if not d.isHidden() and not d.isFloating()]
            for d in shown[1:]:
                if d not in self.tabifiedDockWidgets(shown[0]):
                    self.tabifyDockWidget(shown[0], d)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._adapt_to_size()

    def _adapt_to_size(self):
        """Keep everything visible on small windows: drop the group headings,
        then the button texts (badges + tooltips stay); shrink the Windows bar."""
        tb = getattr(self, "main_tb", None)
        if tb is None or not hasattr(self, "windows_bar"):
            return
        w, h = self.width(), self.height()
        for a in self._tb_headings:
            a.setVisible(w >= 1560)
        long_text = w >= 1180
        for k, (full, short) in self._tb_labels.items():
            self.acts[k].setIconText(full if long_text else short)
        tb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon if w >= 900
                              else Qt.ToolButtonIconOnly)
        tb.setIconSize(QSize(26, 26) if long_text else QSize(22, 22))
        self.conn_pill.setVisible(w >= 1000)
        bar = self.windows_bar
        bar.setToolButtonStyle(Qt.ToolButtonTextUnderIcon if h >= 700
                               else Qt.ToolButtonIconOnly)
        bar.setIconSize(QSize(26, 26) if h >= 900 else QSize(20, 20))
        for a in self._bar_headings:
            a.setVisible(h >= 820)

    LAYOUT_VERSION = 3          # bump when the dock arrangement changes

    def _restore_ui_state(self):
        s = settings()
        same = str(s.value("ui/layout_version", "")) == str(self.LAYOUT_VERSION)
        g = s.value("ui/geometry") if same else None
        if g is not None:
            self.restoreGeometry(g)
            self._keep_on_screen()
        st = s.value("ui/state") if same else None
        if st is not None:
            self.restoreState(st)
            self._tidy_dock_groups()
        self.cb_fmt.setCurrentIndex(int(s.value("ui/format", 0)))
        self.sp_simtime.setValue(float(s.value("ui/simtime", 600.0)))
        self.ed_inputs.setText(s.value("ui/inputs", "", type=str))

    def closeEvent(self, ev):
        if not self._maybe_save():
            ev.ignore()
            return
        rp = getattr(self, "run_panel", None)
        if rp is not None and rp.worker is not None and rp.worker.isRunning():
            if QMessageBox.question(
                    self, "Run in progress",
                    "Sequences are still running on the supply.\n\n"
                    "Stop the supply and close the application?",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                ev.ignore()
                return
        s = settings()
        s.setValue("ui/geometry", self.saveGeometry())
        s.setValue("ui/state", self.saveState())
        s.setValue("ui/layout_version", self.LAYOUT_VERSION)
        s.setValue("ui/format", self.cb_fmt.currentIndex())
        s.setValue("ui/simtime", self.sp_simtime.value())
        s.setValue("ui/inputs", self.ed_inputs.text())
        for name in ("_live", "_direct", "run_panel"):
            w = getattr(self, name, None)
            if w is not None:
                w.close()
                if hasattr(w, "stop"):
                    w.stop()
        if getattr(self, "conn_panel", None) is not None:
            self.conn_panel.stop()
        super().closeEvent(ev)

def _excepthook(exc_type, exc, tb):
    """Show unexpected errors in a dialog instead of letting PyQt abort the app."""
    import traceback
    text = "".join(traceback.format_exception(exc_type, exc, tb))
    try:
        sys.__stderr__.write(text)
    except (UnicodeError, AttributeError, OSError):
        pass
    if QApplication.instance():
        box = QMessageBox(QMessageBox.Critical, "Unexpected error", str(exc))
        box.setDetailedText(text)
        box.exec_()


def main():
    sys.excepthook = _excepthook
    # follow the Windows display scaling (125 %, 150 % …) so icons, spacing and
    # text keep their proportions on laptops and 4K screens
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    if hasattr(QApplication, "setHighDpiScaleFactorRoundingPolicy"):
        try:
            QApplication.setHighDpiScaleFactorRoundingPolicy(
                Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
        except AttributeError:
            pass
    app = QApplication(sys.argv)
    f = app.font()
    if f.pointSize() > 0 and f.pointSize() < 10:
        f.setPointSize(10); app.setFont(f)
    apply_theme(app)
    w = MainWindow()
    if getattr(w, "_start_maximized", False) and settings().value("ui/geometry") is None:
        w.showMaximized()
    else:
        w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
